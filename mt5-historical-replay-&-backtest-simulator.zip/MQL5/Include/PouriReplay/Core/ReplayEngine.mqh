//+------------------------------------------------------------------+
//|                                                 ReplayEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "SimulationDefines.mqh"
#include "../Data/MarketData.mqh"

//+------------------------------------------------------------------+
//| Class CReplayEngine: Pacing & No-Lookahead Replay Controller     |
//+------------------------------------------------------------------+
class CReplayEngine
{
private:
   CMarketData        *m_market_data;        // Pointer to historical data provider
   ENUM_REPLAY_STATE   m_state;              // PAUSED, RUNNING, or STOPPED
   ENUM_REPLAY_SPEED   m_speed;              // Current speed setting
   ENUM_REPLAY_MODE    m_mode;               // Candle, Intrabar, or Tick
   int                 m_current_bar_index;  // Active bar index in historical buffer
   int                 m_intrabar_substep;   // 0=Open, 1=Extremum1, 2=Extremum2, 3=Close
   datetime            m_current_time;       // Replay clock
   datetime            m_start_time;         // Replay start boundary
   datetime            m_end_time;           // Replay end boundary
   ulong               m_last_timer_tick;    // Millisecond clock for pacing
   double              m_accumulated_ms;     // Accumulated delta for fractional speeds

   // Multiplier table matching ENUM_REPLAY_SPEED
   double              m_speed_multipliers[10];

public:
   CReplayEngine();
   ~CReplayEngine();

   bool                Initialize(CMarketData *market_data, const int start_bar_index = 50);

   // Replay controls
   void                Play();
   void                Pause();
   void                TogglePlayPause();
   bool                StepNext();
   bool                StepPrev();
   void                SetSpeed(const ENUM_REPLAY_SPEED speed);
   void                SetMode(const ENUM_REPLAY_MODE mode) { m_mode = mode; }
   bool                JumpToIndex(const int target_index);
   bool                JumpToDate(const datetime target_date);

   // Main timer event handler
   bool                OnTimerTick(const ulong current_tick_ms);

   // Getters
   ENUM_REPLAY_STATE   GetState() const { return m_state; }
   ENUM_REPLAY_SPEED   GetSpeed() const { return m_speed; }
   ENUM_REPLAY_MODE    GetMode() const { return m_mode; }
   int                 GetCurrentIndex() const { return m_current_bar_index; }
   int                 GetIntrabarStep() const { return m_intrabar_substep; }
   datetime            GetCurrentTime() const { return m_current_time; }
   double              GetProgressPercent() const;
   double              GetSpeedMultiplier() const { return m_speed_multipliers[(int)m_speed]; }
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CReplayEngine::CReplayEngine()
   : m_market_data(NULL),
     m_state(REPLAY_STATE_PAUSED),
     m_speed(SPEED_1X),
     m_mode(REPLAY_MODE_CANDLE),
     m_current_bar_index(50),
     m_intrabar_substep(0),
     m_current_time(0),
     m_start_time(0),
     m_end_time(0),
     m_last_timer_tick(0),
     m_accumulated_ms(0.0)
{
   m_speed_multipliers[0] = 0.1;
   m_speed_multipliers[1] = 0.25;
   m_speed_multipliers[2] = 0.5;
   m_speed_multipliers[3] = 1.0;
   m_speed_multipliers[4] = 2.0;
   m_speed_multipliers[5] = 5.0;
   m_speed_multipliers[6] = 10.0;
   m_speed_multipliers[7] = 25.0;
   m_speed_multipliers[8] = 50.0;
   m_speed_multipliers[9] = 100.0;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CReplayEngine::~CReplayEngine()
{
}

//+------------------------------------------------------------------+
//| Initialize with historical data and initial position             |
//+------------------------------------------------------------------+
bool CReplayEngine::Initialize(CMarketData *market_data, const int start_bar_index)
{
   if (market_data == NULL || market_data.GetTotalBars() <= 0)
      return false;

   m_market_data       = market_data;
   int total           = m_market_data.GetTotalBars();
   m_current_bar_index = MathMin(MathMax(10, start_bar_index), total - 1);
   m_intrabar_substep  = 0;
   m_state             = REPLAY_STATE_PAUSED;
   m_accumulated_ms    = 0.0;
   m_last_timer_tick   = GetMicrosecondCount() / 1000;

   MqlRates rate;
   if (m_market_data.GetBar(m_current_bar_index, rate))
   {
      m_current_time = rate.time;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Play forward                                                     |
//+------------------------------------------------------------------+
void CReplayEngine::Play()
{
   if (m_market_data == NULL) return;
   if (m_current_bar_index >= m_market_data.GetTotalBars() - 1)
   {
      m_state = REPLAY_STATE_STOPPED;
      return;
   }
   m_state           = REPLAY_STATE_RUNNING;
   m_last_timer_tick = GetMicrosecondCount() / 1000;
}

//+------------------------------------------------------------------+
//| Pause replay                                                     |
//+------------------------------------------------------------------+
void CReplayEngine::Pause()
{
   m_state = REPLAY_STATE_PAUSED;
}

//+------------------------------------------------------------------+
//| Toggle Play / Pause state                                        |
//+------------------------------------------------------------------+
void CReplayEngine::TogglePlayPause()
{
   if (m_state == REPLAY_STATE_RUNNING)
      Pause();
   else
      Play();
}

//+------------------------------------------------------------------+
//| Advance single step forward                                      |
//+------------------------------------------------------------------+
bool CReplayEngine::StepNext()
{
   if (m_market_data == NULL) return false;

   int total = m_market_data.GetTotalBars();
   if (m_current_bar_index >= total - 1)
   {
      m_state = REPLAY_STATE_STOPPED;
      return false;
   }

   if (m_mode == REPLAY_MODE_INTRABAR)
   {
      m_intrabar_substep++;
      if (m_intrabar_substep > 3)
      {
         m_intrabar_substep = 0;
         m_current_bar_index++;
      }
   }
   else
   {
      m_current_bar_index++;
      m_intrabar_substep = 0;
   }

   MqlRates rate;
   if (m_market_data.GetBar(m_current_bar_index, rate))
   {
      m_current_time = rate.time;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Step single bar backward                                         |
//+------------------------------------------------------------------+
bool CReplayEngine::StepPrev()
{
   if (m_market_data == NULL) return false;

   if (m_current_bar_index <= 10)
      return false;

   m_current_bar_index--;
   m_intrabar_substep = 0;

   MqlRates rate;
   if (m_market_data.GetBar(m_current_bar_index, rate))
   {
      m_current_time = rate.time;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Set replay speed                                                 |
//+------------------------------------------------------------------+
void CReplayEngine::SetSpeed(const ENUM_REPLAY_SPEED speed)
{
   m_speed = speed;
}

//+------------------------------------------------------------------+
//| Jump directly to specific bar index                              |
//+------------------------------------------------------------------+
bool CReplayEngine::JumpToIndex(const int target_index)
{
   if (m_market_data == NULL) return false;

   int total = m_market_data.GetTotalBars();
   if (target_index < 0 || target_index >= total)
      return false;

   m_current_bar_index = target_index;
   m_intrabar_substep  = 0;

   MqlRates rate;
   if (m_market_data.GetBar(m_current_bar_index, rate))
   {
      m_current_time = rate.time;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Jump directly to specific date                                   |
//+------------------------------------------------------------------+
bool CReplayEngine::JumpToDate(const datetime target_date)
{
   if (m_market_data == NULL) return false;

   int total = m_market_data.GetTotalBars();
   for (int i = 0; i < total; i++)
   {
      MqlRates rate;
      if (m_market_data.GetBar(i, rate) && rate.time >= target_date)
      {
         return JumpToIndex(i);
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| High-frequency timer tick handler (advances time with pacing)    |
//+------------------------------------------------------------------+
bool CReplayEngine::OnTimerTick(const ulong current_tick_ms)
{
   if (m_state != REPLAY_STATE_RUNNING || m_market_data == NULL)
      return false;

   if (m_last_timer_tick == 0)
   {
      m_last_timer_tick = current_tick_ms;
      return false;
   }

   ulong delta_ms    = current_tick_ms - m_last_timer_tick;
   m_last_timer_tick = current_tick_ms;

   // Modulate time step by speed multiplier
   double multiplier = m_speed_multipliers[(int)m_speed];
   m_accumulated_ms += (double)delta_ms * multiplier;

   // Standard candle step interval base is 1000ms
   const double BASE_STEP_INTERVAL_MS = 1000.0;

   bool stepped = false;
   while (m_accumulated_ms >= BASE_STEP_INTERVAL_MS)
   {
      m_accumulated_ms -= BASE_STEP_INTERVAL_MS;
      if (!StepNext())
      {
         m_state = REPLAY_STATE_STOPPED;
         break;
      }
      stepped = true;
   }

   return stepped;
}

//+------------------------------------------------------------------+
//| Calculate replay progress (0.0 to 100.0%)                        |
//+------------------------------------------------------------------+
double CReplayEngine::GetProgressPercent() const
{
   if (m_market_data == NULL || m_market_data.GetTotalBars() <= 1)
      return 0.0;

   return ((double)m_current_bar_index / (double)(m_market_data.GetTotalBars() - 1)) * 100.0;
}

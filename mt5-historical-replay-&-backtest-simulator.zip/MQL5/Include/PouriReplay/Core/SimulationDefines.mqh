//+------------------------------------------------------------------+
//|                                            SimulationDefines.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

//--- Replay Run State
enum ENUM_REPLAY_STATE
{
   REPLAY_STATE_PAUSED   = 0, // Replay is currently paused
   REPLAY_STATE_RUNNING  = 1, // Replay is playing forward
   REPLAY_STATE_STOPPED  = 2  // Replay reached end of dataset
};

//--- Replay Speed Multipliers
enum ENUM_REPLAY_SPEED
{
   SPEED_0_1X   = 0,   // 0.1x Speed
   SPEED_0_25X  = 1,   // 0.25x Speed
   SPEED_0_5X   = 2,   // 0.5x Speed
   SPEED_1X     = 3,   // 1.0x Real-time
   SPEED_2X     = 4,   // 2.0x Speed
   SPEED_5X     = 5,   // 5.0x Speed
   SPEED_10X    = 6,   // 10.0x Speed
   SPEED_25X    = 7,   // 25.0x Speed
   SPEED_50X    = 8,   // 50.0x Speed
   SPEED_100X   = 9    // 100.0x Speed
};

//--- Replay Progression Mode
enum ENUM_REPLAY_MODE
{
   REPLAY_MODE_CANDLE   = 0, // Bar-by-bar stepping
   REPLAY_MODE_INTRABAR = 1, // 4-microticks per bar (O -> Extreme1 -> Extreme2 -> C)
   REPLAY_MODE_TICK     = 2  // Exact historical tick replay
};

//--- Trade Direction
enum ENUM_TRADE_DIRECTION
{
   DIRECTION_BUY  = 0,
   DIRECTION_SELL = 1
};

//--- Virtual Order Type
enum ENUM_SIM_ORDER_TYPE
{
   SIM_ORDER_MARKET_BUY  = 0,
   SIM_ORDER_MARKET_SELL = 1,
   SIM_ORDER_BUY_LIMIT   = 2,
   SIM_ORDER_SELL_LIMIT  = 3,
   SIM_ORDER_BUY_STOP    = 4,
   SIM_ORDER_SELL_STOP   = 5
};

//--- Spread Simulation Model
enum ENUM_SPREAD_MODEL
{
   SPREAD_HISTORICAL   = 0, // Direct from historical rates
   SPREAD_FIXED        = 1, // Fixed points
   SPREAD_RANDOM_RANGE = 2  // Jitter within min/max bounds
};

//--- Slippage Simulation Model
enum ENUM_SLIPPAGE_MODEL
{
   SLIPPAGE_NONE   = 0, // Zero slippage
   SLIPPAGE_FIXED  = 1, // Fixed point deviation
   SLIPPAGE_RANDOM = 2  // Stochastic normal deviation
};

//--- Virtual Position Struct
struct SimPosition
{
   long                 ticket;          // Unique virtual ticket ID
   string               symbol;          // Symbol name
   ENUM_TRADE_DIRECTION direction;       // BUY or SELL
   double               lots;            // Volume in lots
   double               open_price;      // Open price (Ask for BUY, Bid for SELL)
   datetime             open_time;       // Historical timestamp of entry
   double               sl;              // Stop Loss price
   double               tp;              // Take Profit price
   double               current_price;   // Current market price
   double               commission;      // Total commission charged ($)
   double               swap;            // Total swap accrued ($)
   double               floating_profit; // Current gross floating P/L ($)
   double               net_profit;      // Current net floating P/L ($)
   double               pips;            // Floating profit in pips
   double               max_favorable;   // MFE in pips
   double               max_adverse;     // MAE in pips
   string               comment;         // User comment
   string               strategy_tag;    // Strategy label (e.g. BREAKOUT)
};

//--- Virtual Pending Order Struct
struct SimPendingOrder
{
   long                 ticket;          // Unique virtual ticket ID
   string               symbol;          // Symbol name
   ENUM_SIM_ORDER_TYPE  type;            // Order type (Limit/Stop)
   ENUM_TRADE_DIRECTION direction;       // BUY or SELL
   double               lots;            // Volume in lots
   double               target_price;    // Trigger level
   double               sl;              // Stop loss
   double               tp;              // Take profit
   datetime             placed_time;     // Time order was placed
   string               comment;         // Comment
   string               strategy_tag;    // Strategy tag
};

//--- Virtual Account State Struct
struct SimAccountState
{
   double   initial_balance;   // Initial deposit ($)
   double   balance;           // Realized balance ($)
   double   equity;            // Balance + Floating P/L ($)
   double   used_margin;       // Required margin for open positions ($)
   double   free_margin;       // Equity - Used Margin ($)
   double   margin_level;      // (Equity / Used Margin) * 100%
   double   leverage;          // Account leverage (e.g. 100)
   double   floating_profit;   // Total open P/L ($)
   double   realized_profit;   // Total closed P/L ($)
   double   total_commission;  // Total commissions paid ($)
   double   total_swap;        // Total swaps paid ($)
   int      open_positions;    // Count of currently active positions
   int      pending_orders;    // Count of currently active pending orders
   int      total_trades;      // Total completed trades count
};

//--- Closed Trade Record Struct for Journaling
struct SimClosedTrade
{
   long                 ticket;          // Position ticket
   string               symbol;          // Symbol name
   ENUM_TRADE_DIRECTION direction;       // BUY or SELL
   double               lots;            // Traded volume
   double               open_price;      // Entry price
   double               close_price;     // Exit price
   datetime             open_time;       // Entry timestamp
   datetime             close_time;      // Exit timestamp
   double               sl;              // Stop loss level
   double               tp;              // Take profit level
   double               gross_profit;    // Gross profit ($)
   double               commission;      // Commission ($)
   double               swap;            // Swap ($)
   double               net_profit;      // Net profit ($)
   double               pips;            // Pips gained/lost
   double               r_multiple;      // Realized R-Multiple
   long                 holding_seconds; // Duration in seconds
   double               mae_pips;        // Maximum Adverse Excursion
   double               mfe_pips;        // Maximum Favorable Excursion
   string               close_reason;    // MANUAL, SL, TP, PARTIAL
   string               strategy_tag;    // Setup / Strategy
   string               notes;           // User reflection notes
};

//--- Simulation Constants
#define SIM_DEFAULT_INITIAL_BALANCE  10000.0
#define SIM_DEFAULT_LEVERAGE          100.0
#define SIM_DEFAULT_COMMISSION_LOT    7.0     // $7 per round lot
#define SIM_TIMER_INTERVAL_MS         20      // 50 updates per second
#define SIM_MAX_POSITIONS             50
#define SIM_MAX_PENDING               50

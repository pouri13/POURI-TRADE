//+------------------------------------------------------------------+
//|                                                 MarketEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CMarketEngine: Microstructure, Bid/Ask & Spread Model      |
//+------------------------------------------------------------------+
class CMarketEngine
{
private:
   CMarketData        *m_market_data;
   CReplayEngine      *m_replay_engine;

   ENUM_SPREAD_MODEL   m_spread_model;
   int                 m_fixed_spread_points;
   int                 m_random_spread_min;
   int                 m_random_spread_max;

   ENUM_SLIPPAGE_MODEL m_slippage_model;
   int                 m_fixed_slippage_points;

   double              m_current_bid;
   double              m_current_ask;
   double              m_current_last;
   int                 m_current_spread_points;
   MqlRates            m_current_candle;

public:
   CMarketEngine();
   ~CMarketEngine();

   bool                Initialize(CMarketData *market_data, CReplayEngine *replay_engine);
   void                UpdateQuotes();

   // Configuration
   void                SetSpreadModel(const ENUM_SPREAD_MODEL model, const int fixed_points = 10, const int rand_min = 8, const int rand_max = 25);
   void                SetSlippageModel(const ENUM_SLIPPAGE_MODEL model, const int fixed_points = 0);

   // Slippage calculation
   double              ApplySlippage(const double requested_price, const ENUM_TRADE_DIRECTION dir, const bool is_market_or_stop);

   // Getters
   double              GetBid() const { return m_current_bid; }
   double              GetAsk() const { return m_current_ask; }
   double              GetLast() const { return m_current_last; }
   int                 GetSpreadPoints() const { return m_current_spread_points; }
   bool                GetCurrentCandle(MqlRates &out_candle) const { out_candle = m_current_candle; return true; }
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CMarketEngine::CMarketEngine()
   : m_market_data(NULL),
     m_replay_engine(NULL),
     m_spread_model(SPREAD_HISTORICAL),
     m_fixed_spread_points(15),
     m_random_spread_min(10),
     m_random_spread_max(30),
     m_slippage_model(SLIPPAGE_NONE),
     m_fixed_slippage_points(0),
     m_current_bid(0.0),
     m_current_ask(0.0),
     m_current_last(0.0),
     m_current_spread_points(15)
{
   ZeroMemory(m_current_candle);
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CMarketEngine::~CMarketEngine()
{
}

//+------------------------------------------------------------------+
//| Initialize with data and replay engine                           |
//+------------------------------------------------------------------+
bool CMarketEngine::Initialize(CMarketData *market_data, CReplayEngine *replay_engine)
{
   if (market_data == NULL || replay_engine == NULL)
      return false;

   m_market_data   = market_data;
   m_replay_engine = replay_engine;
   UpdateQuotes();
   return true;
}

//+------------------------------------------------------------------+
//| Configure spread simulation model                                |
//+------------------------------------------------------------------+
void CMarketEngine::SetSpreadModel(const ENUM_SPREAD_MODEL model, const int fixed_points, const int rand_min, const int rand_max)
{
   m_spread_model        = model;
   m_fixed_spread_points = MathMax(0, fixed_points);
   m_random_spread_min   = MathMax(0, rand_min);
   m_random_spread_max   = MathMax(m_random_spread_min, rand_max);
}

//+------------------------------------------------------------------+
//| Configure slippage model                                         |
//+------------------------------------------------------------------+
void CMarketEngine::SetSlippageModel(const ENUM_SLIPPAGE_MODEL model, const int fixed_points)
{
   m_slippage_model        = model;
   m_fixed_slippage_points = fixed_points;
}

//+------------------------------------------------------------------+
//| Refresh quotes based on current replay index & substep           |
//+------------------------------------------------------------------+
void CMarketEngine::UpdateQuotes()
{
   if (m_market_data == NULL || m_replay_engine == NULL) return;

   int idx = m_replay_engine.GetCurrentIndex();
   if (!m_market_data.GetBar(idx, m_current_candle))
      return;

   // Determine reference price based on mode
   double price = m_current_candle.close;
   if (m_replay_engine.GetMode() == REPLAY_MODE_INTRABAR)
   {
      int step = m_replay_engine.GetIntrabarStep();
      bool is_bull = (m_current_candle.close >= m_current_candle.open);
      switch(step)
      {
         case 0: price = m_current_candle.open; break;
         case 1: price = is_bull ? m_current_candle.low : m_current_candle.high; break;
         case 2: price = is_bull ? m_current_candle.high : m_current_candle.low; break;
         case 3: price = m_current_candle.close; break;
      }
   }

   // Compute spread
   switch(m_spread_model)
   {
      case SPREAD_FIXED:
         m_current_spread_points = m_fixed_spread_points;
         break;

      case SPREAD_RANDOM_RANGE:
         m_current_spread_points = m_random_spread_min + (MathRand() % (m_random_spread_max - m_random_spread_min + 1));
         break;

      case SPREAD_HISTORICAL:
      default:
         m_current_spread_points = (int)m_current_candle.spread;
         if (m_current_spread_points <= 0)
            m_current_spread_points = m_market_data.GetTypicalSpread();
         break;
   }

   double point = m_market_data.GetPoint();
   int digits   = m_market_data.GetDigits();

   m_current_bid  = NormalizeDouble(price, digits);
   m_current_ask  = NormalizeDouble(m_current_bid + (m_current_spread_points * point), digits);
   m_current_last = m_current_bid;
}

//+------------------------------------------------------------------+
//| Evaluates and applies slippage to order execution price          |
//+------------------------------------------------------------------+
double CMarketEngine::ApplySlippage(const double requested_price, const ENUM_TRADE_DIRECTION dir, const bool is_market_or_stop)
{
   if (m_slippage_model == SLIPPAGE_NONE || !is_market_or_stop || m_market_data == NULL)
      return requested_price;

   double point = m_market_data.GetPoint();
   int digits   = m_market_data.GetDigits();
   int slip_points = 0;

   if (m_slippage_model == SLIPPAGE_FIXED)
   {
      slip_points = m_fixed_slippage_points;
   }
   else if (m_slippage_model == SLIPPAGE_RANDOM)
   {
      // Skewed towards slight negative slippage
      int r = MathRand() % 100;
      if (r < 65) slip_points = MathRand() % 4;        // 0 to 3 points slippage
      else if (r < 90) slip_points = 3 + (MathRand() % 5); // 3 to 7 points
      else slip_points = 7 + (MathRand() % 10);        // 7 to 16 points (volatile)
   }

   double slip_dist = slip_points * point;
   double final_price = requested_price;

   // BUY market orders slip upward (higher ask); SELL slip downward (lower bid)
   if (dir == DIRECTION_BUY)
      final_price += slip_dist;
   else
      final_price -= slip_dist;

   return NormalizeDouble(final_price, digits);
}

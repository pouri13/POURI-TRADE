//+------------------------------------------------------------------+
//|                                                AccountEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "SimulationDefines.mqh"
#include "../Data/MarketData.mqh"

//+------------------------------------------------------------------+
//| Class CAccountEngine: Virtual Account & Margin Simulator         |
//+------------------------------------------------------------------+
class CAccountEngine
{
private:
   CMarketData       *m_market_data;
   SimAccountState    m_state;
   double             m_commission_per_lot;
   double             m_stop_out_level;    // e.g. 50.0%

public:
   CAccountEngine();
   ~CAccountEngine();

   bool               Initialize(CMarketData *market_data, const double initial_balance = 10000.0, const double leverage = 100.0);
   void               Reset(const double initial_balance, const double leverage);

   // Margin calculations
   double             CalculateRequiredMargin(const double lots, const double price) const;
   bool               HasSufficientMargin(const double lots, const double price) const;

   // Transaction & State adjustments
   void               DeductCommission(const double commission);
   void               AccrueSwap(const double swap);
   void               ApplyRealizedProfit(const double net_pnl);
   void               UpdateEquityAndMargin(const double floating_profit, const double total_used_margin, const int open_positions, const int pending_orders);

   // Getters
   SimAccountState    GetState() const { return m_state; }
   double             GetBalance() const { return m_state.balance; }
   double             GetEquity() const { return m_state.equity; }
   double             GetFreeMargin() const { return m_state.free_margin; }
   double             GetMarginLevel() const { return m_state.margin_level; }
   double             GetFloatingProfit() const { return m_state.floating_profit; }
   double             GetRealizedProfit() const { return m_state.realized_profit; }
   double             GetCommissionPerLot() const { return m_commission_per_lot; }
   void               SetCommissionPerLot(const double comm) { m_commission_per_lot = comm; }
   bool               IsStopOutTriggered() const { return (m_state.used_margin > 0.0 && m_state.margin_level <= m_stop_out_level); }
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CAccountEngine::CAccountEngine()
   : m_market_data(NULL),
     m_commission_per_lot(SIM_DEFAULT_COMMISSION_LOT),
     m_stop_out_level(50.0)
{
   ZeroMemory(m_state);
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CAccountEngine::~CAccountEngine()
{
}

//+------------------------------------------------------------------+
//| Initialize the account engine                                    |
//+------------------------------------------------------------------+
bool CAccountEngine::Initialize(CMarketData *market_data, const double initial_balance, const double leverage)
{
   m_market_data = market_data;
   Reset(initial_balance, leverage);
   return true;
}

//+------------------------------------------------------------------+
//| Reset virtual account state                                      |
//+------------------------------------------------------------------+
void CAccountEngine::Reset(const double initial_balance, const double leverage)
{
   m_state.initial_balance  = initial_balance;
   m_state.balance          = initial_balance;
   m_state.equity           = initial_balance;
   m_state.used_margin      = 0.0;
   m_state.free_margin      = initial_balance;
   m_state.margin_level     = 0.0;
   m_state.leverage         = (leverage > 0.0) ? leverage : SIM_DEFAULT_LEVERAGE;
   m_state.floating_profit  = 0.0;
   m_state.realized_profit  = 0.0;
   m_state.total_commission = 0.0;
   m_state.total_swap       = 0.0;
   m_state.open_positions   = 0;
   m_state.pending_orders   = 0;
   m_state.total_trades     = 0;
}

//+------------------------------------------------------------------+
//| Calculate required margin for position using MT5 formula         |
//+------------------------------------------------------------------+
double CAccountEngine::CalculateRequiredMargin(const double lots, const double price) const
{
   if (m_market_data == NULL || m_state.leverage <= 0.0)
      return 0.0;

   double contract_size = m_market_data.GetContractSize();
   
   // For commodities (Gold / XAUUSD) and CFDs, margin = (Lots * ContractSize * Price) / Leverage
   // For Forex where base currency is account currency, margin = (Lots * ContractSize) / Leverage
   double notional_value = lots * contract_size * price;
   return NormalizeDouble(notional_value / m_state.leverage, 2);
}

//+------------------------------------------------------------------+
//| Verify if account has sufficient free margin                     |
//+------------------------------------------------------------------+
bool CAccountEngine::HasSufficientMargin(const double lots, const double price) const
{
   double req = CalculateRequiredMargin(lots, price);
   return (m_state.free_margin >= req);
}

//+------------------------------------------------------------------+
//| Deduct commission fee                                            |
//+------------------------------------------------------------------+
void CAccountEngine::DeductCommission(const double commission)
{
   m_state.total_commission += commission;
   m_state.balance          -= commission;
   m_state.equity           -= commission;
}

//+------------------------------------------------------------------+
//| Accrue overnight swap                                            |
//+------------------------------------------------------------------+
void CAccountEngine::AccrueSwap(const double swap)
{
   m_state.total_swap += swap;
   m_state.balance    += swap;
   m_state.equity     += swap;
}

//+------------------------------------------------------------------+
//| Apply closed trade realized profit / loss                        |
//+------------------------------------------------------------------+
void CAccountEngine::ApplyRealizedProfit(const double net_pnl)
{
   m_state.balance         += net_pnl;
   m_state.realized_profit += net_pnl;
   m_state.total_trades++;
}

//+------------------------------------------------------------------+
//| Synchronize equity, used margin, and margin level                |
//+------------------------------------------------------------------+
void CAccountEngine::UpdateEquityAndMargin(const double floating_profit, const double total_used_margin, const int open_positions, const int pending_orders)
{
   m_state.floating_profit = floating_profit;
   m_state.equity          = NormalizeDouble(m_state.balance + floating_profit, 2);
   m_state.used_margin     = NormalizeDouble(total_used_margin, 2);
   m_state.free_margin     = NormalizeDouble(m_state.equity - m_state.used_margin, 2);
   m_state.open_positions  = open_positions;
   m_state.pending_orders  = pending_orders;

   if (m_state.used_margin > 0.0)
      m_state.margin_level = NormalizeDouble((m_state.equity / m_state.used_margin) * 100.0, 1);
   else
      m_state.margin_level = 0.0;
}

//+------------------------------------------------------------------+
//|                                              PositionManager.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Core/AccountEngine.mqh"

#define SIM_MAX_CLOSED_HISTORY 200

//+------------------------------------------------------------------+
//| Class CPositionManager: Multi-Position Hedging & SL/TP Monitor   |
//+------------------------------------------------------------------+
class CPositionManager
{
private:
   CMarketData        *m_market_data;
   CAccountEngine     *m_account_engine;
   SimPosition         m_positions[SIM_MAX_POSITIONS];
   int                 m_count;
   long                m_ticket_generator;

   // Closed trade history buffer for journal and exit visualization
   SimClosedTrade      m_closed_trades[SIM_MAX_CLOSED_HISTORY];
   int                 m_closed_count;

public:
   CPositionManager();
   ~CPositionManager();

   bool                Initialize(CMarketData *market_data, CAccountEngine *account_engine);
   void                ClearAll();

   // Position operations
   long                AddPosition(const string symbol, const ENUM_TRADE_DIRECTION dir, const double lots, const double open_price, const datetime open_time, const double sl = 0.0, const double tp = 0.0, const string comment = "", const string strategy = "MANUAL");
   bool                ClosePosition(const long ticket, const double close_price, const datetime close_time, const string reason, SimClosedTrade &out_closed);
   bool                PartialClose(const long ticket, const double close_lots, const double close_price, const datetime close_time, SimClosedTrade &out_closed);
   void                CloseAll(const double bid_price, const double ask_price, const datetime close_time);

   // SL / TP & Trailing modifications
   bool                ModifySlTp(const long ticket, const double new_sl, const double new_tp);
   bool                MoveToBreakeven(const long ticket, const double offset_points = 0.0);

   // Tick evaluation & floating P/L calculation
   void                UpdatePositions(const double bid_price, const double ask_price, const datetime current_time);

   // Getters
   int                 GetCount() const { return m_count; }
   bool                GetPositionByIndex(const int index, SimPosition &out_pos) const;
   bool                GetPositionByTicket(const long ticket, SimPosition &out_pos) const;
   double              GetTotalFloatingProfit() const;
   double              GetTotalUsedMargin() const;

   // Closed trades history
   int                 GetClosedCount() const { return m_closed_count; }
   bool                GetClosedTrade(const int index, SimClosedTrade &out_trade) const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPositionManager::CPositionManager()
   : m_market_data(NULL),
     m_account_engine(NULL),
     m_count(0),
     m_ticket_generator(1000),
     m_closed_count(0)
{
   ZeroMemory(m_positions);
   ZeroMemory(m_closed_trades);
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPositionManager::~CPositionManager()
{
}

//+------------------------------------------------------------------+
//| Initialize position manager                                      |
//+------------------------------------------------------------------+
bool CPositionManager::Initialize(CMarketData *market_data, CAccountEngine *account_engine)
{
   m_market_data      = market_data;
   m_account_engine   = account_engine;
   ClearAll();
   return true;
}

//+------------------------------------------------------------------+
//| Clear all positions                                              |
//+------------------------------------------------------------------+
void CPositionManager::ClearAll()
{
   ZeroMemory(m_positions);
   ZeroMemory(m_closed_trades);
   m_count = 0;
   m_closed_count = 0;
}

//+------------------------------------------------------------------+
//| Add a newly executed position                                    |
//+------------------------------------------------------------------+
long CPositionManager::AddPosition(const string symbol, const ENUM_TRADE_DIRECTION dir, const double lots, const double open_price, const datetime open_time, const double sl, const double tp, const string comment, const string strategy)
{
   if (m_count >= SIM_MAX_POSITIONS || m_market_data == NULL || m_account_engine == NULL)
      return -1;

   m_ticket_generator++;
   long ticket = m_ticket_generator;

   double commission = lots * m_account_engine.GetCommissionPerLot();

   m_positions[m_count].ticket          = ticket;
   m_positions[m_count].symbol          = symbol;
   m_positions[m_count].direction       = dir;
   m_positions[m_count].lots            = lots;
   m_positions[m_count].open_price      = open_price;
   m_positions[m_count].open_time       = open_time;
   m_positions[m_count].sl              = sl;
   m_positions[m_count].tp              = tp;
   m_positions[m_count].current_price   = open_price;
   m_positions[m_count].commission      = commission;
   m_positions[m_count].swap            = 0.0;
   m_positions[m_count].floating_profit = 0.0;
   m_positions[m_count].net_profit      = -commission;
   m_positions[m_count].pips            = 0.0;
   m_positions[m_count].max_favorable   = 0.0;
   m_positions[m_count].max_adverse     = 0.0;
   m_positions[m_count].comment         = comment;
   m_positions[m_count].strategy_tag    = strategy;

   m_count++;

   // Deduct round-turn commission immediately
   m_account_engine.DeductCommission(commission);

   return ticket;
}

//+------------------------------------------------------------------+
//| Close a single position by ticket                                |
//+------------------------------------------------------------------+
bool CPositionManager::ClosePosition(const long ticket, const double close_price, const datetime close_time, const string reason, SimClosedTrade &out_closed)
{
   int found_idx = -1;
   for (int i = 0; i < m_count; i++)
   {
      if (m_positions[i].ticket == ticket)
      {
         found_idx = i;
         break;
      }
   }

   if (found_idx == -1 || m_market_data == NULL || m_account_engine == NULL)
      return false;

   SimPosition pos = m_positions[found_idx];

   double point        = m_market_data.GetPoint();
   double tick_val     = m_market_data.GetTickValue();
   double tick_size    = m_market_data.GetTickSize();

   double points_diff = (pos.direction == DIRECTION_BUY) ? (close_price - pos.open_price) / point
                                                         : (pos.open_price - close_price) / point;

   double gross_pnl = (points_diff * point / tick_size) * tick_val * pos.lots;
   double net_pnl   = gross_pnl - pos.commission - pos.swap;
   double pips      = points_diff / 10.0;

   // Calculate R-Multiple
   double sl_dist_points = (pos.sl > 0.0) ? MathAbs(pos.open_price - pos.sl) / point : 0.0;
   double risk_amount    = (sl_dist_points > 0.0) ? (sl_dist_points * point / tick_size) * tick_val * pos.lots : 0.0;
   double r_multiple     = (risk_amount > 0.0) ? (net_pnl / risk_amount) : 0.0;

   // Fill closed trade record
   out_closed.ticket          = pos.ticket;
   out_closed.symbol          = pos.symbol;
   out_closed.direction       = pos.direction;
   out_closed.lots            = pos.lots;
   out_closed.open_price      = pos.open_price;
   out_closed.close_price     = close_price;
   out_closed.open_time       = pos.open_time;
   out_closed.close_time      = close_time;
   out_closed.sl              = pos.sl;
   out_closed.tp              = pos.tp;
   out_closed.gross_profit    = NormalizeDouble(gross_pnl, 2);
   out_closed.commission      = pos.commission;
   out_closed.swap            = pos.swap;
   out_closed.net_profit      = NormalizeDouble(net_pnl, 2);
   out_closed.pips            = NormalizeDouble(pips, 1);
   out_closed.r_multiple      = NormalizeDouble(r_multiple, 2);
   out_closed.holding_seconds = (long)(close_time - pos.open_time);
   out_closed.mae_pips        = pos.max_adverse;
   out_closed.mfe_pips        = pos.max_favorable;
   out_closed.close_reason    = reason;
   out_closed.strategy_tag    = pos.strategy_tag;
   out_closed.notes           = "";

   // Save into history ring buffer
   if (m_closed_count < SIM_MAX_CLOSED_HISTORY)
   {
      m_closed_trades[m_closed_count] = out_closed;
      m_closed_count++;
   }
   else
   {
      // Shift left and append
      for (int h = 0; h < SIM_MAX_CLOSED_HISTORY - 1; h++)
         m_closed_trades[h] = m_closed_trades[h + 1];
      m_closed_trades[SIM_MAX_CLOSED_HISTORY - 1] = out_closed;
   }

   // Realize profit into virtual account
   m_account_engine.ApplyRealizedProfit(net_pnl);

   // Shift remaining positions
   for (int i = found_idx; i < m_count - 1; i++)
   {
      m_positions[i] = m_positions[i + 1];
   }
   m_count--;
   ZeroMemory(m_positions[m_count]);

   return true;
}

//+------------------------------------------------------------------+
//| Partial close a position                                         |
//+------------------------------------------------------------------+
bool CPositionManager::PartialClose(const long ticket, const double close_lots, const double close_price, const datetime close_time, SimClosedTrade &out_closed)
{
   for (int i = 0; i < m_count; i++)
   {
      if (m_positions[i].ticket == ticket)
      {
         if (close_lots >= m_positions[i].lots)
            return ClosePosition(ticket, close_price, close_time, "PARTIAL_100%", out_closed);

         double orig_lots = m_positions[i].lots;
         double rem_lots  = NormalizeDouble(orig_lots - close_lots, 2);

         // Close partial fraction
         m_positions[i].lots = close_lots;
         bool res = ClosePosition(ticket, close_price, close_time, "PARTIAL_CLOSE", out_closed);

         // Add back remainder with identical open price and entry time
         if (res && rem_lots > 0.0)
         {
            AddPosition(m_positions[i].symbol, m_positions[i].direction, rem_lots, m_positions[i].open_price, m_positions[i].open_time, m_positions[i].sl, m_positions[i].tp, m_positions[i].comment, m_positions[i].strategy_tag);
         }
         return res;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| Close all open positions                                         |
//+------------------------------------------------------------------+
void CPositionManager::CloseAll(const double bid_price, const double ask_price, const datetime close_time)
{
   while (m_count > 0)
   {
      double px = (m_positions[0].direction == DIRECTION_BUY) ? bid_price : ask_price;
      SimClosedTrade closed;
      ClosePosition(m_positions[0].ticket, px, close_time, "CLOSE_ALL", closed);
   }
}

//+------------------------------------------------------------------+
//| Modify SL and TP                                                 |
//+------------------------------------------------------------------+
bool CPositionManager::ModifySlTp(const long ticket, const double new_sl, const double new_tp)
{
   for (int i = 0; i < m_count; i++)
   {
      if (m_positions[i].ticket == ticket)
      {
         m_positions[i].sl = new_sl;
         m_positions[i].tp = new_tp;
         return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| Move Stop Loss to Breakeven (+ offset points)                    |
//+------------------------------------------------------------------+
bool CPositionManager::MoveToBreakeven(const long ticket, const double offset_points)
{
   if (m_market_data == NULL) return false;
   double point = m_market_data.GetPoint();

   for (int i = 0; i < m_count; i++)
   {
      if (m_positions[i].ticket == ticket)
      {
         double new_sl = (m_positions[i].direction == DIRECTION_BUY)
            ? m_positions[i].open_price + (offset_points * point)
            : m_positions[i].open_price - (offset_points * point);

         m_positions[i].sl = NormalizeDouble(new_sl, m_market_data.GetDigits());
         return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| Evaluate SL / TP and compute floating profits                    |
//+------------------------------------------------------------------+
void CPositionManager::UpdatePositions(const double bid_price, const double ask_price, const datetime current_time)
{
   if (m_market_data == NULL) return;

   double point     = m_market_data.GetPoint();
   double tick_val  = m_market_data.GetTickValue();
   double tick_size = m_market_data.GetTickSize();

   for (int i = m_count - 1; i >= 0; i--)
   {
      double cur_px = (m_positions[i].direction == DIRECTION_BUY) ? bid_price : ask_price;
      m_positions[i].current_price = cur_px;

      // Check Stop Loss Trigger
      if (m_positions[i].sl > 0.0)
      {
         if ((m_positions[i].direction == DIRECTION_BUY && bid_price <= m_positions[i].sl) ||
             (m_positions[i].direction == DIRECTION_SELL && ask_price >= m_positions[i].sl))
         {
            SimClosedTrade dummy;
            ClosePosition(m_positions[i].ticket, m_positions[i].sl, current_time, "STOP_LOSS", dummy);
            continue;
         }
      }

      // Check Take Profit Trigger
      if (m_positions[i].tp > 0.0)
      {
         if ((m_positions[i].direction == DIRECTION_BUY && bid_price >= m_positions[i].tp) ||
             (m_positions[i].direction == DIRECTION_SELL && ask_price <= m_positions[i].tp))
         {
            SimClosedTrade dummy;
            ClosePosition(m_positions[i].ticket, m_positions[i].tp, current_time, "TAKE_PROFIT", dummy);
            continue;
         }
      }

      // Compute Floating Pips and Profit
      double points_diff = (m_positions[i].direction == DIRECTION_BUY) ? (cur_px - m_positions[i].open_price) / point
                                                                      : (m_positions[i].open_price - cur_px) / point;
      double gross = (points_diff * point / tick_size) * tick_val * m_positions[i].lots;

      m_positions[i].floating_profit = NormalizeDouble(gross, 2);
      m_positions[i].net_profit      = NormalizeDouble(gross - m_positions[i].commission - m_positions[i].swap, 2);
      m_positions[i].pips            = NormalizeDouble(points_diff / 10.0, 1);

      // Track MAE / MFE
      if (m_positions[i].pips > m_positions[i].max_favorable)
         m_positions[i].max_favorable = m_positions[i].pips;
      if (m_positions[i].pips < m_positions[i].max_adverse)
         m_positions[i].max_adverse = m_positions[i].pips;
   }
}

//+------------------------------------------------------------------+
//| Get position by index                                            |
//+------------------------------------------------------------------+
bool CPositionManager::GetPositionByIndex(const int index, SimPosition &out_pos) const
{
   if (index < 0 || index >= m_count) return false;
   out_pos = m_positions[index];
   return true;
}

//+------------------------------------------------------------------+
//| Get position by ticket                                           |
//+------------------------------------------------------------------+
bool CPositionManager::GetPositionByTicket(const long ticket, SimPosition &out_pos) const
{
   for (int i = 0; i < m_count; i++)
   {
      if (m_positions[i].ticket == ticket)
      {
         out_pos = m_positions[i];
         return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| Sum of all open floating profit                                  |
//+------------------------------------------------------------------+
double CPositionManager::GetTotalFloatingProfit() const
{
   double sum = 0.0;
   for (int i = 0; i < m_count; i++)
   {
      sum += m_positions[i].floating_profit;
   }
   return sum;
}

//+------------------------------------------------------------------+
//| Sum of required margin across open positions                     |
//+------------------------------------------------------------------+
double CPositionManager::GetTotalUsedMargin() const
{
   if (m_account_engine == NULL) return 0.0;
   double sum = 0.0;
   for (int i = 0; i < m_count; i++)
   {
      sum += m_account_engine.CalculateRequiredMargin(m_positions[i].lots, m_positions[i].open_price);
   }
   return sum;
}

//+------------------------------------------------------------------+
//| Get closed trade by history index                                |
//+------------------------------------------------------------------+
bool CPositionManager::GetClosedTrade(const int index, SimClosedTrade &out_trade) const
{
   if (index < 0 || index >= m_closed_count) return false;
   out_trade = m_closed_trades[index];
   return true;
}

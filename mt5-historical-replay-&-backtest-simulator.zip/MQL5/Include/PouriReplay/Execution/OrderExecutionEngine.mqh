//+------------------------------------------------------------------+
//|                                         OrderExecutionEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Core/AccountEngine.mqh"
#include "../Core/MarketEngine.mqh"
#include "PositionManager.mqh"

//+------------------------------------------------------------------+
//| Class COrderExecutionEngine: Virtual Order Execution Pipeline   |
//+------------------------------------------------------------------+
class COrderExecutionEngine
{
private:
   CMarketData        *m_market_data;
   CMarketEngine      *m_market_engine;
   CAccountEngine     *m_account_engine;
   CPositionManager   *m_position_manager;

public:
   COrderExecutionEngine();
   ~COrderExecutionEngine();

   bool                Initialize(CMarketData *data, CMarketEngine *market, CAccountEngine *account, CPositionManager *positions);

   // Manual Market Execution
   long                ExecuteMarketBuy(const double lots, const double sl = 0.0, const double tp = 0.0, const string comment = "");
   long                ExecuteMarketSell(const double lots, const double sl = 0.0, const double tp = 0.0, const string comment = "");

   // Lot alignment to MT5 symbol specs
   double              NormalizeLotSize(const double requested_lots) const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
COrderExecutionEngine::COrderExecutionEngine()
   : m_market_data(NULL),
     m_market_engine(NULL),
     m_account_engine(NULL),
     m_position_manager(NULL)
{
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
COrderExecutionEngine::~COrderExecutionEngine()
{
}

//+------------------------------------------------------------------+
//| Initialize the execution engine                                  |
//+------------------------------------------------------------------+
bool COrderExecutionEngine::Initialize(CMarketData *data, CMarketEngine *market, CAccountEngine *account, CPositionManager *positions)
{
   if (data == NULL || market == NULL || account == NULL || positions == NULL)
      return false;

   m_market_data      = data;
   m_market_engine    = market;
   m_account_engine   = account;
   m_position_manager = positions;
   return true;
}

//+------------------------------------------------------------------+
//| Clamp & align lot size to MT5 symbol min/max/step                |
//+------------------------------------------------------------------+
double COrderExecutionEngine::NormalizeLotSize(const double requested_lots) const
{
   if (m_market_data == NULL) return requested_lots;

   double min_lot  = m_market_data.GetMinLot();
   double max_lot  = m_market_data.GetMaxLot();
   double step_lot = m_market_data.GetLotStep();

   double clamped = MathMax(min_lot, MathMin(max_lot, requested_lots));
   if (step_lot > 0.0)
   {
      clamped = MathFloor(clamped / step_lot) * step_lot;
   }
   return NormalizeDouble(clamped, 2);
}

//+------------------------------------------------------------------+
//| Execute manual BUY order at current simulated Ask                |
//+------------------------------------------------------------------+
long COrderExecutionEngine::ExecuteMarketBuy(const double lots, const double sl, const double tp, const string comment)
{
   if (m_market_data == NULL || m_market_engine == NULL || m_account_engine == NULL || m_position_manager == NULL)
      return -1;

   double norm_lots = NormalizeLotSize(lots);
   double ask       = m_market_engine.GetAsk();

   // Check margin adequacy
   if (!m_account_engine.HasSufficientMargin(norm_lots, ask))
   {
      PrintFormat("[OrderExecution] Error: Insufficient free margin for BUY %0.2f lots at %0.5f", norm_lots, ask);
      return -1;
   }

   // Apply realistic slippage
   double exec_price = m_market_engine.ApplySlippage(ask, DIRECTION_BUY, true);

   // Get current candle time
   MqlRates cur;
   m_market_engine.GetCurrentCandle(cur);

   long ticket = m_position_manager.AddPosition(m_market_data.GetSymbol(), DIRECTION_BUY, norm_lots, exec_price, cur.time, sl, tp, comment, "MANUAL_BUY");
   if (ticket > 0)
   {
      PrintFormat("[OrderExecution] Virtual BUY executed: Ticket #%d | %s | Lots: %0.2f | Price: %0.5f | SL: %0.5f | TP: %0.5f",
                  ticket, m_market_data.GetSymbol(), norm_lots, exec_price, sl, tp);
   }
   return ticket;
}

//+------------------------------------------------------------------+
//| Execute manual SELL order at current simulated Bid               |
//+------------------------------------------------------------------+
long COrderExecutionEngine::ExecuteMarketSell(const double lots, const double sl, const double tp, const string comment)
{
   if (m_market_data == NULL || m_market_engine == NULL || m_account_engine == NULL || m_position_manager == NULL)
      return -1;

   double norm_lots = NormalizeLotSize(lots);
   double bid       = m_market_engine.GetBid();

   // Check margin adequacy
   if (!m_account_engine.HasSufficientMargin(norm_lots, bid))
   {
      PrintFormat("[OrderExecution] Error: Insufficient free margin for SELL %0.2f lots at %0.5f", norm_lots, bid);
      return -1;
   }

   // Apply realistic slippage
   double exec_price = m_market_engine.ApplySlippage(bid, DIRECTION_SELL, true);

   // Get current candle time
   MqlRates cur;
   m_market_engine.GetCurrentCandle(cur);

   long ticket = m_position_manager.AddPosition(m_market_data.GetSymbol(), DIRECTION_SELL, norm_lots, exec_price, cur.time, sl, tp, comment, "MANUAL_SELL");
   if (ticket > 0)
   {
      PrintFormat("[OrderExecution] Virtual SELL executed: Ticket #%d | %s | Lots: %0.2f | Price: %0.5f | SL: %0.5f | TP: %0.5f",
                  ticket, m_market_data.GetSymbol(), norm_lots, exec_price, sl, tp);
   }
   return ticket;
}

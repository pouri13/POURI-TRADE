//+------------------------------------------------------------------+
//|                                               ReplayRenderer.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include <Canvas/Canvas.mqh>
#include "../Core/SimulationDefines.mqh"
#include "../Data/ReplayDataFeed.mqh"
#include "../Core/MarketEngine.mqh"
#include "../Execution/PositionManager.mqh"
#include "ReplayCandleRenderer.mqh"

#define COLOR_BID_LINE        0xFF3B82F6  // Dodger Blue
#define COLOR_ASK_LINE        0xFFEC4899  // Hot Pink
#define COLOR_SL_LINE         0xFFEF4444  // Coral Red
#define COLOR_TP_LINE         0xFF10B981  // Emerald Green
#define COLOR_ENTRY_BUY       0xFF065F46  // Deep Green
#define COLOR_ENTRY_SELL      0xFF881337  // Deep Red
#define COLOR_HUD_BG          0xCC111827  // Translucent Charcoal
#define COLOR_HUD_BORDER      0xFF374151
#define COLOR_WHITE           0xFFFFFFFF
#define COLOR_BADGE_WIN       0xFF059669
#define COLOR_BADGE_LOSS      0xFFDC2626

//+------------------------------------------------------------------+
//| Class CReplayRenderer: Master Replay Visualizer                  |
//| Renders candles, live quotes, SL/TP levels, entry/exit markers,  |
//| and telemetry HUD directly onto the high-performance CCanvas.    |
//+------------------------------------------------------------------+
class CReplayRenderer
{
private:
   CReplayDataFeed       *m_feed;
   CMarketEngine         *m_market;
   CPositionManager      *m_positions;
   CReplayCandleRenderer  m_candle_renderer;

   int                    m_vx;
   int                    m_vy;
   int                    m_vw;
   int                    m_vh;
   int                    m_axis_w;
   int                    m_axis_h;

public:
   CReplayRenderer();
   ~CReplayRenderer();

   bool                   Initialize(CReplayDataFeed *feed, CMarketEngine *market, CPositionManager *positions);
   void                   SetViewport(const int x, const int y, const int w, const int h);

   // Delegated Viewport Controls
   void                   ZoomIn()  { m_candle_renderer.ZoomIn(); }
   void                   ZoomOut() { m_candle_renderer.ZoomOut(); }
   void                   ScrollLeft(const int bars = 5)  { m_candle_renderer.ScrollLeft(bars); }
   void                   ScrollRight(const int bars = 5) { m_candle_renderer.ScrollRight(bars); }
   void                   ResetScroll() { m_candle_renderer.ResetScroll(); }

   // Main Frame Render Call
   void                   Render(CCanvas &canvas, const string symbol, const ENUM_TIMEFRAMES period, const ENUM_REPLAY_SPEED speed, const ENUM_REPLAY_STATE state);

private:
   void                   RenderQuotesAndSpread(CCanvas &canvas);
   void                   RenderActiveTrades(CCanvas &canvas);
   void                   RenderClosedTrades(CCanvas &canvas);
   void                   RenderHudHeader(CCanvas &canvas, const string symbol, const ENUM_TIMEFRAMES period, const ENUM_REPLAY_SPEED speed, const ENUM_REPLAY_STATE state);
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CReplayRenderer::CReplayRenderer()
   : m_feed(NULL),
     m_market(NULL),
     m_positions(NULL),
     m_vx(0),
     m_vy(0),
     m_vw(800),
     m_vh(500),
     m_axis_w(68),
     m_axis_h(24)
{
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CReplayRenderer::~CReplayRenderer()
{
}

//+------------------------------------------------------------------+
//| Initialize dependencies                                          |
//+------------------------------------------------------------------+
bool CReplayRenderer::Initialize(CReplayDataFeed *feed, CMarketEngine *market, CPositionManager *positions)
{
   if (feed == NULL || market == NULL || positions == NULL)
      return false;

   m_feed      = feed;
   m_market    = market;
   m_positions = positions;

   m_candle_renderer.Initialize(m_feed);
   m_candle_renderer.SetViewport(m_vx, m_vy, m_vw, m_vh, m_axis_w, m_axis_h);
   return true;
}

//+------------------------------------------------------------------+
//| Configure viewport geometry                                      |
//+------------------------------------------------------------------+
void CReplayRenderer::SetViewport(const int x, const int y, const int w, const int h)
{
   m_vx = x;
   m_vy = y;
   m_vw = w;
   m_vh = h;
   m_candle_renderer.SetViewport(x, y, w, h, m_axis_w, m_axis_h);
}

//+------------------------------------------------------------------+
//| Render Complete Replay Frame onto CCanvas                        |
//+------------------------------------------------------------------+
void CReplayRenderer::Render(CCanvas &canvas, const string symbol, const ENUM_TIMEFRAMES period, const ENUM_REPLAY_SPEED speed, const ENUM_REPLAY_STATE state)
{
   // 1. Render historical candle chart up to current replay index
   m_candle_renderer.Render(canvas);

   // 2. Render Bid, Ask, Spread and current price levels
   RenderQuotesAndSpread(canvas);

   // 3. Render active positions, Entry markers, SL/TP lines
   RenderActiveTrades(canvas);

   // 4. Render closed trade exit markers
   RenderClosedTrades(canvas);

   // 5. Render HUD telemetry header
   RenderHudHeader(canvas, symbol, period, speed, state);
}

//+------------------------------------------------------------------+
//| Render Bid/Ask horizontal levels and spread indicator            |
//+------------------------------------------------------------------+
void CReplayRenderer::RenderQuotesAndSpread(CCanvas &canvas)
{
   if (m_market == NULL) return;

   double bid = m_market.GetBid();
   double ask = m_market.GetAsk();
   int spread = m_market.GetSpreadPoints();

   int plot_w = m_vw - m_axis_w;
   int y_bid  = m_candle_renderer.PriceToY(bid);
   int y_ask  = m_candle_renderer.PriceToY(ask);

   // Draw Bid Line (dashed effect)
   for (int x = m_vx; x < m_vx + plot_w; x += 8)
   {
      canvas.Line(x, y_bid, MathMin(x + 5, m_vx + plot_w), y_bid, COLOR_BID_LINE);
   }

   // Draw Ask Line (dotted effect)
   for (int x = m_vx; x < m_vx + plot_w; x += 6)
   {
      canvas.Line(x, y_ask, MathMin(x + 3, m_vx + plot_w), y_ask, COLOR_ASK_LINE);
   }

   // Badges on Price Axis
   canvas.FontSet("Arial", 8, FW_BOLD);

   // Bid badge
   canvas.FillRectangle(m_vx + plot_w + 1, y_bid - 7, m_vx + m_vw - 1, y_bid + 7, COLOR_BID_LINE);
   canvas.TextOut(m_vx + plot_w + 4, y_bid - 5, DoubleToString(bid, 2), COLOR_WHITE);

   // Ask badge
   canvas.FillRectangle(m_vx + plot_w + 1, y_ask - 7, m_vx + m_vw - 1, y_ask + 7, COLOR_ASK_LINE);
   canvas.TextOut(m_vx + plot_w + 4, y_ask - 5, DoubleToString(ask, 2), COLOR_WHITE);

   // Spread badge in upper right corner of plot
   string sp_str = StringFormat("Spread: %d pts", spread);
   int sp_w = 90;
   int sp_x = m_vx + plot_w - sp_w - 10;
   int sp_y = m_vy + 12;
   canvas.FillRectangle(sp_x, sp_y, sp_x + sp_w, sp_y + 18, 0xDD1F2937);
   canvas.Rectangle(sp_x, sp_y, sp_x + sp_w, sp_y + 18, 0xFF4B5563);
   canvas.TextOut(sp_x + 8, sp_y + 3, sp_str, 0xFFE5E7EB);
}

//+------------------------------------------------------------------+
//| Render active virtual trades, Entry price, SL/TP lines & badges  |
//+------------------------------------------------------------------+
void CReplayRenderer::RenderActiveTrades(CCanvas &canvas)
{
   if (m_positions == NULL || m_feed == NULL) return;

   int count = m_positions.GetCount();
   int plot_w = m_vw - m_axis_w;

   canvas.FontSet("Arial", 8, FW_NORMAL);

   for (int i = 0; i < count; i++)
   {
      SimPosition pos;
      if (!m_positions.GetPositionByIndex(i, pos))
         continue;

      int y_open = m_candle_renderer.PriceToY(pos.open_price);
      uint line_clr = (pos.direction == DIRECTION_BUY) ? 0xFF059669 : 0xFFDC2626;

      // 1. Entry level dashed line across plot
      for (int x = m_vx; x < m_vx + plot_w; x += 10)
      {
         canvas.Line(x, y_open, MathMin(x + 6, m_vx + plot_w), y_open, line_clr);
      }

      // 2. Position badge on left side
      string dir_txt = (pos.direction == DIRECTION_BUY) ? "BUY" : "SELL";
      string pnl_txt = StringFormat("#%d %s %0.2f (%+0.2f)", pos.ticket, dir_txt, pos.lots, pos.net_profit);
      uint badge_clr = (pos.net_profit >= 0.0) ? COLOR_BADGE_WIN : COLOR_BADGE_LOSS;

      canvas.FillRectangle(m_vx + 10, y_open - 8, m_vx + 175, y_open + 8, badge_clr);
      canvas.Rectangle(m_vx + 10, y_open - 8, m_vx + 175, y_open + 8, COLOR_WHITE);
      canvas.TextOut(m_vx + 15, y_open - 6, pnl_txt, COLOR_WHITE);

      // 3. Stop Loss line & label
      if (pos.sl > 0.0)
      {
         int y_sl = m_candle_renderer.PriceToY(pos.sl);
         for (int x = m_vx; x < m_vx + plot_w; x += 8)
         {
            canvas.Line(x, y_sl, MathMin(x + 4, m_vx + plot_w), y_sl, COLOR_SL_LINE);
         }
         canvas.FillRectangle(m_vx + 10, y_sl - 7, m_vx + 65, y_sl + 7, COLOR_SL_LINE);
         canvas.TextOut(m_vx + 15, y_sl - 5, "SL", COLOR_WHITE);
      }

      // 4. Take Profit line & label
      if (pos.tp > 0.0)
      {
         int y_tp = m_candle_renderer.PriceToY(pos.tp);
         for (int x = m_vx; x < m_vx + plot_w; x += 8)
         {
            canvas.Line(x, y_tp, MathMin(x + 4, m_vx + plot_w), y_tp, COLOR_TP_LINE);
         }
         canvas.FillRectangle(m_vx + 10, y_tp - 7, m_vx + 65, y_tp + 7, COLOR_TP_LINE);
         canvas.TextOut(m_vx + 15, y_tp - 5, "TP", COLOR_WHITE);
      }
   }
}

//+------------------------------------------------------------------+
//| Render historical exit markers for closed trades in visible range|
//+------------------------------------------------------------------+
void CReplayRenderer::RenderClosedTrades(CCanvas &canvas)
{
   if (m_positions == NULL) return;

   int closed_cnt = m_positions.GetClosedCount();
   if (closed_cnt <= 0) return;

   canvas.FontSet("Arial", 8, FW_NORMAL);

   // Show recent closed trades
   int show_max = MathMin(closed_cnt, 15);
   for (int i = closed_cnt - 1; i >= closed_cnt - show_max; i--)
   {
      SimClosedTrade ct;
      if (!m_positions.GetClosedTrade(i, ct))
         continue;

      // Check if exit price is within visible price range
      if (ct.close_price >= m_candle_renderer.GetViewMinPrice() && ct.close_price <= m_candle_renderer.GetViewMaxPrice())
      {
         int y_exit = m_candle_renderer.PriceToY(ct.close_price);
         // Render exit badge along right edge of plot
         int plot_w = m_vw - m_axis_w;
         int bx = m_vx + plot_w - 110;
         int by = MathMax(m_vy + 40, MathMin(m_vy + m_vh - 40, y_exit - 8));

         uint clr = (ct.net_profit >= 0.0) ? 0xDD065F46 : 0xDD881337;
         canvas.FillRectangle(bx, by, bx + 100, by + 16, clr);
         canvas.Rectangle(bx, by, bx + 100, by + 16, (ct.net_profit >= 0.0) ? 0xFF10B981 : 0xFFEF4444);

         string txt = StringFormat("Exit %+0.2f (%s)", ct.net_profit, ct.close_reason);
         canvas.TextOut(bx + 4, by + 2, txt, COLOR_WHITE);
      }
   }
}

//+------------------------------------------------------------------+
//| Render HUD Telemetry Header (Symbol, Timeframe, Date/Time, Speed)|
//+------------------------------------------------------------------+
void CReplayRenderer::RenderHudHeader(CCanvas &canvas, const string symbol, const ENUM_TIMEFRAMES period, const ENUM_REPLAY_SPEED speed, const ENUM_REPLAY_STATE state)
{
   datetime cur_time = (m_feed != NULL) ? m_feed.GetCurrentTime() : 0;

   string speed_str = "1.0x";
   switch (speed)
   {
      case SPEED_0_1X:  speed_str = "0.10x"; break;
      case SPEED_0_25X: speed_str = "0.25x"; break;
      case SPEED_0_5X:  speed_str = "0.50x"; break;
      case SPEED_1X:    speed_str = "1.00x"; break;
      case SPEED_2X:    speed_str = "2.00x"; break;
      case SPEED_5X:    speed_str = "5.00x"; break;
      case SPEED_10X:   speed_str = "10.0x"; break;
      case SPEED_25X:   speed_str = "25.0x"; break;
      case SPEED_50X:   speed_str = "50.0x"; break;
      case SPEED_100X:  speed_str = "100x";  break;
   }

   string state_str = (state == REPLAY_STATE_RUNNING) ? "[PLAYING]" : "[PAUSED]";
   uint state_clr   = (state == REPLAY_STATE_RUNNING) ? 0xFF10B981   : 0xFFF59E0B;

   string tf_str = EnumToString(period);
   StringReplace(tf_str, "PERIOD_", "");

   int hud_w = 460;
   int hud_h = 26;
   int hud_x = m_vx + 10;
   int hud_y = m_vy + 10;

   canvas.FillRectangle(hud_x, hud_y, hud_x + hud_w, hud_y + hud_h, COLOR_HUD_BG);
   canvas.Rectangle(hud_x, hud_y, hud_x + hud_w, hud_y + hud_h, COLOR_HUD_BORDER);

   canvas.FontSet("Arial", 9, FW_BOLD);
   canvas.TextOut(hud_x + 10, hud_y + 6, state_str, state_clr);

   canvas.FontSet("Arial", 9, FW_NORMAL);
   string info = StringFormat("%s (%s)  |  %s  |  Speed: %s",
                              symbol, tf_str, TimeToString(cur_time, TIME_DATE | TIME_MINUTES), speed_str);
   canvas.TextOut(hud_x + 85, hud_y + 6, info, 0xFFE2E8F0);
}

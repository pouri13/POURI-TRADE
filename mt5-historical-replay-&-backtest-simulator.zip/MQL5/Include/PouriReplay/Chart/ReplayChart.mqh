//+------------------------------------------------------------------+
//|                                                  ReplayChart.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include <Canvas/Canvas.mqh>
#include "../Core/SimulationDefines.mqh"
#include "../Data/ReplayDataFeed.mqh"
#include "../Core/MarketEngine.mqh"
#include "../Execution/PositionManager.mqh"
#include "../Core/ReplayEngine.mqh"
#include "ReplayRenderer.mqh"

#define CANVAS_OBJ_NAME "POURI_REPLAY_CANVAS"

//+------------------------------------------------------------------+
//| Class CReplayChart: Native MT5 Chart Integration & Surface       |
//| Replaces the native MT5 chart display with a high-performance    |
//| CCanvas surface that strictly renders progressive replay data.   |
//+------------------------------------------------------------------+
class CReplayChart
{
private:
   long              m_chart_id;
   CCanvas           m_canvas;
   CReplayDataFeed  *m_feed;
   CMarketEngine    *m_market;
   CPositionManager *m_positions;
   CReplayEngine    *m_replay;
   CReplayRenderer   m_renderer;

   int               m_width;
   int               m_height;
   bool              m_is_created;

   // Interactive mouse dragging state
   bool              m_is_dragging;
   int               m_drag_start_x;

public:
   CReplayChart();
   ~CReplayChart();

   bool              Initialize(const long chart_id, CReplayDataFeed *feed, CMarketEngine *market, CPositionManager *positions, CReplayEngine *replay);
   void              Destroy();

   // Layout and viewport resizing
   void              UpdateLayout(const int x, const int y, const int w, const int h);
   void              Redraw();

   // Event handling
   bool              OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam);

   // Direct controls
   void              ZoomIn()  { m_renderer.ZoomIn();  Redraw(); }
   void              ZoomOut() { m_renderer.ZoomOut(); Redraw(); }
   void              ScrollLeft(const int bars = 5)  { m_renderer.ScrollLeft(bars);  Redraw(); }
   void              ScrollRight(const int bars = 5) { m_renderer.ScrollRight(bars); Redraw(); }
   void              ResetScroll() { m_renderer.ResetScroll(); Redraw(); }

private:
   void              ApplyNativeChartMasking();
   void              RestoreNativeChart();
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CReplayChart::CReplayChart()
   : m_chart_id(0),
     m_feed(NULL),
     m_market(NULL),
     m_positions(NULL),
     m_replay(NULL),
     m_width(1000),
     m_height(600),
     m_is_created(false),
     m_is_dragging(false),
     m_drag_start_x(0)
{
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CReplayChart::~CReplayChart()
{
   Destroy();
}

//+------------------------------------------------------------------+
//| Initialize Replay Chart Canvas and hide native MT5 future candles|
//+------------------------------------------------------------------+
bool CReplayChart::Initialize(const long chart_id, CReplayDataFeed *feed, CMarketEngine *market, CPositionManager *positions, CReplayEngine *replay)
{
   m_chart_id  = (chart_id == 0) ? ChartID() : chart_id;
   m_feed      = feed;
   m_market    = market;
   m_positions = positions;
   m_replay    = replay;

   // 1. Mask native MT5 chart so future bars are never visible
   ApplyNativeChartMasking();

   // 2. Query initial chart pixel dimensions
   m_width  = (int)ChartGetInteger(m_chart_id, CHART_WIDTH_IN_PIXELS, 0);
   m_height = (int)ChartGetInteger(m_chart_id, CHART_HEIGHT_IN_PIXELS, 0);
   if (m_width <= 0)  m_width  = 1200;
   if (m_height <= 0) m_height = 800;

   // 3. Create CCanvas bitmap label
   if (!m_canvas.CreateBitmapLabel(CANVAS_OBJ_NAME, 0, 0, m_width, m_height, COLOR_FORMAT_ARGB_RAW))
   {
      Print("[ReplayChart] Failed to create CCanvas bitmap object.");
      return false;
   }

   m_is_created = true;
   m_renderer.Initialize(m_feed, m_market, m_positions);
   m_renderer.SetViewport(0, 0, m_width, m_height);

   Redraw();
   return true;
}

//+------------------------------------------------------------------+
//| Destroy Canvas and restore settings                              |
//+------------------------------------------------------------------+
void CReplayChart::Destroy()
{
   if (m_is_created)
   {
      m_canvas.Destroy();
      m_is_created = false;
   }
   RestoreNativeChart();
}

//+------------------------------------------------------------------+
//| Mask native MT5 chart to prevent native future candles rendering |
//+------------------------------------------------------------------+
void CReplayChart::ApplyNativeChartMasking()
{
   ChartSetInteger(m_chart_id, CHART_AUTOSCROLL, false);
   ChartSetInteger(m_chart_id, CHART_SHIFT, false);

   // Turn off native price bars/candles by switching to transparent line mode
   ChartSetInteger(m_chart_id, CHART_MODE, CHART_LINE);
   ChartSetInteger(m_chart_id, CHART_COLOR_CHART_LINE, clrNONE);
   ChartSetInteger(m_chart_id, CHART_COLOR_CHART_UP, clrNONE);
   ChartSetInteger(m_chart_id, CHART_COLOR_CHART_DOWN, clrNONE);
   ChartSetInteger(m_chart_id, CHART_COLOR_CANDLE_BULL, clrNONE);
   ChartSetInteger(m_chart_id, CHART_COLOR_CANDLE_BEAR, clrNONE);
   ChartSetInteger(m_chart_id, CHART_COLOR_BACKGROUND, C'15,17,21');
   ChartSetInteger(m_chart_id, CHART_COLOR_GRID, clrNONE);
   ChartSetInteger(m_chart_id, CHART_SHOW_GRID, false);
   ChartSetInteger(m_chart_id, CHART_SHOW_PERIOD_SEP, false);

   ChartRedraw(m_chart_id);
}

//+------------------------------------------------------------------+
//| Restore standard chart view                                      |
//+------------------------------------------------------------------+
void CReplayChart::RestoreNativeChart()
{
   ChartSetInteger(m_chart_id, CHART_MODE, CHART_CANDLES);
   ChartSetInteger(m_chart_id, CHART_COLOR_BACKGROUND, C'15,17,21');
   ChartSetInteger(m_chart_id, CHART_COLOR_CHART_UP, C'16,185,129');
   ChartSetInteger(m_chart_id, CHART_COLOR_CHART_DOWN, C'239,68,68');
   ChartSetInteger(m_chart_id, CHART_SHOW_GRID, true);
   ChartRedraw(m_chart_id);
}

//+------------------------------------------------------------------+
//| Update canvas geometry when layout or chart size changes         |
//+------------------------------------------------------------------+
void CReplayChart::UpdateLayout(const int x, const int y, const int w, const int h)
{
   if (!m_is_created) return;

   int new_w = MathMax(200, w);
   int new_h = MathMax(150, h);

   if (new_w != m_width || new_h != m_height)
   {
      m_width  = new_w;
      m_height = new_h;
      m_canvas.Resize(m_width, m_height);
   }

   m_renderer.SetViewport(x, y, m_width, m_height);
   Redraw();
}

//+------------------------------------------------------------------+
//| Redraw complete replay canvas                                    |
//+------------------------------------------------------------------+
void CReplayChart::Redraw()
{
   if (!m_is_created || m_replay == NULL) return;

   ENUM_REPLAY_SPEED speed = m_replay.GetSpeed();
   ENUM_REPLAY_STATE state = m_replay.GetState();

   m_renderer.Render(m_canvas, _Symbol, _Period, speed, state);
   m_canvas.Update();
}

//+------------------------------------------------------------------+
//| Handle Chart Events (mouse drag, keyboard shortcuts)             |
//+------------------------------------------------------------------+
bool CReplayChart::OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if (!m_is_created) return false;

   // 1. Chart resize event
   if (id == CHARTEVENT_CHART_CHANGE)
   {
      int cur_w = (int)ChartGetInteger(m_chart_id, CHART_WIDTH_IN_PIXELS, 0);
      int cur_h = (int)ChartGetInteger(m_chart_id, CHART_HEIGHT_IN_PIXELS, 0);
      if (cur_w > 0 && cur_h > 0 && (cur_w != m_width || cur_h != m_height))
      {
         UpdateLayout(0, 0, cur_w, cur_h);
         return true;
      }
   }

   // 2. Keyboard shortcuts
   if (id == CHARTEVENT_KEYDOWN)
   {
      // '+' or '=' to zoom in
      if (lparam == 187 || lparam == 107 || lparam == 61)
      {
         ZoomIn();
         return true;
      }
      // '-' or '_' to zoom out
      if (lparam == 189 || lparam == 109 || lparam == 45)
      {
         ZoomOut();
         return true;
      }
      // Left arrow: scroll back into past
      if (lparam == 37)
      {
         ScrollLeft(3);
         return true;
      }
      // Right arrow: scroll forward towards active candle
      if (lparam == 39)
      {
         ScrollRight(3);
         return true;
      }
   }

   return false;
}

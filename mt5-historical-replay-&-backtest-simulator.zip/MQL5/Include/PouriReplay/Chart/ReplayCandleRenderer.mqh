//+------------------------------------------------------------------+
//|                                         ReplayCandleRenderer.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include <Canvas/Canvas.mqh>
#include "../Core/SimulationDefines.mqh"
#include "../Data/ReplayDataFeed.mqh"

#define COLOR_CANVAS_BG       0xFF0F1115
#define COLOR_CANVAS_GRID     0xFF1E2530
#define COLOR_CANVAS_AXIS     0xFF272F3D
#define COLOR_CANVAS_TEXT     0xFF94A3B8
#define COLOR_CANVAS_TEXT_DIM 0xFF64748B
#define COLOR_CANDLE_BULL     0xFF10B981
#define COLOR_CANDLE_BEAR     0xFFEF4444
#define COLOR_WICK_BULL       0xFF059669
#define COLOR_WICK_BEAR       0xFFDC2626

//+------------------------------------------------------------------+
//| Class CReplayCandleRenderer: Zero-Lookahead CCanvas Engine       |
//| Renders historical candles [0 .. current_replay_index] directly  |
//| into a high-performance bitmap canvas buffer without chart spam. |
//+------------------------------------------------------------------+
class CReplayCandleRenderer
{
private:
   CReplayDataFeed *m_feed;
   int              m_bar_width;
   int              m_bar_gap;
   int              m_scroll_offset;    // 0 = current replay candle anchored at right
   double           m_view_min_price;
   double           m_view_max_price;

   // Viewport boundaries
   int              m_chart_x;
   int              m_chart_y;
   int              m_chart_w;
   int              m_chart_h;
   int              m_axis_w;           // Right price axis width (pixels)
   int              m_axis_h;           // Bottom time axis height (pixels)

public:
   CReplayCandleRenderer();
   ~CReplayCandleRenderer();

   void             Initialize(CReplayDataFeed *feed);
   void             SetViewport(const int x, const int y, const int w, const int h, const int axis_w = 65, const int axis_h = 24);

   // Zoom & Pan controls
   void             ZoomIn();
   void             ZoomOut();
   void             ScrollLeft(const int bars = 5);
   void             ScrollRight(const int bars = 5);
   void             ResetScroll() { m_scroll_offset = 0; }

   // Main rendering execution onto CCanvas
   void             Render(CCanvas &canvas);

   // Coordinate conversion helpers
   int              PriceToY(const double price) const;
   double           YToPrice(const int y) const;
   int              BarOffsetToX(const int offset_from_current) const;
   double           GetViewMinPrice() const { return m_view_min_price; }
   double           GetViewMaxPrice() const { return m_view_max_price; }
   int              GetBarWidth() const { return m_bar_width; }
   int              GetBarGap() const { return m_bar_gap; }
   int              GetScrollOffset() const { return m_scroll_offset; }

private:
   void             RenderBackgroundAndGrid(CCanvas &canvas);
   void             RenderPriceAxis(CCanvas &canvas);
   void             RenderCandles(CCanvas &canvas);
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CReplayCandleRenderer::CReplayCandleRenderer()
   : m_feed(NULL),
     m_bar_width(7),
     m_bar_gap(3),
     m_scroll_offset(0),
     m_view_min_price(0.0),
     m_view_max_price(1.0),
     m_chart_x(0),
     m_chart_y(0),
     m_chart_w(800),
     m_chart_h(500),
     m_axis_w(65),
     m_axis_h(24)
{
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CReplayCandleRenderer::~CReplayCandleRenderer()
{
}

//+------------------------------------------------------------------+
//| Initialize with authoritative guarded data feed                  |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::Initialize(CReplayDataFeed *feed)
{
   m_feed = feed;
}

//+------------------------------------------------------------------+
//| Set viewport rectangle on canvas                                 |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::SetViewport(const int x, const int y, const int w, const int h, const int axis_w, const int axis_h)
{
   m_chart_x = x;
   m_chart_y = y;
   m_chart_w = MathMax(200, w);
   m_chart_h = MathMax(150, h);
   m_axis_w  = axis_w;
   m_axis_h  = axis_h;
}

//+------------------------------------------------------------------+
//| Increase zoom level                                              |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::ZoomIn()
{
   if (m_bar_width < 19)
   {
      m_bar_width += 2;
      m_bar_gap   = MathMax(1, m_bar_width / 3);
   }
}

//+------------------------------------------------------------------+
//| Decrease zoom level                                              |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::ZoomOut()
{
   if (m_bar_width > 3)
   {
      m_bar_width -= 2;
      m_bar_gap   = MathMax(1, m_bar_width / 3);
   }
}

//+------------------------------------------------------------------+
//| Pan viewport back into past historical data                      |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::ScrollLeft(const int bars)
{
   if (m_feed == NULL) return;
   int max_avail = m_feed.GetAvailableBarCount();
   m_scroll_offset = MathMin(m_scroll_offset + bars, MathMax(0, max_avail - 10));
}

//+------------------------------------------------------------------+
//| Pan viewport forward toward current replay bar (never past 0!)   |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::ScrollRight(const int bars)
{
   // STRICT BARRIER: Cannot scroll past current replay bar into the future!
   m_scroll_offset = MathMax(0, m_scroll_offset - bars);
}

//+------------------------------------------------------------------+
//| Convert price to Y pixel in viewport                             |
//+------------------------------------------------------------------+
int CReplayCandleRenderer::PriceToY(const double price) const
{
   if (m_view_max_price <= m_view_min_price) return m_chart_y + (m_chart_h - m_axis_h) / 2;
   double range = m_view_max_price - m_view_min_price;
   int usable_h = m_chart_h - m_axis_h;
   int py = m_chart_y + (int)((m_view_max_price - price) / range * usable_h);
   return MathMax(m_chart_y, MathMin(m_chart_y + usable_h, py));
}

//+------------------------------------------------------------------+
//| Convert Y pixel to price in viewport                             |
//+------------------------------------------------------------------+
double CReplayCandleRenderer::YToPrice(const int y) const
{
   int usable_h = m_chart_h - m_axis_h;
   if (usable_h <= 0) return m_view_min_price;
   double ratio = (double)(y - m_chart_y) / (double)usable_h;
   return m_view_max_price - ratio * (m_view_max_price - m_view_min_price);
}

//+------------------------------------------------------------------+
//| Convert relative bar offset to X pixel (0 = current replay bar)  |
//+------------------------------------------------------------------+
int CReplayCandleRenderer::BarOffsetToX(const int offset_from_current) const
{
   int plot_w   = m_chart_w - m_axis_w;
   int step     = m_bar_width + m_bar_gap;
   int anchor_x = m_chart_x + plot_w - (m_bar_width + 10);
   int shift    = (offset_from_current - m_scroll_offset) * step;
   return anchor_x - shift;
}

//+------------------------------------------------------------------+
//| Main Render Loop                                                 |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::Render(CCanvas &canvas)
{
   if (m_feed == NULL) return;

   int available_bars = m_feed.GetAvailableBarCount();
   if (available_bars <= 0) return;

   int plot_w = m_chart_w - m_axis_w;
   int step   = m_bar_width + m_bar_gap;
   int max_visible_bars = (plot_w / step) + 2;

   // 1. Calculate price High/Low range strictly across visible window
   double hi = -DBL_MAX;
   double lo =  DBL_MAX;

   for (int i = 0; i < max_visible_bars; i++)
   {
      int offset = m_scroll_offset + i;
      MqlRates rate;
      if (m_feed.GetBarByOffset(offset, rate))
      {
         if (rate.high > hi) hi = rate.high;
         if (rate.low  < lo) lo = rate.low;
      }
   }

   if (hi > -DBL_MAX && lo < DBL_MAX && hi > lo)
   {
      double pad = (hi - lo) * 0.06; // 6% headroom and footroom
      m_view_max_price = hi + pad;
      m_view_min_price = lo - pad;
   }

   // 2. Draw background, grid, and coordinate frames
   RenderBackgroundAndGrid(canvas);

   // 3. Draw Price Scale and horizontal grid lines
   RenderPriceAxis(canvas);

   // 4. Draw Candlesticks and wicks (Guaranteed ZERO lookahead)
   RenderCandles(canvas);
}

//+------------------------------------------------------------------+
//| Render background fill, bounding frame, and vertical date grid   |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::RenderBackgroundAndGrid(CCanvas &canvas)
{
   int plot_w = m_chart_w - m_axis_w;
   int plot_h = m_chart_h - m_axis_h;

   // Main plot background
   canvas.FillRectangle(m_chart_x, m_chart_y, m_chart_x + plot_w, m_chart_y + plot_h, COLOR_CANVAS_BG);

   // Axis backgrounds
   canvas.FillRectangle(m_chart_x + plot_w, m_chart_y, m_chart_x + m_chart_w, m_chart_y + m_chart_h, 0xFF141820);
   canvas.FillRectangle(m_chart_x, m_chart_y + plot_h, m_chart_x + plot_w, m_chart_y + m_chart_h, 0xFF141820);

   // Outer border lines
   canvas.Line(m_chart_x + plot_w, m_chart_y, m_chart_x + plot_w, m_chart_y + plot_h, COLOR_CANVAS_AXIS);
   canvas.Line(m_chart_x, m_chart_y + plot_h, m_chart_x + plot_w, m_chart_y + plot_h, COLOR_CANVAS_AXIS);
}

//+------------------------------------------------------------------+
//| Render horizontal grid lines and price axis labels               |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::RenderPriceAxis(CCanvas &canvas)
{
   int plot_w = m_chart_w - m_axis_w;
   int plot_h = m_chart_h - m_axis_h;
   int steps  = 6;

   canvas.FontSet("Arial", 9, FW_NORMAL);

   for (int s = 0; s <= steps; s++)
   {
      double ratio = (double)s / (double)steps;
      int y = m_chart_y + (int)(ratio * (plot_h - 20)) + 10;
      double px = YToPrice(y);

      // Grid line
      canvas.Line(m_chart_x, y, m_chart_x + plot_w, y, COLOR_CANVAS_GRID);

      // Price label on right axis
      string label = DoubleToString(px, 2);
      canvas.TextOut(m_chart_x + plot_w + 6, y - 6, label, COLOR_CANVAS_TEXT);
   }
}

//+------------------------------------------------------------------+
//| Progressively render candles up to current replay index          |
//+------------------------------------------------------------------+
void CReplayCandleRenderer::RenderCandles(CCanvas &canvas)
{
   int plot_w = m_chart_w - m_axis_w;
   int plot_h = m_chart_h - m_axis_h;
   int step   = m_bar_width + m_bar_gap;
   int max_visible_bars = (plot_w / step) + 2;

   // Render from right (newest visible) to left (oldest visible)
   for (int i = 0; i < max_visible_bars; i++)
   {
      int offset = m_scroll_offset + i;
      MqlRates rate;

      // STRICT ZERO LOOKAHEAD: Feed strictly denies any future candle
      if (!m_feed.GetBarByOffset(offset, rate))
         continue;

      int cx = BarOffsetToX(offset);
      if (cx + m_bar_width < m_chart_x || cx > m_chart_x + plot_w)
         continue;

      int y_open  = PriceToY(rate.open);
      int y_close = PriceToY(rate.close);
      int y_high  = PriceToY(rate.high);
      int y_low   = PriceToY(rate.low);

      bool is_bull = (rate.close >= rate.open);
      uint candle_color = is_bull ? COLOR_CANDLE_BULL : COLOR_CANDLE_BEAR;
      uint wick_color   = is_bull ? COLOR_WICK_BULL   : COLOR_WICK_BEAR;

      int mid_x = cx + m_bar_width / 2;

      // 1. Upper and lower wicks
      canvas.Line(mid_x, y_high, mid_x, y_low, wick_color);

      // 2. Candlestick body
      int top_body = MathMin(y_open, y_close);
      int bot_body = MathMax(y_open, y_close);
      if (bot_body - top_body < 1) bot_body = top_body + 1; // At least 1px for doji

      canvas.FillRectangle(cx, top_body, cx + m_bar_width - 1, bot_body, candle_color);

      // Render periodic time stamp tick on bottom axis
      if (i % 8 == 0)
      {
         string t_str = TimeToString(rate.time, TIME_MINUTES);
         canvas.TextOut(cx - 12, m_chart_y + plot_h + 5, t_str, COLOR_CANVAS_TEXT_DIM);
      }
   }
}

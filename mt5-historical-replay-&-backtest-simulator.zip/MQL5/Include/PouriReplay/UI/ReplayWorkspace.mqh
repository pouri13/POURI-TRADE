//+------------------------------------------------------------------+
//|                                              ReplayWorkspace.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Data/ReplayDataFeed.mqh"
#include "../Core/ReplayEngine.mqh"
#include "../Core/MarketEngine.mqh"
#include "../Core/AccountEngine.mqh"
#include "../Execution/PositionManager.mqh"
#include "../Execution/OrderExecutionEngine.mqh"
#include "../Chart/ReplayChart.mqh"

#define WS_PREFIX "POURI_WS_"

//+------------------------------------------------------------------+
//| Class CReplayWorkspace: Complete Simulator Workspace for MT5     |
//| Manages Strategy Tester Visual Mode interface: Replay Canvas     |
//| Chart, Pacing Controls, Virtual Trading, Account HUD, Positions  |
//| Table, and Closed Trades Journal.                                |
//+------------------------------------------------------------------+
class CReplayWorkspace
{
private:
   long                    m_chart_id;
   CReplayDataFeed        *m_feed;
   CMarketData            *m_market_data;
   CReplayEngine          *m_replay;
   CMarketEngine          *m_market;
   CAccountEngine         *m_account;
   CPositionManager       *m_positions;
   COrderExecutionEngine  *m_execution;

   // Integrated Replay Chart Engine
   CReplayChart            m_chart;

   // UI State
   double                  m_trade_lots;
   int                     m_sl_pips;
   int                     m_tp_pips;
   int                     m_active_tab;   // 0=TRADING, 1=POSITIONS, 2=JOURNAL
   int                     m_panel_width;
   bool                    m_is_initialized;

public:
   CReplayWorkspace();
   ~CReplayWorkspace();

   bool                    Initialize(const long chart_id,
                                      CReplayDataFeed *feed,
                                      CMarketData *market_data,
                                      CReplayEngine *replay,
                                      CMarketEngine *market,
                                      CAccountEngine *account,
                                      CPositionManager *positions,
                                      COrderExecutionEngine *execution);
   void                    Destroy();

   // Frame cycle
   void                    Update();
   bool                    OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam);

private:
   void                    CreateLayout();
   void                    CreateReplayControls(int &y);
   void                    CreateAccountMetrics(int &y);
   void                    CreateNavigationTabs(int &y);
   void                    CreateTradingTab(int &y);
   void                    CreatePositionsTab(int &y);
   void                    CreateJournalTab(int &y);

   void                    UpdateTelemetry();
   void                    UpdatePositionsList();
   void                    UpdateJournalList();

   // Action Handlers
   void                    HandlePlayPause();
   void                    HandleStepForward();
   void                    HandleStepBackward();
   void                    HandleReset();
   void                    HandleSpeedChange(const int direction);
   void                    HandleExecuteBuy();
   void                    HandleExecuteSell();
   void                    HandleCloseAll();
   void                    HandleBreakeven();
   void                    HandleLotChange(const double delta);
   void                    HandleLotPreset(const double lots);
   void                    HandleSlChange(const int delta);
   void                    HandleTpChange(const int delta);
   void                    HandleTabSelect(const int tab);
   void                    HandlePositionClose(const long ticket);
   void                    HandlePositionPartial(const long ticket);
   void                    HandlePositionBe(const long ticket);

   // GUI Object Helpers
   bool                    CreateButton(const string name, const string text, const int x, const int y, const int w, const int h, const color bg_clr, const color txt_clr, const int font_size = 8, const bool bold = false);
   bool                    CreateLabel(const string name, const string text, const int x, const int y, const color txt_clr, const int font_size = 8, const bool bold = false);
   bool                    CreateRectLabel(const string name, const int x, const int y, const int w, const int h, const color bg_clr, const color border_clr);
   void                    SetText(const string name, const string text);
   void                    SetButtonColors(const string name, const color bg_clr, const color txt_clr);
   void                    DeleteGroup(const string sub_prefix);
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CReplayWorkspace::CReplayWorkspace()
   : m_chart_id(0),
     m_feed(NULL),
     m_market_data(NULL),
     m_replay(NULL),
     m_market(NULL),
     m_account(NULL),
     m_positions(NULL),
     m_execution(NULL),
     m_trade_lots(0.10),
     m_sl_pips(30),
     m_tp_pips(60),
     m_active_tab(0),
     m_panel_width(280),
     m_is_initialized(false)
{
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CReplayWorkspace::~CReplayWorkspace()
{
   Destroy();
}

//+------------------------------------------------------------------+
//| Initialize the complete Strategy Tester Replay Workspace         |
//+------------------------------------------------------------------+
bool CReplayWorkspace::Initialize(const long chart_id,
                                  CReplayDataFeed *feed,
                                  CMarketData *market_data,
                                  CReplayEngine *replay,
                                  CMarketEngine *market,
                                  CAccountEngine *account,
                                  CPositionManager *positions,
                                  COrderExecutionEngine *execution)
{
   m_chart_id    = (chart_id == 0) ? ChartID() : chart_id;
   m_feed        = feed;
   m_market_data = market_data;
   m_replay      = replay;
   m_market      = market;
   m_account     = account;
   m_positions   = positions;
   m_execution   = execution;

   if (feed == NULL || replay == NULL || market == NULL || account == NULL || positions == NULL || execution == NULL)
      return false;

   // 1. Initialize Replay Chart Canvas in the viewport to the right of the control panel
   int total_w = (int)ChartGetInteger(m_chart_id, CHART_WIDTH_IN_PIXELS, 0);
   int total_h = (int)ChartGetInteger(m_chart_id, CHART_HEIGHT_IN_PIXELS, 0);
   if (total_w <= 0) total_w = 1200;
   if (total_h <= 0) total_h = 800;

   int chart_x = m_panel_width + 12;
   int chart_w = MathMax(300, total_w - chart_x - 10);
   int chart_h = MathMax(200, total_h - 20);

   if (!m_chart.Initialize(m_chart_id, m_feed, m_market, m_positions, m_replay))
   {
      Print("[ReplayWorkspace] Failed to initialize Replay Chart.");
      return false;
   }
   m_chart.UpdateLayout(chart_x, 10, chart_w, chart_h);

   // 2. Build Interactive Workspace Control Panel
   CreateLayout();

   m_is_initialized = true;
   Update();
   return true;
}

//+------------------------------------------------------------------+
//| Destroy workspace and clear all objects                          |
//+------------------------------------------------------------------+
void CReplayWorkspace::Destroy()
{
   m_chart.Destroy();
   ObjectsDeleteAll(m_chart_id, WS_PREFIX);
   ChartRedraw(m_chart_id);
   m_is_initialized = false;
}

//+------------------------------------------------------------------+
//| Create UI Layout Sections                                        |
//+------------------------------------------------------------------+
void CReplayWorkspace::CreateLayout()
{
   ObjectsDeleteAll(m_chart_id, WS_PREFIX);

   int total_h = (int)ChartGetInteger(m_chart_id, CHART_HEIGHT_IN_PIXELS, 0);
   if (total_h <= 0) total_h = 800;

   // Main Panel Background Frame
   CreateRectLabel(WS_PREFIX + "BG", 10, 10, m_panel_width, total_h - 20, C'21,24,31', C'45,55,72');

   // Header Branding Banner
   CreateRectLabel(WS_PREFIX + "HDR_BG", 12, 12, m_panel_width - 4, 38, C'15,17,21', C'30,41,59');
   CreateLabel(WS_PREFIX + "HDR_TITLE", "POURI REPLAY SIMULATOR", 24, 18, C'241,245,249', 9, true);
   CreateLabel(WS_PREFIX + "HDR_SUB", "MT5 Strategy Tester - Zero Lookahead", 24, 32, C'148,163,184', 7, false);

   int cur_y = 56;

   // 1. Replay Controls Section
   CreateReplayControls(cur_y);

   // 2. Account Telemetry Section
   CreateAccountMetrics(cur_y);

   // 3. Navigation Tabs
   CreateNavigationTabs(cur_y);

   // 4. Tab Content Area
   if (m_active_tab == 0)
      CreateTradingTab(cur_y);
   else if (m_active_tab == 1)
      CreatePositionsTab(cur_y);
   else
      CreateJournalTab(cur_y);

   ChartRedraw(m_chart_id);
}

//+------------------------------------------------------------------+
//| Build Replay Transport & Speed Controls                          |
//+------------------------------------------------------------------+
void CReplayWorkspace::CreateReplayControls(int &y)
{
   CreateRectLabel(WS_PREFIX + "SEC1_BG", 16, y, m_panel_width - 12, 98, C'15,17,21', C'39,45,57');
   CreateLabel(WS_PREFIX + "SEC1_LBL", "REPLAY CONTROLS", 24, y + 6, C'148,163,184', 7, true);

   // Transport buttons: [RESET] [|< STEP] [PLAY/PAUSE] [STEP >|]
   int btn_y = y + 22;
   CreateButton(WS_PREFIX + "BTN_RESET", "RESET", 22, btn_y, 48, 26, C'39,45,57', C'226,232,240', 7, true);
   CreateButton(WS_PREFIX + "BTN_STEP_B", "|<", 74, btn_y, 38, 26, C'39,45,57', C'226,232,240', 8, true);
   CreateButton(WS_PREFIX + "BTN_PLAY", "PLAY", 116, btn_y, 90, 26, C'16,185,129', C'255,255,255', 8, true);
   CreateButton(WS_PREFIX + "BTN_STEP_F", ">|", 210, btn_y, 38, 26, C'39,45,57', C'226,232,240', 8, true);

   // Speed Controller: [SPEED -] [ Speed: 1.00x ] [SPEED +]
   int spd_y = y + 56;
   CreateButton(WS_PREFIX + "BTN_SPD_DOWN", "<<", 22, spd_y, 40, 24, C'30,41,59', C'203,213,225', 8, true);
   CreateRectLabel(WS_PREFIX + "SPD_BOX", 66, spd_y, 140, 24, C'15,17,21', C'51,65,85');
   CreateLabel(WS_PREFIX + "LBL_SPEED", "Speed: 1.00x", 98, spd_y + 5, C'241,245,249', 8, true);
   CreateButton(WS_PREFIX + "BTN_SPD_UP", ">>", 210, spd_y, 40, 24, C'30,41,59', C'203,213,225', 8, true);

   y += 106;
}

//+------------------------------------------------------------------+
//| Build Account Telemetry Cards                                    |
//+------------------------------------------------------------------+
void CReplayWorkspace::CreateAccountMetrics(int &y)
{
   CreateRectLabel(WS_PREFIX + "SEC2_BG", 16, y, m_panel_width - 12, 100, C'15,17,21', C'39,45,57');
   CreateLabel(WS_PREFIX + "SEC2_LBL", "VIRTUAL ACCOUNT", 24, y + 6, C'148,163,184', 7, true);

   int r1_y = y + 22;
   CreateLabel(WS_PREFIX + "LBL_BAL_TITLE", "Balance:", 24, r1_y, C'100,116,139', 8, false);
   CreateLabel(WS_PREFIX + "LBL_BAL_VAL", "$10,000.00", 160, r1_y, C'241,245,249', 8, true);

   int r2_y = y + 40;
   CreateLabel(WS_PREFIX + "LBL_EQ_TITLE", "Equity:", 24, r2_y, C'100,116,139', 8, false);
   CreateLabel(WS_PREFIX + "LBL_EQ_VAL", "$10,000.00", 160, r2_y, C'241,245,249', 8, true);

   int r3_y = y + 58;
   CreateLabel(WS_PREFIX + "LBL_FL_TITLE", "Floating P/L:", 24, r3_y, C'100,116,139', 8, false);
   CreateLabel(WS_PREFIX + "LBL_FL_VAL", "$0.00", 160, r3_y, C'148,163,184', 8, true);

   int r4_y = y + 76;
   CreateLabel(WS_PREFIX + "LBL_MG_TITLE", "Margin Level:", 24, r4_y, C'100,116,139', 8, false);
   CreateLabel(WS_PREFIX + "LBL_MG_VAL", "0.0%", 160, r4_y, C'148,163,184', 8, true);

   y += 108;
}

//+------------------------------------------------------------------+
//| Build Section Navigation Tabs                                    |
//+------------------------------------------------------------------+
void CReplayWorkspace::CreateNavigationTabs(int &y)
{
   int tab_w = (m_panel_width - 24) / 3;

   color t0_bg = (m_active_tab == 0) ? C'59,130,246' : C'30,41,59';
   color t1_bg = (m_active_tab == 1) ? C'59,130,246' : C'30,41,59';
   color t2_bg = (m_active_tab == 2) ? C'59,130,246' : C'30,41,59';

   CreateButton(WS_PREFIX + "TAB_0", "TRADE", 16, y, tab_w, 24, t0_bg, C'255,255,255', 7, true);
   CreateButton(WS_PREFIX + "TAB_1", "POSITIONS", 16 + tab_w + 2, y, tab_w, 24, t1_bg, C'255,255,255', 7, true);
   CreateButton(WS_PREFIX + "TAB_2", "JOURNAL", 16 + (tab_w * 2) + 4, y, tab_w, 24, t2_bg, C'255,255,255', 7, true);

   y += 30;
}

//+------------------------------------------------------------------+
//| Build Interactive Virtual Trading Tab                            |
//+------------------------------------------------------------------+
void CReplayWorkspace::CreateTradingTab(int &y)
{
   DeleteGroup("TAB_CONTENT_");

   // Container box
   CreateRectLabel(WS_PREFIX + "TAB_CONTENT_BG", 16, y, m_panel_width - 12, 280, C'15,17,21', C'39,45,57');

   // 1. Lot Size Controls
   int lot_y = y + 10;
   CreateLabel(WS_PREFIX + "TAB_CONTENT_LOT_LBL", "Trading Volume (Lots)", 24, lot_y, C'148,163,184', 7, true);

   int b_lot_y = lot_y + 16;
   CreateButton(WS_PREFIX + "TAB_CONTENT_LOT_M", "-", 24, b_lot_y, 34, 24, C'39,45,57', C'255,255,255', 9, true);
   CreateRectLabel(WS_PREFIX + "TAB_CONTENT_LOT_BOX", 62, b_lot_y, 88, 24, C'21,24,31', C'51,65,85');
   CreateLabel(WS_PREFIX + "TAB_CONTENT_LOT_VAL", DoubleToString(m_trade_lots, 2), 86, b_lot_y + 5, C'241,245,249', 8, true);
   CreateButton(WS_PREFIX + "TAB_CONTENT_LOT_P", "+", 154, b_lot_y, 34, 24, C'39,45,57', C'255,255,255', 9, true);

   // Quick Lot Presets
   int p_y = b_lot_y + 30;
   CreateButton(WS_PREFIX + "TAB_CONTENT_P_001", "0.01", 24, p_y, 48, 20, C'30,41,59', C'203,213,225', 7, false);
   CreateButton(WS_PREFIX + "TAB_CONTENT_P_01",  "0.10", 76, p_y, 48, 20, C'30,41,59', C'203,213,225', 7, false);
   CreateButton(WS_PREFIX + "TAB_CONTENT_P_05",  "0.50", 128, p_y, 48, 20, C'30,41,59', C'203,213,225', 7, false);
   CreateButton(WS_PREFIX + "TAB_CONTENT_P_10",  "1.00", 180, p_y, 48, 20, C'30,41,59', C'203,213,225', 7, false);

   // 2. Stop Loss & Take Profit in Pips
   int sltp_y = p_y + 28;
   CreateLabel(WS_PREFIX + "TAB_CONTENT_SL_LBL", "SL (Pips)", 24, sltp_y, C'239,68,68', 7, true);
   CreateLabel(WS_PREFIX + "TAB_CONTENT_TP_LBL", "TP (Pips)", 134, sltp_y, C'16,185,129', 7, true);

   int sltp_b_y = sltp_y + 14;
   CreateButton(WS_PREFIX + "TAB_CONTENT_SL_M", "-", 24, sltp_b_y, 24, 22, C'39,45,57', C'255,255,255', 8, true);
   CreateRectLabel(WS_PREFIX + "TAB_CONTENT_SL_BOX", 50, sltp_b_y, 40, 22, C'21,24,31', C'51,65,85');
   CreateLabel(WS_PREFIX + "TAB_CONTENT_SL_VAL", IntegerToString(m_sl_pips), 58, sltp_b_y + 4, C'241,245,249', 8, true);
   CreateButton(WS_PREFIX + "TAB_CONTENT_SL_P", "+", 92, sltp_b_y, 24, 22, C'39,45,57', C'255,255,255', 8, true);

   CreateButton(WS_PREFIX + "TAB_CONTENT_TP_M", "-", 134, sltp_b_y, 24, 22, C'39,45,57', C'255,255,255', 8, true);
   CreateRectLabel(WS_PREFIX + "TAB_CONTENT_TP_BOX", 160, sltp_b_y, 40, 22, C'21,24,31', C'51,65,85');
   CreateLabel(WS_PREFIX + "TAB_CONTENT_TP_VAL", IntegerToString(m_tp_pips), 168, sltp_b_y + 4, C'241,245,249', 8, true);
   CreateButton(WS_PREFIX + "TAB_CONTENT_TP_P", "+", 202, sltp_b_y, 24, 22, C'39,45,57', C'255,255,255', 8, true);

   // 3. One-Click Virtual BUY / SELL Execution
   int trade_btn_y = sltp_b_y + 32;
   int btn_half_w = (m_panel_width - 46) / 2;
   CreateButton(WS_PREFIX + "TAB_CONTENT_BTN_BUY", "BUY\n(Ask)", 24, trade_btn_y, btn_half_w, 40, C'16,185,129', C'255,255,255', 9, true);
   CreateButton(WS_PREFIX + "TAB_CONTENT_BTN_SELL", "SELL\n(Bid)", 24 + btn_half_w + 8, trade_btn_y, btn_half_w, 40, C'239,68,68', C'255,255,255', 9, true);

   // 4. Batch Position Actions
   int batch_y = trade_btn_y + 48;
   CreateButton(WS_PREFIX + "TAB_CONTENT_BTN_BE", "BREAKEVEN ALL", 24, batch_y, btn_half_w, 26, C'39,45,57', C'226,232,240', 7, true);
   CreateButton(WS_PREFIX + "TAB_CONTENT_BTN_CLOSE_ALL", "CLOSE ALL", 24 + btn_half_w + 8, batch_y, btn_half_w, 26, C'185,28,28', C'255,255,255', 7, true);

   y += 290;
}

//+------------------------------------------------------------------+
//| Build Open Positions Table Tab                                   |
//+------------------------------------------------------------------+
void CReplayWorkspace::CreatePositionsTab(int &y)
{
   DeleteGroup("TAB_CONTENT_");
   CreateRectLabel(WS_PREFIX + "TAB_CONTENT_BG", 16, y, m_panel_width - 12, 280, C'15,17,21', C'39,45,57');
   CreateLabel(WS_PREFIX + "TAB_CONTENT_POS_HDR", "OPEN VIRTUAL POSITIONS", 24, y + 8, C'148,163,184', 7, true);

   UpdatePositionsList();
   y += 290;
}

//+------------------------------------------------------------------+
//| Build Closed Trades Journal Tab                                  |
//+------------------------------------------------------------------+
void CReplayWorkspace::CreateJournalTab(int &y)
{
   DeleteGroup("TAB_CONTENT_");
   CreateRectLabel(WS_PREFIX + "TAB_CONTENT_BG", 16, y, m_panel_width - 12, 280, C'15,17,21', C'39,45,57');
   CreateLabel(WS_PREFIX + "TAB_CONTENT_JRN_HDR", "SIMULATION JOURNAL (RECENT)", 24, y + 8, C'148,163,184', 7, true);

   UpdateJournalList();
   y += 290;
}

//+------------------------------------------------------------------+
//| Frame Cycle Update                                               |
//+------------------------------------------------------------------+
void CReplayWorkspace::Update()
{
   if (!m_is_initialized) return;

   // 1. Redraw Replay Chart Canvas
   m_chart.Redraw();

   // 2. Refresh Numeric HUD Readouts
   UpdateTelemetry();

   // 3. Refresh Active Tab Content
   if (m_active_tab == 1)
      UpdatePositionsList();
   else if (m_active_tab == 2)
      UpdateJournalList();

   ChartRedraw(m_chart_id);
}

//+------------------------------------------------------------------+
//| Update Account Metrics and Replay State Labels                   |
//+------------------------------------------------------------------+
void CReplayWorkspace::UpdateTelemetry()
{
   if (m_account == NULL || m_replay == NULL) return;

   // Play/Pause button color & text
   bool is_running = (m_replay.GetState() == REPLAY_STATE_RUNNING);
   SetText(WS_PREFIX + "BTN_PLAY", is_running ? "PAUSE" : "PLAY");
   SetButtonColors(WS_PREFIX + "BTN_PLAY", is_running ? C'239,68,68' : C'16,185,129', C'255,255,255');

   // Speed text
   string spd_txt = StringFormat("Speed: %0.2fx", m_replay.GetSpeedMultiplier());
   SetText(WS_PREFIX + "LBL_SPEED", spd_txt);

   // Balance, Equity, Floating P/L
   double bal = m_account.GetBalance();
   double eq  = m_account.GetEquity();
   double fl  = m_account.GetFloatingProfit();
   double mg  = m_account.GetMarginLevel();

   SetText(WS_PREFIX + "LBL_BAL_VAL", StringFormat("$%0.2f", bal));
   SetText(WS_PREFIX + "LBL_EQ_VAL",  StringFormat("$%0.2f", eq));

   string fl_str = StringFormat("%s$%0.2f", (fl >= 0 ? "+" : ""), fl);
   SetText(WS_PREFIX + "LBL_FL_VAL", fl_str);

   string mg_str = (mg > 0.0) ? StringFormat("%0.1f%%", mg) : "0.0%";
   SetText(WS_PREFIX + "LBL_MG_VAL", mg_str);
}

//+------------------------------------------------------------------+
//| Populate open positions table                                    |
//+------------------------------------------------------------------+
void CReplayWorkspace::UpdatePositionsList()
{
   DeleteGroup("POS_ROW_");
   if (m_positions == NULL) return;

   int count = m_positions.GetCount();
   int start_y = 300;

   if (count == 0)
   {
      CreateLabel(WS_PREFIX + "POS_ROW_EMPTY", "No active positions open.", 30, start_y + 20, C'100,116,139', 8, false);
      return;
   }

   int max_rows = MathMin(count, 5);
   for (int i = 0; i < max_rows; i++)
   {
      SimPosition pos;
      if (!m_positions.GetPositionByIndex(i, pos))
         continue;

      int row_y = start_y + (i * 48);

      CreateRectLabel(WS_PREFIX + StringFormat("POS_ROW_BG_%d", i), 20, row_y, m_panel_width - 20, 44, C'21,24,31', C'39,45,57');

      string dir_txt = (pos.direction == DIRECTION_BUY) ? "BUY" : "SELL";
      color dir_clr  = (pos.direction == DIRECTION_BUY) ? C'16,185,129' : C'239,68,68';

      string info = StringFormat("#%d %s %0.2f @ %0.2f", pos.ticket, dir_txt, pos.lots, pos.open_price);
      CreateLabel(WS_PREFIX + StringFormat("POS_ROW_INF_%d", i), info, 26, row_y + 4, dir_clr, 7, true);

      string pnl_txt = StringFormat("P/L: %+0.2f (%+0.1f pips)", pos.net_profit, pos.pips);
      color pnl_clr  = (pos.net_profit >= 0.0) ? C'16,185,129' : C'239,68,68';
      CreateLabel(WS_PREFIX + StringFormat("POS_ROW_PNL_%d", i), pnl_txt, 26, row_y + 18, pnl_clr, 7, false);

      // Action buttons: [BE] [50%] [X Close]
      string t_str = IntegerToString(pos.ticket);
      CreateButton(WS_PREFIX + "POS_ROW_BE_" + t_str, "BE", 140, row_y + 8, 28, 22, C'39,45,57', C'226,232,240', 7, false);
      CreateButton(WS_PREFIX + "POS_ROW_PARTIAL_" + t_str, "50%", 172, row_y + 8, 34, 22, C'39,45,57', C'226,232,240', 7, false);
      CreateButton(WS_PREFIX + "POS_ROW_CLOSE_" + t_str, "X", 210, row_y + 8, 26, 22, C'185,28,28', C'255,255,255', 7, true);
   }
}

//+------------------------------------------------------------------+
//| Populate closed trades audit log                                 |
//+------------------------------------------------------------------+
void CReplayWorkspace::UpdateJournalList()
{
   DeleteGroup("JRN_ROW_");
   if (m_positions == NULL) return;

   int closed_cnt = m_positions.GetClosedCount();
   int start_y = 300;

   if (closed_cnt == 0)
   {
      CreateLabel(WS_PREFIX + "JRN_ROW_EMPTY", "No closed trades recorded yet.", 30, start_y + 20, C'100,116,139', 8, false);
      return;
   }

   int show_cnt = MathMin(closed_cnt, 5);
   for (int i = 0; i < show_cnt; i++)
   {
      int trade_idx = closed_cnt - 1 - i;
      SimClosedTrade ct;
      if (!m_positions.GetClosedTrade(trade_idx, ct))
         continue;

      int row_y = start_y + (i * 48);

      CreateRectLabel(WS_PREFIX + StringFormat("JRN_ROW_BG_%d", i), 20, row_y, m_panel_width - 20, 44, C'21,24,31', C'39,45,57');

      string dir_txt = (ct.direction == DIRECTION_BUY) ? "BUY" : "SELL";
      color dir_clr  = (ct.direction == DIRECTION_BUY) ? C'16,185,129' : C'239,68,68';

      string line1 = StringFormat("#%d %s %0.2f (%s)", ct.ticket, dir_txt, ct.lots, ct.close_reason);
      CreateLabel(WS_PREFIX + StringFormat("JRN_ROW_L1_%d", i), line1, 26, row_y + 4, dir_clr, 7, true);

      string line2 = StringFormat("Net: %+0.2f | Pips: %+0.1f", ct.net_profit, ct.pips);
      color pnl_clr = (ct.net_profit >= 0.0) ? C'16,185,129' : C'239,68,68';
      CreateLabel(WS_PREFIX + StringFormat("JRN_ROW_L2_%d", i), line2, 26, row_y + 18, pnl_clr, 7, false);
   }
}

//+------------------------------------------------------------------+
//| Event Handler: Intercept Button Clicks & Keyboard Hotkeys        |
//+------------------------------------------------------------------+
bool CReplayWorkspace::OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if (!m_is_initialized) return false;

   // 1. Chart resize
   if (id == CHARTEVENT_CHART_CHANGE)
   {
      int total_w = (int)ChartGetInteger(m_chart_id, CHART_WIDTH_IN_PIXELS, 0);
      int total_h = (int)ChartGetInteger(m_chart_id, CHART_HEIGHT_IN_PIXELS, 0);
      int chart_x = m_panel_width + 12;
      int chart_w = MathMax(300, total_w - chart_x - 10);
      int chart_h = MathMax(200, total_h - 20);

      m_chart.UpdateLayout(chart_x, 10, chart_w, chart_h);
      CreateLayout();
      return true;
   }

   // 2. Keyboard Hotkeys
   if (id == CHARTEVENT_KEYDOWN)
   {
      // Spacebar: Play/Pause
      if (lparam == 32)
      {
         HandlePlayPause();
         return true;
      }
      // Right Arrow: Step Forward
      if (lparam == 39)
      {
         HandleStepForward();
         return true;
      }
      // Left Arrow: Step Backward
      if (lparam == 37)
      {
         HandleStepBackward();
         return true;
      }
      // Pass other keys (+, -) to canvas chart
      if (m_chart.OnChartEvent(id, lparam, dparam, sparam))
         return true;
   }

   // 3. Object click events
   if (id == CHARTEVENT_OBJECT_CLICK)
   {
      string name = sparam;

      // Transport controls
      if (name == WS_PREFIX + "BTN_PLAY")       { HandlePlayPause();    return true; }
      if (name == WS_PREFIX + "BTN_STEP_F")      { HandleStepForward();  return true; }
      if (name == WS_PREFIX + "BTN_STEP_B")      { HandleStepBackward(); return true; }
      if (name == WS_PREFIX + "BTN_RESET")       { HandleReset();        return true; }
      if (name == WS_PREFIX + "BTN_SPD_UP")      { HandleSpeedChange(1);  return true; }
      if (name == WS_PREFIX + "BTN_SPD_DOWN")    { HandleSpeedChange(-1); return true; }

      // Tabs
      if (name == WS_PREFIX + "TAB_0")           { HandleTabSelect(0); return true; }
      if (name == WS_PREFIX + "TAB_1")           { HandleTabSelect(1); return true; }
      if (name == WS_PREFIX + "TAB_2")           { HandleTabSelect(2); return true; }

      // Lot controls
      if (name == WS_PREFIX + "TAB_CONTENT_LOT_P") { HandleLotChange(0.05);  return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_LOT_M") { HandleLotChange(-0.05); return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_P_001") { HandleLotPreset(0.01);  return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_P_01")  { HandleLotPreset(0.10);  return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_P_05")  { HandleLotPreset(0.50);  return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_P_10")  { HandleLotPreset(1.00);  return true; }

      // SL / TP adjustments
      if (name == WS_PREFIX + "TAB_CONTENT_SL_P")  { HandleSlChange(5);  return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_SL_M")  { HandleSlChange(-5); return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_TP_P")  { HandleTpChange(5);  return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_TP_M")  { HandleTpChange(-5); return true; }

      // Trading executions
      if (name == WS_PREFIX + "TAB_CONTENT_BTN_BUY")       { HandleExecuteBuy();  return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_BTN_SELL")      { HandleExecuteSell(); return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_BTN_CLOSE_ALL") { HandleCloseAll();    return true; }
      if (name == WS_PREFIX + "TAB_CONTENT_BTN_BE")        { HandleBreakeven();   return true; }

      // Row actions in Positions table
      if (StringFind(name, WS_PREFIX + "POS_ROW_CLOSE_") == 0)
      {
         string t_str = StringSubstr(name, StringLen(WS_PREFIX + "POS_ROW_CLOSE_"));
         HandlePositionClose(StringToInteger(t_str));
         return true;
      }
      if (StringFind(name, WS_PREFIX + "POS_ROW_PARTIAL_") == 0)
      {
         string t_str = StringSubstr(name, StringLen(WS_PREFIX + "POS_ROW_PARTIAL_"));
         HandlePositionPartial(StringToInteger(t_str));
         return true;
      }
      if (StringFind(name, WS_PREFIX + "POS_ROW_BE_") == 0)
      {
         string t_str = StringSubstr(name, StringLen(WS_PREFIX + "POS_ROW_BE_"));
         HandlePositionBe(StringToInteger(t_str));
         return true;
      }
   }

   return false;
}

//+------------------------------------------------------------------+
//| Action Handlers                                                  |
//+------------------------------------------------------------------+
void CReplayWorkspace::HandlePlayPause()
{
   if (m_replay == NULL) return;
   m_replay.TogglePlayPause();
   Update();
}

void CReplayWorkspace::HandleStepForward()
{
   if (m_replay == NULL) return;
   m_replay.StepNext();
   Update();
}

void CReplayWorkspace::HandleStepBackward()
{
   if (m_replay == NULL) return;
   m_replay.StepPrev();
   Update();
}

void CReplayWorkspace::HandleReset()
{
   if (m_replay == NULL) return;
   m_replay.JumpToIndex(50);
   Update();
}

void CReplayWorkspace::HandleSpeedChange(const int direction)
{
   if (m_replay == NULL) return;
   int cur = (int)m_replay.GetSpeed();
   int next = cur + direction;
   if (next >= 0 && next <= 9)
   {
      m_replay.SetSpeed((ENUM_REPLAY_SPEED)next);
      Update();
   }
}

void CReplayWorkspace::HandleTabSelect(const int tab)
{
   m_active_tab = tab;
   CreateLayout();
}

void CReplayWorkspace::HandleLotChange(const double delta)
{
   m_trade_lots = NormalizeDouble(MathMax(0.01, MathMin(20.0, m_trade_lots + delta)), 2);
   SetText(WS_PREFIX + "TAB_CONTENT_LOT_VAL", DoubleToString(m_trade_lots, 2));
}

void CReplayWorkspace::HandleLotPreset(const double lots)
{
   m_trade_lots = lots;
   SetText(WS_PREFIX + "TAB_CONTENT_LOT_VAL", DoubleToString(m_trade_lots, 2));
}

void CReplayWorkspace::HandleSlChange(const int delta)
{
   m_sl_pips = MathMax(0, MathMin(500, m_sl_pips + delta));
   SetText(WS_PREFIX + "TAB_CONTENT_SL_VAL", IntegerToString(m_sl_pips));
}

void CReplayWorkspace::HandleTpChange(const int delta)
{
   m_tp_pips = MathMax(0, MathMin(1000, m_tp_pips + delta));
   SetText(WS_PREFIX + "TAB_CONTENT_TP_VAL", IntegerToString(m_tp_pips));
}

void CReplayWorkspace::HandleExecuteBuy()
{
   if (m_execution == NULL || m_market_data == NULL || m_market == NULL) return;

   double ask   = m_market.GetAsk();
   double point = m_market_data.GetPoint();

   double sl_px = (m_sl_pips > 0) ? NormalizeDouble(ask - (m_sl_pips * 10.0 * point), m_market_data.GetDigits()) : 0.0;
   double tp_px = (m_tp_pips > 0) ? NormalizeDouble(ask + (m_tp_pips * 10.0 * point), m_market_data.GetDigits()) : 0.0;

   m_execution.ExecuteMarketBuy(m_trade_lots, sl_px, tp_px, "WS_BUY");
   Update();
}

void CReplayWorkspace::HandleExecuteSell()
{
   if (m_execution == NULL || m_market_data == NULL || m_market == NULL) return;

   double bid   = m_market.GetBid();
   double point = m_market_data.GetPoint();

   double sl_px = (m_sl_pips > 0) ? NormalizeDouble(bid + (m_sl_pips * 10.0 * point), m_market_data.GetDigits()) : 0.0;
   double tp_px = (m_tp_pips > 0) ? NormalizeDouble(bid - (m_tp_pips * 10.0 * point), m_market_data.GetDigits()) : 0.0;

   m_execution.ExecuteMarketSell(m_trade_lots, sl_px, tp_px, "WS_SELL");
   Update();
}

void CReplayWorkspace::HandleCloseAll()
{
   if (m_positions == NULL || m_market == NULL || m_feed == NULL) return;
   m_positions.CloseAll(m_market.GetBid(), m_market.GetAsk(), m_feed.GetCurrentTime());
   Update();
}

void CReplayWorkspace::HandleBreakeven()
{
   if (m_positions == NULL) return;
   for (int i = 0; i < m_positions.GetCount(); i++)
   {
      SimPosition pos;
      if (m_positions.GetPositionByIndex(i, pos))
         m_positions.MoveToBreakeven(pos.ticket, 2.0); // +2 points profit buffer
   }
   Update();
}

void CReplayWorkspace::HandlePositionClose(const long ticket)
{
   if (m_positions == NULL || m_market == NULL || m_feed == NULL) return;
   SimPosition pos;
   if (m_positions.GetPositionByTicket(ticket, pos))
   {
      double px = (pos.direction == DIRECTION_BUY) ? m_market.GetBid() : m_market.GetAsk();
      SimClosedTrade dummy;
      m_positions.ClosePosition(ticket, px, m_feed.GetCurrentTime(), "MANUAL_CLOSE", dummy);
      Update();
   }
}

void CReplayWorkspace::HandlePositionPartial(const long ticket)
{
   if (m_positions == NULL || m_market == NULL || m_feed == NULL) return;
   SimPosition pos;
   if (m_positions.GetPositionByTicket(ticket, pos))
   {
      double close_lots = NormalizeDouble(pos.lots * 0.5, 2);
      if (close_lots > 0.0)
      {
         double px = (pos.direction == DIRECTION_BUY) ? m_market.GetBid() : m_market.GetAsk();
         SimClosedTrade dummy;
         m_positions.PartialClose(ticket, close_lots, px, m_feed.GetCurrentTime(), dummy);
         Update();
      }
   }
}

void CReplayWorkspace::HandlePositionBe(const long ticket)
{
   if (m_positions == NULL) return;
   m_positions.MoveToBreakeven(ticket, 2.0);
   Update();
}

//+------------------------------------------------------------------+
//| GUI Object Construction Helpers                                  |
//+------------------------------------------------------------------+
bool CReplayWorkspace::CreateButton(const string name, const string text, const int x, const int y, const int w, const int h, const color bg_clr, const color txt_clr, const int font_size, const bool bold)
{
   ObjectDelete(m_chart_id, name);
   if (!ObjectCreate(m_chart_id, name, OBJ_BUTTON, 0, 0, 0)) return false;

   ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(m_chart_id, name, OBJPROP_XSIZE, w);
   ObjectSetInteger(m_chart_id, name, OBJPROP_YSIZE, h);
   ObjectSetString(m_chart_id, name, OBJPROP_TEXT, text);
   ObjectSetString(m_chart_id, name, OBJPROP_FONT, "Arial");
   ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, font_size);
   ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, txt_clr);
   ObjectSetInteger(m_chart_id, name, OBJPROP_BGCOLOR, bg_clr);
   ObjectSetInteger(m_chart_id, name, OBJPROP_BORDER_COLOR, bg_clr);
   ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(m_chart_id, name, OBJPROP_ZORDER, 10);
   return true;
}

bool CReplayWorkspace::CreateLabel(const string name, const string text, const int x, const int y, const color txt_clr, const int font_size, const bool bold)
{
   ObjectDelete(m_chart_id, name);
   if (!ObjectCreate(m_chart_id, name, OBJ_LABEL, 0, 0, 0)) return false;

   ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
   ObjectSetString(m_chart_id, name, OBJPROP_TEXT, text);
   ObjectSetString(m_chart_id, name, OBJPROP_FONT, bold ? "Arial Bold" : "Arial");
   ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, font_size);
   ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, txt_clr);
   ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(m_chart_id, name, OBJPROP_ZORDER, 10);
   return true;
}

bool CReplayWorkspace::CreateRectLabel(const string name, const int x, const int y, const int w, const int h, const color bg_clr, const color border_clr)
{
   ObjectDelete(m_chart_id, name);
   if (!ObjectCreate(m_chart_id, name, OBJ_RECTANGLE_LABEL, 0, 0, 0)) return false;

   ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(m_chart_id, name, OBJPROP_XSIZE, w);
   ObjectSetInteger(m_chart_id, name, OBJPROP_YSIZE, h);
   ObjectSetInteger(m_chart_id, name, OBJPROP_BGCOLOR, bg_clr);
   ObjectSetInteger(m_chart_id, name, OBJPROP_BORDER_COLOR, border_clr);
   ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(m_chart_id, name, OBJPROP_ZORDER, 5);
   return true;
}

void CReplayWorkspace::SetText(const string name, const string text)
{
   ObjectSetString(m_chart_id, name, OBJPROP_TEXT, text);
}

void CReplayWorkspace::SetButtonColors(const string name, const color bg_clr, const color txt_clr)
{
   ObjectSetInteger(m_chart_id, name, OBJPROP_BGCOLOR, bg_clr);
   ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, txt_clr);
}

void CReplayWorkspace::DeleteGroup(const string sub_prefix)
{
   string full_match = WS_PREFIX + sub_prefix;
   int total = ObjectsTotal(m_chart_id, 0);
   for (int i = total - 1; i >= 0; i--)
   {
      string obj_name = ObjectName(m_chart_id, i, 0);
      if (StringFind(obj_name, full_match) == 0)
      {
         ObjectDelete(m_chart_id, obj_name);
      }
   }
}

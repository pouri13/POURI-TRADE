//+------------------------------------------------------------------+
//|                                               ReplayDataFeed.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "MarketData.mqh"
#include "../Core/ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CReplayDataFeed: Zero-Lookahead Authoritative Data Feed     |
//| Guarantees that only candles up to the current replay index are  |
//| accessible. All future bars beyond current index are quarantined.|
//+------------------------------------------------------------------+
class CReplayDataFeed
{
private:
   CMarketData   *m_market_data;
   CReplayEngine *m_replay_engine;

public:
   CReplayDataFeed();
   ~CReplayDataFeed();

   bool           Initialize(CMarketData *market_data, CReplayEngine *replay_engine);

   // Zero look-ahead bounded access
   int            GetAvailableBarCount() const;
   int            GetCurrentBarIndex() const;
   datetime       GetCurrentTime() const;

   // Bar access (offset 0 = current replay bar, 1 = previous bar, etc.)
   bool           GetBarByOffset(const int offset_from_current, MqlRates &out_rate) const;
   bool           GetBarByAbsoluteIndex(const int abs_index, MqlRates &out_rate) const;
   bool           GetCurrentCandle(MqlRates &out_rate) const;

   // Batch extraction of visible window (chronological: [0] = oldest, [count-1] = newest)
   int            GetVisibleWindow(const int max_bars, MqlRates &out_rates[]) const;

   // Price range query for visible window scaling
   bool           GetVisibleHighLow(const int visible_count, double &out_high, double &out_low) const;

   // Security guard
   bool           IsFutureIndex(const int abs_index) const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CReplayDataFeed::CReplayDataFeed()
   : m_market_data(NULL),
     m_replay_engine(NULL)
{
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CReplayDataFeed::~CReplayDataFeed()
{
}

//+------------------------------------------------------------------+
//| Initialize the guarded data feed                                 |
//+------------------------------------------------------------------+
bool CReplayDataFeed::Initialize(CMarketData *market_data, CReplayEngine *replay_engine)
{
   if (market_data == NULL || replay_engine == NULL)
      return false;

   m_market_data   = market_data;
   m_replay_engine = replay_engine;
   return true;
}

//+------------------------------------------------------------------+
//| Total number of bars currently released to the simulator         |
//+------------------------------------------------------------------+
int CReplayDataFeed::GetAvailableBarCount() const
{
   if (m_replay_engine == NULL) return 0;
   int cur_idx = m_replay_engine.GetCurrentIndex();
   return (cur_idx >= 0) ? (cur_idx + 1) : 0;
}

//+------------------------------------------------------------------+
//| Active replay bar index                                          |
//+------------------------------------------------------------------+
int CReplayDataFeed::GetCurrentBarIndex() const
{
   if (m_replay_engine == NULL) return 0;
   return m_replay_engine.GetCurrentIndex();
}

//+------------------------------------------------------------------+
//| Current simulated timestamp                                      |
//+------------------------------------------------------------------+
datetime CReplayDataFeed::GetCurrentTime() const
{
   if (m_replay_engine == NULL) return 0;
   return m_replay_engine.GetCurrentTime();
}

//+------------------------------------------------------------------+
//| Check if absolute index lies in the quarantined future           |
//+------------------------------------------------------------------+
bool CReplayDataFeed::IsFutureIndex(const int abs_index) const
{
   if (m_replay_engine == NULL) return true;
   return (abs_index > m_replay_engine.GetCurrentIndex());
}

//+------------------------------------------------------------------+
//| Fetch bar by relative offset (0 = current, 1 = previous)         |
//| Rejects negative offsets (future bars)                           |
//+------------------------------------------------------------------+
bool CReplayDataFeed::GetBarByOffset(const int offset_from_current, MqlRates &out_rate) const
{
   if (offset_from_current < 0)
   {
      // STRICT QUARANTINE: Attempt to read future bar blocked!
      return false;
   }

   if (m_market_data == NULL || m_replay_engine == NULL)
      return false;

   int abs_index = m_replay_engine.GetCurrentIndex() - offset_from_current;
   if (abs_index < 0 || abs_index >= m_market_data.GetTotalBars())
      return false;

   return m_market_data.GetBar(abs_index, out_rate);
}

//+------------------------------------------------------------------+
//| Fetch bar by absolute historical buffer index                    |
//| Strictly rejects any index > current_replay_index               |
//+------------------------------------------------------------------+
bool CReplayDataFeed::GetBarByAbsoluteIndex(const int abs_index, MqlRates &out_rate) const
{
   if (m_market_data == NULL || m_replay_engine == NULL)
      return false;

   // ZERO LOOK-AHEAD ENFORCEMENT
   if (IsFutureIndex(abs_index) || abs_index < 0)
      return false;

   return m_market_data.GetBar(abs_index, out_rate);
}

//+------------------------------------------------------------------+
//| Fetch the current active candle                                  |
//+------------------------------------------------------------------+
bool CReplayDataFeed::GetCurrentCandle(MqlRates &out_rate) const
{
   return GetBarByOffset(0, out_rate);
}

//+------------------------------------------------------------------+
//| Extract visible window up to current replay bar                  |
//| Result is chronological: [0] = oldest, [count-1] = current       |
//+------------------------------------------------------------------+
int CReplayDataFeed::GetVisibleWindow(const int max_bars, MqlRates &out_rates[]) const
{
   if (m_market_data == NULL || m_replay_engine == NULL || max_bars <= 0)
   {
      ArrayResize(out_rates, 0);
      return 0;
   }

   int cur_idx = m_replay_engine.GetCurrentIndex();
   if (cur_idx < 0)
   {
      ArrayResize(out_rates, 0);
      return 0;
   }

   int available = cur_idx + 1;
   int take = MathMin(max_bars, available);
   int start_idx = cur_idx - take + 1;

   ArrayResize(out_rates, take);
   for (int i = 0; i < take; i++)
   {
      m_market_data.GetBar(start_idx + i, out_rates[i]);
   }

   return take;
}

//+------------------------------------------------------------------+
//| Calculate High/Low range over visible replay window              |
//+------------------------------------------------------------------+
bool CReplayDataFeed::GetVisibleHighLow(const int visible_count, double &out_high, double &out_low) const
{
   if (m_market_data == NULL || m_replay_engine == NULL || visible_count <= 0)
      return false;

   int cur_idx = m_replay_engine.GetCurrentIndex();
   int start_idx = MathMax(0, cur_idx - visible_count + 1);

   out_high = -DBL_MAX;
   out_low  = DBL_MAX;

   MqlRates rate;
   for (int i = start_idx; i <= cur_idx; i++)
   {
      if (m_market_data.GetBar(i, rate))
      {
         if (rate.high > out_high) out_high = rate.high;
         if (rate.low  < out_low)  out_low  = rate.low;
      }
   }

   return (out_high > -DBL_MAX && out_low < DBL_MAX);
}

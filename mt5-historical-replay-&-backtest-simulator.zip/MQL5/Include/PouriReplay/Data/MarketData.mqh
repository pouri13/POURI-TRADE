//+------------------------------------------------------------------+
//|                                                   MarketData.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"

//+------------------------------------------------------------------+
//| Class CMarketData: Authoritative Historical Data Provider        |
//+------------------------------------------------------------------+
class CMarketData
{
private:
   string         m_symbol;               // Current symbol
   ENUM_TIMEFRAMES m_timeframe;           // Active timeframe
   MqlRates       m_rates[];              // Chronological rates buffer [0=oldest]
   int            m_total_bars;           // Total historical bars loaded
   bool           m_is_loaded;            // Has data been copied successfully?

   // Symbol specifications read dynamically from MT5
   int            m_digits;
   double         m_point;
   double         m_tick_size;
   double         m_tick_value;
   double         m_contract_size;
   double         m_min_lot;
   double         m_max_lot;
   double         m_lot_step;
   int            m_typical_spread;

public:
   CMarketData();
   ~CMarketData();

   // Initialization and data loading from native MT5 history
   bool           Initialize(const string symbol, const ENUM_TIMEFRAMES timeframe, const datetime start_time, const datetime end_time);
   bool           LoadHistoryCount(const string symbol, const ENUM_TIMEFRAMES timeframe, const int bar_count);
   void           RefreshSymbolSpecs();

   // Strictly guarded data access (No-Lookahead)
   int            GetTotalBars() const { return m_total_bars; }
   bool           GetBar(const int index, MqlRates &out_rate) const;
   bool           GetVisibleRates(const int current_index, const int max_count, MqlRates &out_rates[]) const;

   // Getters for dynamic MT5 symbol properties
   string         GetSymbol() const { return m_symbol; }
   ENUM_TIMEFRAMES GetTimeframe() const { return m_timeframe; }
   int            GetDigits() const { return m_digits; }
   double         GetPoint() const { return m_point; }
   double         GetTickSize() const { return m_tick_size; }
   double         GetTickValue() const { return m_tick_value; }
   double         GetContractSize() const { return m_contract_size; }
   double         GetMinLot() const { return m_min_lot; }
   double         GetMaxLot() const { return m_max_lot; }
   double         GetLotStep() const { return m_lot_step; }
   int            GetTypicalSpread() const { return m_typical_spread; }
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CMarketData::CMarketData()
   : m_symbol(_Symbol),
     m_timeframe(PERIOD_M5),
     m_total_bars(0),
     m_is_loaded(false),
     m_digits(2),
     m_point(0.01),
     m_tick_size(0.01),
     m_tick_value(1.0),
     m_contract_size(100.0),
     m_min_lot(0.01),
     m_max_lot(50.0),
     m_lot_step(0.01),
     m_typical_spread(15)
{
   ArraySetAsSeries(m_rates, false); // Index 0 is oldest, chronological order
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CMarketData::~CMarketData()
{
   ArrayFree(m_rates);
}

//+------------------------------------------------------------------+
//| Dynamically queries native MT5 symbol specification              |
//+------------------------------------------------------------------+
void CMarketData::RefreshSymbolSpecs()
{
   m_digits         = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
   m_point          = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
   m_tick_size      = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_SIZE);
   m_tick_value     = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_VALUE);
   m_contract_size  = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_CONTRACT_SIZE);
   m_min_lot        = SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_MIN);
   m_max_lot        = SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_MAX);
   m_lot_step       = SymbolInfoDouble(m_symbol, SYMBOL_VOLUME_STEP);
   m_typical_spread = (int)SymbolInfoInteger(m_symbol, SYMBOL_SPREAD);

   // Fallback safety guards if running offline or in restricted testing mode
   if (m_point <= 0.0) m_point = 0.00001;
   if (m_tick_size <= 0.0) m_tick_size = m_point;
   if (m_tick_value <= 0.0) m_tick_value = 1.0;
   if (m_contract_size <= 0.0) m_contract_size = 100000.0;
   if (m_min_lot <= 0.0) m_min_lot = 0.01;
   if (m_max_lot <= 0.0) m_max_lot = 100.0;
   if (m_lot_step <= 0.0) m_lot_step = 0.01;
   if (m_typical_spread <= 0) m_typical_spread = 10;
}

//+------------------------------------------------------------------+
//| Loads authentic historical rates using CopyRates                 |
//+------------------------------------------------------------------+
bool CMarketData::Initialize(const string symbol, const ENUM_TIMEFRAMES timeframe, const datetime start_time, const datetime end_time)
{
   m_symbol    = (symbol == "") ? _Symbol : symbol;
   m_timeframe = timeframe;

   RefreshSymbolSpecs();

   // Query real historical rates from MT5 terminal history database
   int copied = CopyRates(m_symbol, m_timeframe, start_time, end_time, m_rates);
   if (copied <= 0)
   {
      PrintFormat("[CMarketData::Initialize] Error: Failed to copy historical rates for %s. Error code: %d", m_symbol, GetLastError());
      m_is_loaded  = false;
      m_total_bars = 0;
      return false;
   }

   ArraySetAsSeries(m_rates, false); // Enforce ascending chronological order
   m_total_bars = copied;
   m_is_loaded  = true;

   PrintFormat("[CMarketData::Initialize] Successfully loaded %d historical bars for %s (%s to %s).",
               m_total_bars, m_symbol, TimeToString(m_rates[0].time), TimeToString(m_rates[m_total_bars - 1].time));

   return true;
}

//+------------------------------------------------------------------+
//| Loads N most recent historical bars                              |
//+------------------------------------------------------------------+
bool CMarketData::LoadHistoryCount(const string symbol, const ENUM_TIMEFRAMES timeframe, const int bar_count)
{
   m_symbol    = (symbol == "") ? _Symbol : symbol;
   m_timeframe = timeframe;

   RefreshSymbolSpecs();

   int copied = CopyRates(m_symbol, m_timeframe, 0, bar_count, m_rates);
   if (copied <= 0)
   {
      PrintFormat("[CMarketData::LoadHistoryCount] Error: Failed to copy %d bars for %s. Error: %d", bar_count, m_symbol, GetLastError());
      m_is_loaded  = false;
      m_total_bars = 0;
      return false;
   }

   ArraySetAsSeries(m_rates, false);
   m_total_bars = copied;
   m_is_loaded  = true;

   return true;
}

//+------------------------------------------------------------------+
//| Safely retrieves a single bar by index                           |
//+------------------------------------------------------------------+
bool CMarketData::GetBar(const int index, MqlRates &out_rate) const
{
   if (!m_is_loaded || index < 0 || index >= m_total_bars)
      return false;

   out_rate = m_rates[index];
   return true;
}

//+------------------------------------------------------------------+
//| Returns visible rates up to current_index (strictly No-Lookahead)|
//+------------------------------------------------------------------+
bool CMarketData::GetVisibleRates(const int current_index, const int max_count, MqlRates &out_rates[]) const
{
   if (!m_is_loaded || current_index < 0 || current_index >= m_total_bars)
      return false;

   int start_idx = MathMax(0, current_index - max_count + 1);
   int count     = current_index - start_idx + 1;

   if (ArrayResize(out_rates, count) != count)
      return false;

   for (int i = 0; i < count; i++)
   {
      out_rates[i] = m_rates[start_idx + i];
   }

   return true;
}

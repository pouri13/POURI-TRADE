//+------------------------------------------------------------------+
//|                                  POURI-ESCOBAR-MARKET-REPLAY.mq5 |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright   "Copyright 2026, Pouri-Escobar"
#property link        "https://github.com/pouri-escobar/market-replay"
#property version     "2.00"
#property description "Professional MetaTrader 5 Strategy Tester Historical Market Replay Simulator."
#property description "Features CCanvas progressive candle rendering, zero look-ahead quarantine, and manual virtual trading."
#property strict

//--- Core Simulation Architecture
#include "../Include/PouriReplay/Core/SimulationDefines.mqh"
#include "../Include/PouriReplay/Data/MarketData.mqh"
#include "../Include/PouriReplay/Core/ReplayEngine.mqh"
#include "../Include/PouriReplay/Data/ReplayDataFeed.mqh"
#include "../Include/PouriReplay/Core/MarketEngine.mqh"
#include "../Include/PouriReplay/Core/AccountEngine.mqh"

//--- Execution Pipeline
#include "../Include/PouriReplay/Execution/PositionManager.mqh"
#include "../Include/PouriReplay/Execution/OrderExecutionEngine.mqh"

//--- Visual Replay Engine & Workspace
#include "../Include/PouriReplay/Chart/ReplayCandleRenderer.mqh"
#include "../Include/PouriReplay/Chart/ReplayRenderer.mqh"
#include "../Include/PouriReplay/Chart/ReplayChart.mqh"
#include "../Include/PouriReplay/UI/ReplayWorkspace.mqh"

//+------------------------------------------------------------------+
//| Input Parameters                                                 |
//+------------------------------------------------------------------+
sinput group "=== SIMULATION ACCOUNT ==="
input double               InpInitialBalance    = 10000.0;             // Initial Account Balance ($)
input double               InpLeverage          = 100.0;               // Account Leverage (e.g. 100)
input double               InpCommissionLot     = 7.0;                 // Commission per Round Lot ($)

sinput group "=== MARKET MICROSTRUCTURE ==="
input ENUM_SPREAD_MODEL    InpSpreadModel       = SPREAD_HISTORICAL;   // Spread Simulation Model
input int                  InpFixedSpreadPts    = 15;                  // Fixed Spread (Points)
input ENUM_SLIPPAGE_MODEL  InpSlippageModel     = SLIPPAGE_NONE;       // Slippage Model
input int                  InpFixedSlippagePts  = 0;                   // Fixed Slippage (Points)

sinput group "=== REPLAY CONFIGURATION ==="
input int                  InpStartHistoryBars  = 600;                 // Historical Bars Loaded from MT5
input int                  InpInitialBarOffset  = 60;                  // Initial Visible Bar Offset
input ENUM_REPLAY_SPEED    InpInitialSpeed      = SPEED_1X;            // Initial Playback Speed
input ENUM_REPLAY_MODE     InpReplayMode        = REPLAY_MODE_CANDLE;  // Stepping Mode

//+------------------------------------------------------------------+
//| Global Simulator Engine Instances                                |
//+------------------------------------------------------------------+
CMarketData             ExtMarketData;
CReplayEngine           ExtReplayEngine;
CReplayDataFeed         ExtDataFeed;
CMarketEngine           ExtMarketEngine;
CAccountEngine          ExtAccountEngine;
CPositionManager        ExtPositionManager;
COrderExecutionEngine   ExtExecutionEngine;
CReplayWorkspace        ExtWorkspace;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("==================================================================");
   Print("  POURI-ESCOBAR-MARKET-REPLAY: Initializing Historical Replay...  ");
   Print("==================================================================");

   // 1. Initialize Authoritative Historical Data from MT5
   if (!ExtMarketData.LoadHistoryCount(_Symbol, _Period, InpStartHistoryBars))
   {
      Print("[OnInit] CRITICAL ERROR: Could not load historical rates for symbol ", _Symbol);
      return INIT_FAILED;
   }

   // 2. Initialize Pacing & Replay Controller
   if (!ExtReplayEngine.Initialize(&ExtMarketData, InpInitialBarOffset))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Replay Engine.");
      return INIT_FAILED;
   }
   ExtReplayEngine.SetSpeed(InpInitialSpeed);
   ExtReplayEngine.SetMode(InpReplayMode);

   // 3. Initialize Zero-Lookahead Authoritative Data Feed
   if (!ExtDataFeed.Initialize(&ExtMarketData, &ExtReplayEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Replay Data Feed.");
      return INIT_FAILED;
   }

   // 4. Initialize Simulated Market Microstructure
   if (!ExtMarketEngine.Initialize(&ExtMarketData, &ExtReplayEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Market Engine.");
      return INIT_FAILED;
   }
   ExtMarketEngine.SetSpreadModel(InpSpreadModel, InpFixedSpreadPts);
   ExtMarketEngine.SetSlippageModel(InpSlippageModel, InpFixedSlippagePts);

   // 5. Initialize Virtual Account Engine
   if (!ExtAccountEngine.Initialize(&ExtMarketData, InpInitialBalance, InpLeverage))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Account Engine.");
      return INIT_FAILED;
   }
   ExtAccountEngine.SetCommissionPerLot(InpCommissionLot);

   // 6. Initialize Position Manager
   if (!ExtPositionManager.Initialize(&ExtMarketData, &ExtAccountEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Position Manager.");
      return INIT_FAILED;
   }

   // 7. Initialize Order Execution Engine
   if (!ExtExecutionEngine.Initialize(&ExtMarketData, &ExtMarketEngine, &ExtAccountEngine, &ExtPositionManager))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Order Execution Engine.");
      return INIT_FAILED;
   }

   // 8. Initialize Complete Simulator Workspace & Replay Canvas
   if (!ExtWorkspace.Initialize(ChartID(), &ExtDataFeed, &ExtMarketData, &ExtReplayEngine, &ExtMarketEngine, &ExtAccountEngine, &ExtPositionManager, &ExtExecutionEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Replay Workspace.");
      return INIT_FAILED;
   }

   // 9. Launch High-Resolution Millisecond Timer for Replay Loop
   EventSetMillisecondTimer(SIM_TIMER_INTERVAL_MS);

   PrintFormat("[OnInit] Replay Ready. Symbol: %s | Timeframe: %s | Replay Start Time: %s",
               _Symbol, EnumToString(_Period), TimeToString(ExtReplayEngine.GetCurrentTime()));
   Print("Hotkeys: [Space] = Play/Pause | [Right Arrow] = Step | [+] / [-] = Zoom");

   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   ExtWorkspace.Destroy();

   PrintFormat("[OnDeinit] Market replay session terminated. Reason code: %d", reason);
}

//+------------------------------------------------------------------+
//| High-Frequency Millisecond Timer Event Handler                   |
//+------------------------------------------------------------------+
void OnTimer()
{
   ulong cur_ms = GetMicrosecondCount() / 1000;

   // 1. Advance replay state if simulation is running
   bool stepped = ExtReplayEngine.OnTimerTick(cur_ms);

   // 2. Refresh current simulated quotes
   ExtMarketEngine.UpdateQuotes();

   double   bid      = ExtMarketEngine.GetBid();
   double   ask      = ExtMarketEngine.GetAsk();
   datetime cur_time = ExtReplayEngine.GetCurrentTime();

   // 3. Evaluate active positions, SL/TP triggers, and floating P/L
   ExtPositionManager.UpdatePositions(bid, ask, cur_time);

   // 4. Update virtual account equity and margin metrics
   double fl_pnl = ExtPositionManager.GetTotalFloatingProfit();
   double used_m = ExtPositionManager.GetTotalUsedMargin();
   ExtAccountEngine.UpdateEquityAndMargin(fl_pnl, used_m, ExtPositionManager.GetCount(), 0);

   // 5. Refresh Replay Chart Canvas and Workspace HUD
   ExtWorkspace.Update();
}

//+------------------------------------------------------------------+
//| Chart Event Handler (Clicks, Dragging, Hotkeys, Resizes)         |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   // Forward event to Replay Workspace
   if (ExtWorkspace.OnChartEvent(id, lparam, dparam, sparam))
   {
      ExtMarketEngine.UpdateQuotes();
      ExtWorkspace.Update();
   }
}

//+------------------------------------------------------------------+
//| Expert tick function (Strategy Tester visual mode sync)          |
//+------------------------------------------------------------------+
void OnTick()
{
   ExtMarketEngine.UpdateQuotes();
   OnTimer();
}

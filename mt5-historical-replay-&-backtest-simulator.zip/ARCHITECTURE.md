# ARCHITECTURE: POURI-ESCOBAR MARKET REPLAY
**High-Performance MetaTrader 5 Historical Market Replay & Trading Simulator EA**
**Architecture Specification Version:** 2.0.0  
**Target Runtime:** MetaTrader 5 (MQL5 64-bit Architecture, Build 4000+)  

---

## 1. System Philosophy & Executive Summary

The **POURI-ESCOBAR-MARKET-REPLAY** system is a specialized, human-driven historical simulator that executes directly within the MetaTrader 5 platform. Unlike typical automated trading Expert Advisors that act on incoming live ticks, this EA **is the simulation environment itself**.

It isolates the trading engine from MT5's live broker pipeline, taking full authority over:
1. **Time Flow:** Replaying historical rates with high-precision stepping and speed controls.
2. **Data Integrity:** Strictly enforcing zero lookahead bias by isolating future market data from indicators, charts, and orders.
3. **Execution Realism:** Simulating true market microstructure including dynamic spreads, slippage jitter, execution delays, swaps, and commissions.
4. **Human Interaction:** Providing a high-frequency, responsive graphical user interface on the MT5 chart that allows manual order entry, position sizing, SL/TP dragging, and trade journaling.

---

## 2. Directory & Modular File Architecture

All source files are organized into a decoupled, object-oriented structure under `Include/PouriReplay/` with the main EA entry point in `Experts/`:

```
MQL5/
├── Experts/
│   └── POURI-ESCOBAR-MARKET-REPLAY.mq5        <-- Main Expert Advisor Controller
└── Include/
    └── PouriReplay/
        ├── Core/
        │   ├── SimulationDefines.mqh          <-- Data structures, enums, error codes
        │   ├── ReplayEngine.mqh               <-- Virtual clock, pacing, ring-buffer index
        │   ├── MarketEngine.mqh               <-- Quote provider (Bid, Ask, Spread, Slippage)
        │   ├── AccountEngine.mqh              <-- Virtual account balance, equity, margin
        │   └── RiskEngine.mqh                 <-- Position sizing, risk %, pip calculator
        ├── Data/
        │   ├── MarketData.mqh                 <-- CopyRates caching, bar indexing, integrity
        │   └── SymbolSpecs.mqh                <-- Dynamic MT5 symbol specification resolver
        ├── Positions/
        │   ├── PositionManager.mqh            <-- Multi-position hedging, partial closes
        │   ├── OrderManager.mqh               <-- Pending orders (Limit & Stop)
        │   └── OrderExecutionEngine.mqh       <-- Virtual broker order routing & fills
        ├── Analytics/
        │   ├── StatisticsEngine.mqh           <-- Sharpe, Sortino, SQN, Expectancy, DD
        │   └── JournalEngine.mqh              <-- Trade logger, JSON & CSV file writer
        ├── UI/
        │   ├── ChartManager.mqh               <-- Visual template, autoscroll off, markers
        │   ├── MainPanel.mqh                  <-- Dockable GUI container, theme management
        │   ├── ReplayPanel.mqh                <-- Play, Pause, Step, Speed, Time display
        │   ├── TradingPanel.mqh               <-- Buy/Sell, Lots, SL/TP inputs, Risk calc
        │   └── PositionPanel.mqh              <-- Live positions table & close buttons
        ├── Session/
        │   └── SessionManager.mqh             <-- JSON session state serialize/deserialize
        └── Utils/
            ├── Logger.mqh                     <-- Diagnostic logging (DEBUG, INFO, ERROR)
            └── TimeUtils.mqh                  <-- Time parsing, session window detection
```

---

## 3. Class Hierarchy & Responsibilities

```
                         ┌─────────────────────────────────────────┐
                         │       CReplayController (Main EA)       │
                         │    (POURI-ESCOBAR-MARKET-REPLAY.mq5)    │
                         └────────────────────┬────────────────────┘
                                              │
         ┌────────────────────────┬───────────┴────────────┬────────────────────────┐
         │                        │                        │                        │
         ▼                        ▼                        ▼                        ▼
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐
│  CReplayEngine  │      │  CMarketEngine  │      │ CAccountEngine  │      │   CMainPanel    │
│ - Virtual Clock │      │ - Real Bid/Ask  │      │ - Balance/Equity│      │ - Native MT5 UI │
│ - No-Lookahead  │      │ - Spread Model  │      │ - Margin Engine │      │ - Chart Events  │
│ - Step Logic    │      │ - Slippage      │      │ - Drawdown Guard│      │ - Visual Panels │
└────────┬────────┘      └────────┬────────┘      └────────┬────────┘      └─────────────────┘
         │                        │                        │
         ▼                        ▼                        │
┌─────────────────┐      ┌─────────────────┐               │
│   CMarketData   │      │COrderExecution- │               │
│ - CopyRates()   │      │     Engine      │               │
│ - Rates Array   │      │ - Market Orders │               │
│ - Integrity     │      │ - Pending Orders│               │
└─────────────────┘      └────────┬────────┘               │
                                  │                        │
                                  ▼                        ▼
                         ┌─────────────────┐      ┌─────────────────┐
                         │CPositionManager │      │ CJournalEngine  │
                         │ - Hedged Tickets│◄────►│ - Trade Log     │
                         │ - Partial Close │      │ - JSON/CSV Out  │
                         │ - Breakeven/SL  │      │ - Statistics    │
                         └─────────────────┘      └─────────────────┘
```

---

## 4. Replay State Machine & No-Lookahead Isolation

To eliminate any chance of future data leakage into trading decisions or indicator evaluations:

1. **Chronological Storage:**
   Rates retrieved via `CopyRates()` are kept in chronological ascending order (`[0]` oldest, `[Total-1]` newest).
2. **Current Virtual Index:**
   `m_current_bar_index` points to the active candle in simulation time.
3. **Data Access Wall:**
   Any method requesting rates or prices (such as `CMarketData::GetVisibleRates()` or `CMarketEngine::GetCurrentCandle()`) strictly caps data arrays at `m_current_bar_index`. Future elements ($> \text{m\_current\_bar\_index}$) remain quarantined in memory.
4. **Deterministic Pacing:**
   In Strategy Tester or live visual mode, a high-resolution millisecond timer (`EventSetMillisecondTimer(20)`) advances the simulation clock based on user-selected replay speed ($0.1\times$ to $100\times$).

---

## 5. Virtual Order Execution & Market Microstructure

- **Bid / Ask Realism:**
  - `BUY` market orders execute at current simulated **Ask**.
  - `SELL` market orders execute at current simulated **Bid**.
  - `BUY` positions close at **Bid**, and `SELL` positions close at **Ask**.
- **Spread Modes:**
  - `SPREAD_HISTORICAL`: Directly reads the spread recorded in the MT5 historical bar.
  - `SPREAD_FIXED`: Applies user-defined point spread (e.g. 15 points on Gold).
  - `SPREAD_RANDOM_RANGE`: Simulates natural liquidity jitter within minimum and maximum boundaries.
- **Slippage Simulation:**
  - Evaluates execution price using deterministic or stochastic point deviations.
- **Commission & Swaps:**
  - Round-turn commission deducted at order creation/close.
  - Daily rollover swap applied when historical timestamp passes 00:00 server time.

---

## 6. Risk Engine & Position Sizing Mathematical Model

When calculating position sizes from risk percentage:

$$\text{Account Equity} = E$$
$$\text{Risk Percentage} = R\% \implies \text{Risk Amount } (\$) = E \times \frac{R}{100}$$
$$\text{SL Distance in Points} = D_{\text{points}} = \frac{|\text{Entry} - \text{SL}|}{\text{Point}}$$
$$\text{Tick Value per Standard Lot} = V_{\text{tick}}$$
$$\text{Tick Size} = S_{\text{tick}}$$
$$\text{Recommended Lots} = \frac{\text{Risk Amount}}{\left(\frac{D_{\text{points}} \times \text{Point}}{S_{\text{tick}}}\right) \times V_{\text{tick}}}$$

The calculated lot size is automatically clamped between `SYMBOL_VOLUME_MIN` and `SYMBOL_VOLUME_MAX`, and aligned to `SYMBOL_VOLUME_STEP`.

---

## 7. MT5 Strategy Tester Integration Lifecycle

```
[MT5 Launch Strategy Tester (Visual Mode)]
   │
   ├── OnInit()
   │    ├── Detect execution environment (Tester vs. Normal Chart)
   │    ├── Initialize CMarketData (Load symbol specs, test data integrity)
   │    ├── Initialize CReplayEngine (Set start date, set paused state)
   │    ├── Initialize CAccountEngine (Set starting balance, leverage)
   │    ├── Initialize CMainPanel (Construct dark GUI, bind click events)
   │    └── EventSetMillisecondTimer(20)
   │
   ├── OnTick()
   │    └── Process tick events if Strategy Tester native feed is active
   │
   ├── OnTimer()
   │    ├── If simulation running: advance replay clock according to speed
   │    ├── CMarketEngine::UpdateQuotes()
   │    ├── COrderExecutionEngine::CheckPendingOrdersAndStops()
   │    ├── CPositionManager::UpdateFloatingProfits()
   │    ├── CAccountEngine::UpdateMetrics()
   │    └── CMainPanel::RefreshDisplay()
   │
   ├── OnChartEvent()
   │    ├── CHARTEVENT_OBJECT_CLICK: Process GUI buttons (Play, Step, Buy, Sell, Close)
   │    ├── CHARTEVENT_KEYDOWN: Process hotkeys (Space = Play/Pause, Right = Step)
   │    └── CHARTEVENT_OBJECT_DRAG: Update draggable SL/TP visual lines
   │
   └── OnDeinit()
        ├── EventKillTimer()
        ├── CSessionManager::SaveAutosaveSession()
        ├── CMainPanel::Destroy()
        └── Output final performance summary to Journal & Logs
```

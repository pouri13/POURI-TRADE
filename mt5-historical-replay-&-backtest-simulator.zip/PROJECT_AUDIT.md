# PROJECT AUDIT: POURI-ESCOBAR MARKET REPLAY
**Comprehensive Technical Audit, Architecture Gap Analysis & MQL5 Strategy Tester Design**
**System Name:** POURI-ESCOBAR-MARKET-REPLAY  
**Target Platform:** MetaTrader 5 (MQL5 64-bit Windows Build 4000+)  
**Execution Environment:** MT5 Strategy Tester (Visual Mode) & Standalone Chart Mode  

---

## 1. Existing Files & Components Audit

| File Path | Description / Role | Current Status in Prototype | Reusability / Verdict |
| :--- | :--- | :--- | :--- |
| `/src/types/simulator.ts` | TypeScript type definitions for Account, Position, Orders, Trades, Stats | Complete schema for web mock | **Reusable Concept**: Data contracts map 1:1 to MQL5 `struct` and `enum` types in `SimulationDefines.mqh`. |
| `/src/data/symbols.ts` | Symbol contract specifications (XAUUSD, EURUSD, etc.) and candle generator | Contains synthetic random candle generator (`Math.random`) | **Discard Fake Generator**: Real MT5 `SymbolInfoDouble`, `SymbolInfoInteger`, and `CopyRates` replace this completely. Static specs serve as reference fallback. |
| `/src/engine/analyticsEngine.ts` | Quantitative metrics (Sharpe, Sortino, SQN, Calmar, Drawdown, Expectancy) | High-fidelity mathematical functions in TS | **Reusable**: Direct translation into MQL5 `CStatisticsEngine` with identical mathematical rigor. |
| `/src/components/ChartCanvas.tsx` | HTML5 2D Canvas rendering candles, draggable SL/TP, session bands | Web UI prototype | **Discard UI, Keep UX Flow**: MQL5 will use native MT5 chart objects (`OBJ_RECTANGLE`, `OBJ_HLINE`, `OBJ_TREND`, `OBJ_LABEL`) or virtual canvas. |
| `/src/components/ReplayControls.tsx` | Replay control bar (Play/Pause, Step, Speed, Date slider) | Web UI prototype | **Translate to MQL5**: Map to MT5 in-chart button bar with `OnChartEvent` handler (`CHARTEVENT_OBJECT_CLICK`). |
| `/src/components/TradingPanel.tsx` | Order execution panel (Buy/Sell, Lots, Risk %, SL/TP in pips) | Web UI prototype | **Translate to MQL5**: Map to interactive MQL5 dialog panel with edit fields, one-click buy/sell, and risk calculator. |
| `/src/components/PositionsTable.tsx` | Active positions, partial close, breakeven, reverse, close all | Web UI prototype | **Translate to MQL5**: Managed by `CPositionManager` and visualized in an on-chart table or terminal tab. |
| `/src/components/JournalView.tsx` | Trade log, psychological emotions, confidence rating, notes, JSON/CSV | Web UI prototype | **Translate to MQL5**: `CTradeJournal` logs directly to disk (`MQL5/Files/`) as formatted JSON and CSV with screenshot links. |
| `/src/components/StatsDashboard.tsx` | Equity curve graph and performance ratio tables | Web UI prototype | **Translate to MQL5**: Computed via `CStatisticsEngine` and rendered on chart or exported to HTML/CSV reports. |
| `/src/components/CalendarView.tsx` | Daily P/L heatmap grid | Web UI prototype | **Translate to MQL5**: Daily performance aggregator exported in session reports. |
| `/src/components/Mql5CodeViewer.tsx` | In-app code viewer and ZIP exporter for MQL5 source code | Web packaging tool | **Retain in Web Viewer**: Exposes the actual MQL5 files for immediate copy and ZIP download inside the workspace. |
| `/src/mql5/mql5Sources.ts` | Modular MQL5 source code strings for compilation and export | Early MQL5 draft | **Upgrade & Align**: Upgrade to full `POURI-ESCOBAR-MARKET-REPLAY.mq5` architecture and modular hierarchy. |

---

## 2. Analysis of Broken / Synthetic Functionality to Discard

1. **Synthetic Brownian Walk Candle Generation (`generateMarketCandles`)**:
   - *Problem:* Generated fake price points using `Math.random()` and sine waves.
   - *Fix:* Must be completely discarded for actual trading simulation. The MQL5 engine calls MT5's native `CopyRates()` and `CopyTicksRange()` to fetch 100% authentic broker history.
2. **Client-Side Browser Timers (`setInterval`)**:
   - *Problem:* Browser-based timers fluctuate with frame drops and background throttling.
   - *Fix:* In MT5, replay pacing is governed by high-precision `EventSetMillisecondTimer()` inside `OnTimer()` or synchronized with Strategy Tester ticks in `OnTick()`.
3. **Hard-coded Instrument Assumptions**:
   - *Problem:* Assuming all instruments share 1.00 lot tick value or 2 digits.
   - *Fix:* Dynamically query MT5 symbol properties using `SymbolInfoDouble(_Symbol, SYMBOL_POINT)`, `SYMBOL_TRADE_TICK_VALUE`, `SYMBOL_TRADE_CONTRACT_SIZE`, `SYMBOL_VOLUME_MIN`, `SYMBOL_VOLUME_STEP`, etc.

---

## 3. Detailed MQL5 Architecture Proposal

The Expert Advisor `POURI-ESCOBAR-MARKET-REPLAY.mq5` is structured into clean, decoupled object-oriented modules under `Include/PouriReplay/`:

```
Experts/
└── POURI-ESCOBAR-MARKET-REPLAY.mq5

Include/PouriReplay/
├── Core/
│   ├── SimulationDefines.mqh       <-- Structs, Enums, Error codes, Event constants
│   ├── ReplayEngine.mqh            <-- Replay clock, step logic, no-lookahead ring buffer
│   ├── MarketEngine.mqh            <-- Bid/Ask, spread modeling, slippage, candle queries
│   ├── AccountEngine.mqh           <-- Virtual balance, equity, margin requirements, leverage
│   └── RiskEngine.mqh              <-- Auto risk % sizing, pip value calculator, margin check
├── Data/
│   ├── MarketData.mqh              <-- CopyRates caching, history gap detection, bar indexing
│   └── SymbolSpecs.mqh             <-- Native MT5 dynamic symbol property resolver
├── Positions/
│   ├── PositionManager.mqh         <-- Multi-position hedging, partial closes, breakeven, trailing
│   ├── OrderManager.mqh            <-- Pending limit/stop order management and triggering
│   └── OrderExecutionEngine.mqh    <-- Deterministic order routing with spread & slippage
├── Analytics/
│   ├── StatisticsEngine.mqh        <-- Sharpe, Sortino, Calmar, SQN, Expectancy, Win Rate
│   └── JournalEngine.mqh           <-- Trade records, psychological tags, CSV/JSON file writer
├── UI/
│   ├── ChartManager.mqh            <-- Native MT5 graphical objects, clean template, no-scroll
│   ├── MainPanel.mqh               <-- Dark terminal GUI, draggable docking panels
│   ├── ReplayPanel.mqh             <-- Play/Pause/Step/Speed buttons, time readout
│   ├── TradingPanel.mqh            <-- Buy/Sell buttons, lot size, SL/TP inputs, risk calculator
│   └── PositionPanel.mqh           <-- Open positions display, one-click close / modify
├── Session/
│   └── SessionManager.mqh          <-- Save/load simulation state to disk, crash autosave
└── Utils/
    ├── Logger.mqh                  <-- Multi-level structured logger (INFO, WARN, ERROR, DEBUG)
    └── TimeUtils.mqh               <-- Timestamp formatting, session checks (London, NY, Asian)
```

---

## 4. Module Dependencies & Data Flow

```
                                  ┌───────────────────────┐
                                  │   MT5 Strategy Tester │
                                  │   or Live Chart Host  │
                                  └───────────┬───────────┘
                                              │ Rates & Ticks
                                              ▼
                                  ┌───────────────────────┐
                                  │     CMarketData       │
                                  │ (CopyRates, History)  │
                                  └───────────┬───────────┘
                                              │
                                              ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                     CReplayEngine                                      │
│  - Maintains m_current_index (0 .. N)                                                  │
│  - Exposes ONLY historical bars up to current replay timestamp                         │
│  - Emits Step events, respects Play/Pause state and speed multiplier                   │
└─────────────────────────────────────────────┬──────────────────────────────────────────┘
                                              │
                    ┌─────────────────────────┴─────────────────────────┐
                    ▼                                                   ▼
       ┌─────────────────────────┐                         ┌─────────────────────────┐
       │      CMarketEngine      │                         │      CChartManager      │
       │ - Current Bid / Ask     │                         │ - Visual Candle Slicing │
       │ - Spread Model (Hist/Fix│                         │ - Draggable SL/TP lines │
       │ - Slippage Generator    │                         │ - Native MT5 GUI Panels │
       └────────────┬────────────┘                         └────────────┬────────────┘
                    │                                                   │
                    ▼                                                   │
       ┌─────────────────────────┐                                      │
       │  COrderExecutionEngine  │◄─────────────────────────────────────┘ (User Click Events)
       │ - Virtual Market Buy/Sel│
       │ - Pending Order Triggers│
       └────────────┬────────────┘
                    │
                    ▼
       ┌─────────────────────────┐
       │    CPositionManager     │
       │ - Multi-position Hedging│
       │ - Partial Close & SL/TP │
       └──────┬────────────┬─────┘
              │            │
              ▼            ▼
┌─────────────────────┐ ┌─────────────────────┐
│   CAccountEngine    │ │   CJournalEngine    │
│ - Virtual Balance   │ │ - Trade Records     │
│ - Floating/Realized │ │ - JSON & CSV Export │
│ - Margin & Leverage │ │ - MAE / MFE / Pips  │
└─────────────────────┘ └──────────┬──────────┘
                                   │
                                   ▼
                        ┌─────────────────────┐
                        │  CStatisticsEngine  │
                        │ - Sharpe, Sortino   │
                        │ - SQN, Expectancy   │
                        │ - Max Drawdown      │
                        └─────────────────────┘
```

---

## 5. Replay Architecture & No-Lookahead Protection

1. **Physical Slicing of Rates Array:**
   - All historical bars are loaded into `MqlRates m_all_rates[]` sorted chronologically (index 0 is earliest, index $Total - 1$ is latest).
   - The replay state is tracked by integer `m_current_bar_index` and `m_current_tick_index`.
   - Any external query to `GetVisibleRates(MqlRates &out_rates[])` copies strictly elements `0` through `m_current_bar_index`. Elements from `m_current_bar_index + 1` are memory-quarantined.
2. **Intrabar Precision Engine:**
   - In candle replay mode, a single candle can be stepped as 4 micro-ticks: Open $\rightarrow$ Extreme 1 $\rightarrow$ Extreme 2 $\rightarrow$ Close (determined by bullish vs. bearish polarity).
   - Pending orders and Stop Loss / Take Profit are evaluated at each micro-tick price, ensuring no false lookahead fills.
3. **Pacing & Speed Control:**
   - Millisecond timer (`EventSetMillisecondTimer(20)`) advances the clock according to speed:
     - $1\times$: 1 simulated second per real second
     - $10\times$: 10 simulated seconds per real second
     - Candle Step: Instantly advances 1 bar and pauses.

---

## 6. Trading Architecture & Order Execution

1. **Virtual Order Pipeline:**
   - Orders never touch the broker's real server or account.
   - `COrderExecutionEngine::ExecuteMarketOrder()` constructs a virtual ticket, computes required margin based on `SymbolInfoDouble(SYMBOL_MARGIN_INITIAL)`, deducts commission, and registers the position in `CPositionManager`.
2. **Realistic Execution Modeling:**
   - **Spread:** Can be configured as `SPREAD_HISTORICAL` (read from `MqlRates.spread`), `SPREAD_FIXED`, or `SPREAD_RANDOM_RANGE`.
   - **Slippage:** Slippage points are applied to market and stop orders (positive or negative based on Gaussian or fixed configuration).
   - **Hedging:** Supports simultaneous long and short positions on the same symbol with independent tickets, stops, and volumes.
   - **Partial Close:** Reduces position volume, generates a closed trade record for the closed portion, and updates account realized P/L.

---

## 7. Testing Strategy

1. **Unit Test Suite:**
   - Unit tests for margin calculations across Forex (100,000 contract size) and Commodities (100 oz Gold).
   - Mathematical verification of risk calculations: $\text{Lots} = \frac{\text{Risk Amount}}{\text{SL Distance in Points} \times \text{Tick Value}}$.
   - No-lookahead boundary tests: verifying that `m_current_bar_index + 1` is unreachable by any analytics, indicator, or execution method.
2. **Deterministic Backtest Scenario:**
   - Fixed historical segment replay to ensure identical buy/sell sequences produce identical P/L, drawdown, and journal logs.

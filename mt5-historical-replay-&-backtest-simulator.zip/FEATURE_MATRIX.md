# FEATURE MATRIX: POURI-ESCOBAR MARKET REPLAY
**Implementation Matrix for Professional MT5 Historical Market Replay EA**

| Feature | Required? | Current Status | Target Phase | Implementation Notes |
| :--- | :--- | :--- | :--- | :--- |
| **POURI-ESCOBAR-MARKET-REPLAY.mq5 Entry** | YES | Planned | Phase 1 | Main MT5 Expert Advisor entry point with OnInit, OnDeinit, OnTick, OnTimer, OnChartEvent |
| **Historical Data Engine (CopyRates)** | YES | Prototype / Planned | Phase 1 | CMarketData queries real MT5 historical bars; zero fake candles |
| **Strict No-Lookahead Protection** | YES | Prototype / Planned | Phase 1 | Memory quarantine of all bars beyond current replay index |
| **Replay Controls (Play/Pause/Step)** | YES | Prototype / Planned | Phase 1 | In-chart buttons + hotkeys (Space for Play/Pause, Right Arrow for Step) |
| **Replay Speed Modulation (0.1x to 100x)**| YES | Prototype / Planned | Phase 1 | Millisecond timer pacing with speed multiplier array |
| **Virtual Account Engine** | YES | Prototype / Planned | Phase 1 | Virtual balance, equity, margin, free margin, margin level, floating P/L |
| **Manual Market BUY / SELL Execution** | YES | Prototype / Planned | Phase 1 | Bid/Ask execution with virtual ticket generation and immediate position tracking |
| **In-Chart Dark Trading Terminal UI** | YES | Prototype / Planned | Phase 1 | Native MT5 chart buttons and edit controls for high-speed interaction |
| **Stop Loss & Take Profit Setting** | YES | Planned | Phase 2 | User enters SL/TP in price or pips; engine monitors on each replay tick |
| **Draggable SL / TP Chart Lines** | YES | Planned | Phase 2 | Native MT5 `OBJ_HLINE` with live pip/dollar tooltip, interactive drag-and-drop |
| **Multi-Position Hedging** | YES | Planned | Phase 2 | Independent tickets for simultaneous BUY and SELL positions |
| **Partial Close (10%, 25%, 50%, Custom)** | YES | Planned | Phase 2 | Closes partial lot size, adjusts position, logs closed fraction to trade journal |
| **Breakeven & Trailing Stop** | YES | Planned | Phase 2 | Moves SL to entry + offset once market moves specified points |
| **Pending Orders (Limit & Stop)** | YES | Planned | Phase 2 | Buy/Sell Limit, Buy/Sell Stop triggered when simulated price touches level |
| **Spread Simulation (Historical/Fixed)** | YES | Planned | Phase 2 | Reads spread from historical bars or enforces fixed point spread |
| **Commission & Slippage Modeling** | YES | Planned | Phase 2 | Round-turn per-lot commission and Gaussian/fixed point slippage |
| **Position Sizing & Risk Calculator** | YES | Planned | Phase 3 | Calculates recommended lots from Account Balance, Risk %, and SL distance |
| **Trade Markers on Chart (Entry/Exit)** | YES | Planned | Phase 3 | Visual arrows and connecting lines showing executed trade history |
| **Trade Journal Engine** | YES | Planned | Phase 3 | Records trade details, strategy tag, emotion, confidence, MFE, MAE |
| **MAE / MFE Tracking** | YES | Planned | Phase 3 | Maximum Adverse / Favorable Excursion computed continuously per position |
| **Quantitative Statistics Engine** | YES | Planned | Phase 3 | Sharpe Ratio, Sortino Ratio, Calmar Ratio, SQN, Profit Factor, Expectancy |
| **Equity & Drawdown Curve** | YES | Planned | Phase 3 | On-chart or exported equity progression curve tracking peak-to-trough drawdown |
| **Drawing Tools (Trend, Fib, Box, Text)**| YES | Planned | Phase 4 | Native MT5 chart tools managed by DrawingManager with session persistence |
| **Multi-Timeframe Synchronization** | YES | Planned | Phase 4 | Synchronized history across M1, M5, M15, H1, H4 up to identical historical timestamp |
| **Session Highlighting (London, NY, Asia)**| YES | Planned | Phase 4 | Visual vertical bands on chart highlighting session hours without fake news |
| **Replay Bookmarks & Trade Notes** | YES | Planned | Phase 4 | Tag specific replay timestamps with setup notes, mistakes, and learning points |
| **Setup Screenshot Capture** | YES | Planned | Phase 4 | Invokes MT5 `ChartScreenShot` saving PNG image tied to trade ticket |
| **Session Save / Load to Disk** | YES | Planned | Phase 5 | Serializes complete simulation state (account, positions, journal) to JSON file |
| **Autosave & Crash Recovery** | YES | Planned | Phase 5 | Periodic background state dump ensuring zero work lost if MT5 restarts |
| **Prop Firm Challenge Mode** | YES | Planned | Phase 5 | Profit targets, maximum drawdown limit, and daily loss enforcement |
| **Export to JSON & CSV** | YES | Planned | Phase 5 | Full trade history exported to `MQL5/Files/` in AI-ready JSON and standard CSV |
| **Tick Replay & Millisecond Intrabar** | YES | Planned | Phase 6 | Consumes historical tick data from `CopyTicksRange` when available |
| **Margin Call & Stop-Out Enforcement** | YES | Planned | Phase 6 | Liquidates worst positions if Margin Level falls below configured stop-out level |
| **Production Polish & Performance Tuning**| YES | Planned | Phase 7 | Zero lag on large datasets, caching, and comprehensive end-to-end testing |

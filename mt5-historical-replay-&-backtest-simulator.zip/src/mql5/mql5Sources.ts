/**
 * POURI-ESCOBAR-MARKET-REPLAY
 * Soft4FX-Style Dedicated Historical Trading Simulator & Market Replay Workspace for MT5
 */

import { MqlFile } from './types';
import {
  SIMULATION_DEFINES_MQH,
  MARKET_DATA_MQH,
  REPLAY_ENGINE_MQH,
  MARKET_ENGINE_MQH,
  ACCOUNT_ENGINE_MQH,
  POSITION_MANAGER_MQH,
  ORDER_EXECUTION_ENGINE_MQH,
  ORDER_MANAGER_MQH
} from './sources/core';
import {
  REPLAY_DATA_FEED_MQH,
  REPLAY_CANDLE_RENDERER_MQH,
  TRADE_RENDERER_MQH,
  REPLAY_RENDERER_MQH,
  REPLAY_CHART_MQH
} from './sources/chart';
import {
  REPLAY_CONTROL_PANEL_MQH,
  TRADING_PANEL_MQH,
  ACCOUNT_PANEL_MQH,
  POSITIONS_PANEL_MQH,
  JOURNAL_PANEL_MQH,
  MAIN_WORKSPACE_MQH
} from './sources/ui';
import { MODULAR_EA_MQL5, README_INSTALLATION_TXT } from './sources/expert';
import { STANDALONE_WORKSPACE_EA_MQL5 } from './sources/standalone';

export * from './types';

export const ARCHITECTURE_DOCUMENT = `# ARCHITECTURE: POURI-ESCOBAR MARKET REPLAY (SOFT4FX-STYLE MT5 SIMULATOR)
================================================================================
Document Version: 3.0.0
Target Platform: MetaTrader 5 Strategy Tester Visual Mode (MQL5 64-bit Build 4000+)
================================================================================

## 1. PRIMARY OBJECTIVE
POURI-ESCOBAR-MARKET-REPLAY is a dedicated historical manual trading simulator and market
replay environment inside MetaTrader 5 Strategy Tester Visual Mode. It replaces simple chart
line drawing with a dedicated, professional Soft4FX-style trading workspace.

## 2. DEDICATED VISUAL WORKSPACE ARCHITECTURE
When launched in MT5 Strategy Tester Visual Mode:
1. Detects Tester & Visual Mode via MQLInfoInteger(MQL_TESTER) & MQLInfoInteger(MQL_VISUAL_MODE).
2. Dedicated Canvas Replay Engine:
   - High-performance CCanvas renderer (CReplayCandleRenderer).
   - Strict Zero Look-Ahead Guarantee via CReplayDataFeed: future bars beyond current replay
     index are quarantined and never accessible or rendered.
   - Dynamic Zoom (+/- key), Horizontal Pan/Scroll, and Auto-cursor anchoring.
   - Live Bid/Ask quotes & Spread badges.
   - Overlaid Virtual Trades via CTradeRenderer (entry markers, SL/TP lines, pending orders).
3. Independent Virtual Hedging & Account System:
   - Real-time Balance, Equity, Margin, Free Margin, Margin Level %, and Max Drawdown %.
   - Zero broker connection or real money risk.
4. Comprehensive Simulator Panels:
   - Replay Control Panel: [RESET], [|< STEP], [> PLAY / || PAUSE], [STEP >|], [FAST >>],
     and 9 calibrated speed modes (0.1x to 100x).
   - Manual Trading Panel: One-click Market Buy/Sell, Volume +/-/presets, SL/TP in pips,
     Pending Orders, and Quick Close (All/Winners/Losers/Breakeven).
   - Account Telemetry Panel: Live balance, equity, margin, daily P/L.
   - Open Positions Panel: Interactive ticket table with [Close], [Partial 50%], and [BE].
   - Simulation Trade Journal: Audit trail of closed positions with P/L, pips, and reasons.
`;

export const STANDALONE_EA_MQL5 = STANDALONE_WORKSPACE_EA_MQL5;

export const MQL5_SOURCES: MqlFile[] = [
  {
    path: 'Experts/POURI-ESCOBAR-MARKET-REPLAY.mq5',
    name: 'POURI-ESCOBAR-MARKET-REPLAY.mq5',
    category: 'Expert',
    description: '★ Dedicated Soft4FX-Style Simulator EA (Modular Architecture for Strategy Tester Visual Mode)',
    code: MODULAR_EA_MQL5
  },
  {
    path: 'Experts/POURI-ESCOBAR-MARKET-REPLAY-STANDALONE.mq5',
    name: 'POURI-ESCOBAR-MARKET-REPLAY-STANDALONE.mq5',
    category: 'Expert',
    description: '★ 100% Self-Contained Standalone Edition: Paste into MetaEditor & Press F7 to compile with 0 missing file errors!',
    code: STANDALONE_WORKSPACE_EA_MQL5
  },
  {
    path: 'Include/PouriReplay/Data/ReplayDataFeed.mqh',
    name: 'ReplayDataFeed.mqh',
    category: 'Core',
    description: 'CReplayDataFeed: Strict Zero-Lookahead Data Feed Gatekeeper (Quarantines Future Candles)',
    code: REPLAY_DATA_FEED_MQH
  },
  {
    path: 'Include/PouriReplay/Chart/ReplayCandleRenderer.mqh',
    name: 'ReplayCandleRenderer.mqh',
    category: 'Chart',
    description: 'CReplayCandleRenderer: High-Performance CCanvas Historical Replay Candle Engine',
    code: REPLAY_CANDLE_RENDERER_MQH
  },
  {
    path: 'Include/PouriReplay/Chart/TradeRenderer.mqh',
    name: 'TradeRenderer.mqh',
    category: 'Chart',
    description: 'CTradeRenderer: Overlays Virtual Positions, SL/TP Levels & Pending Orders on Canvas',
    code: TRADE_RENDERER_MQH
  },
  {
    path: 'Include/PouriReplay/Chart/ReplayRenderer.mqh',
    name: 'ReplayRenderer.mqh',
    category: 'Chart',
    description: 'CReplayRenderer: Master Canvas Replay Engine coordinating Candles and Trade Overlays',
    code: REPLAY_RENDERER_MQH
  },
  {
    path: 'Include/PouriReplay/Chart/ReplayChart.mqh',
    name: 'ReplayChart.mqh',
    category: 'Chart',
    description: 'CReplayChart: Dedicated Historical Chart Visualizer (Candles, Bid/Ask, Entry Markers, SL/TP Lines, Connectors)',
    code: REPLAY_CHART_MQH
  },
  {
    path: 'Include/PouriReplay/UI/ReplayControlPanel.mqh',
    name: 'ReplayControlPanel.mqh',
    category: 'UI',
    description: 'CReplayControlPanel: Soft4FX-Style Fixed Replay Controller (Reset, Step, Play/Pause, 0.1x to 100x Speeds)',
    code: REPLAY_CONTROL_PANEL_MQH
  },
  {
    path: 'Include/PouriReplay/UI/TradingPanel.mqh',
    name: 'TradingPanel.mqh',
    category: 'UI',
    description: 'CTradingPanel: Dedicated Manual Trading Panel (Buy/Sell Market, Buy/Sell Limit & Stop, Close All/Winners/Losers)',
    code: TRADING_PANEL_MQH
  },
  {
    path: 'Include/PouriReplay/UI/AccountPanel.mqh',
    name: 'AccountPanel.mqh',
    category: 'UI',
    description: 'CAccountPanel: Permanent Virtual Account Telemetry (Balance, Equity, Floating P/L, Margin, Drawdown %)',
    code: ACCOUNT_PANEL_MQH
  },
  {
    path: 'Include/PouriReplay/UI/PositionsPanel.mqh',
    name: 'PositionsPanel.mqh',
    category: 'UI',
    description: 'CPositionsPanel: Open Positions & Orders Table with Interactive Actions ([Close], [Partial 50%], [BE])',
    code: POSITIONS_PANEL_MQH
  },
  {
    path: 'Include/PouriReplay/UI/JournalPanel.mqh',
    name: 'JournalPanel.mqh',
    category: 'UI',
    description: 'CJournalPanel: Simulation Trade Journal & Execution Audit Log of Closed Positions',
    code: JOURNAL_PANEL_MQH
  },
  {
    path: 'Include/PouriReplay/UI/MainWorkspace.mqh',
    name: 'MainWorkspace.mqh',
    category: 'UI',
    description: 'CMainWorkspace: Master Workspace Manager coordinating Top Status Banner, Panel Docking & Dynamic Resizing',
    code: MAIN_WORKSPACE_MQH
  },
  {
    path: 'Include/PouriReplay/Positions/OrderManager.mqh',
    name: 'OrderManager.mqh',
    category: 'Trading',
    description: 'COrderManager: Virtual Pending Orders Engine (Buy/Sell Limit, Buy/Sell Stop triggers & cancellation)',
    code: ORDER_MANAGER_MQH
  },
  {
    path: 'Include/PouriReplay/Core/SimulationDefines.mqh',
    name: 'SimulationDefines.mqh',
    category: 'Core',
    description: 'Shared constants, enums, structs for positions, orders, account and replay modes',
    code: SIMULATION_DEFINES_MQH
  },
  {
    path: 'Include/PouriReplay/Data/MarketData.mqh',
    name: 'MarketData.mqh',
    category: 'Core',
    description: 'CMarketData: Authoritative Historical Cache with Zero-Lookahead memory quarantine',
    code: MARKET_DATA_MQH
  },
  {
    path: 'Include/PouriReplay/Core/ReplayEngine.mqh',
    name: 'ReplayEngine.mqh',
    category: 'Core',
    description: 'CReplayEngine: Replay clock, millisecond pacing, step-by-step navigation, and speed control',
    code: REPLAY_ENGINE_MQH
  },
  {
    path: 'Include/PouriReplay/Core/MarketEngine.mqh',
    name: 'MarketEngine.mqh',
    category: 'Core',
    description: 'CMarketEngine: Synthetic Bid/Ask pricing, spread models, and slippage deviation simulation',
    code: MARKET_ENGINE_MQH
  },
  {
    path: 'Include/PouriReplay/Core/AccountEngine.mqh',
    name: 'AccountEngine.mqh',
    category: 'Core',
    description: 'CAccountEngine: Virtual account balance, margin requirements, leverage, equity & drawdown tracker',
    code: ACCOUNT_ENGINE_MQH
  },
  {
    path: 'Include/PouriReplay/Positions/PositionManager.mqh',
    name: 'PositionManager.mqh',
    category: 'Trading',
    description: 'CPositionManager: Virtual hedging position manager, multi-lot tracking, and SL/TP trigger evaluation',
    code: POSITION_MANAGER_MQH
  },
  {
    path: 'Include/PouriReplay/Positions/OrderExecutionEngine.mqh',
    name: 'OrderExecutionEngine.mqh',
    category: 'Trading',
    description: 'COrderExecutionEngine: Order validation, margin sufficiency checking, and market execution',
    code: ORDER_EXECUTION_ENGINE_MQH
  },
  {
    path: 'README_INSTALLATION.txt',
    name: 'README_INSTALLATION.txt',
    category: 'Documentation',
    description: 'Quick Start: How to run in MT5 Strategy Tester Visual Mode',
    code: README_INSTALLATION_TXT
  }
];

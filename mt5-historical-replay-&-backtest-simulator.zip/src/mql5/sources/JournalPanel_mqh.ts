import { JOURNAL_PANEL_MQH } from './ui';
export const JOURNAL_PANEL_MQH_FILE = JOURNAL_PANEL_MQH;

import { TRADE_RENDERER_MQH } from './chart';
export const TRADE_RENDERER_MQH_FILE = TRADE_RENDERER_MQH;

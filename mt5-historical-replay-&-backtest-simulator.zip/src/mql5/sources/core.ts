import { MqlFile } from '../types';

export const SIMULATION_DEFINES_MQH = `//+------------------------------------------------------------------+
//|                                            SimulationDefines.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

//--- Replay Run State
enum ENUM_REPLAY_STATE
{
   REPLAY_STATE_PAUSED   = 0, // Replay is currently paused
   REPLAY_STATE_RUNNING  = 1, // Replay is playing forward
   REPLAY_STATE_STOPPED  = 2  // Replay reached end of dataset
};

//--- Replay Speed Multipliers (Soft4FX-style calibrated pacing)
enum ENUM_REPLAY_SPEED
{
   SPEED_0_1X   = 0,   // 0.1x Speed
   SPEED_0_25X  = 1,   // 0.25x Speed
   SPEED_0_5X   = 2,   // 0.5x Speed
   SPEED_1X     = 3,   // 1.0x Real-time
   SPEED_2X     = 4,   // 2.0x Speed
   SPEED_5X     = 5,   // 5.0x Speed
   SPEED_10X    = 6,   // 10.0x Speed
   SPEED_25X    = 7,   // 25.0x Speed
   SPEED_50X    = 8,   // 50.0x Speed
   SPEED_100X   = 9    // 100.0x Speed
};

//--- Replay Progression Mode
enum ENUM_REPLAY_MODE
{
   REPLAY_MODE_CANDLE   = 0, // Bar-by-bar progressive stepping
   REPLAY_MODE_INTRABAR = 1, // 4-microticks per bar (O -> Extreme1 -> Extreme2 -> C)
   REPLAY_MODE_TICK     = 2  // Exact historical tick replay from Strategy Tester
};

//--- Trade Direction
enum ENUM_TRADE_DIRECTION
{
   DIRECTION_BUY  = 0,
   DIRECTION_SELL = 1
};

//--- Virtual Order Type
enum ENUM_SIM_ORDER_TYPE
{
   SIM_ORDER_MARKET_BUY  = 0,
   SIM_ORDER_MARKET_SELL = 1,
   SIM_ORDER_BUY_LIMIT   = 2,
   SIM_ORDER_SELL_LIMIT  = 3,
   SIM_ORDER_BUY_STOP    = 4,
   SIM_ORDER_SELL_STOP   = 5
};

//--- Spread Simulation Model
enum ENUM_SPREAD_MODEL
{
   SPREAD_HISTORICAL   = 0, // Direct from historical rates
   SPREAD_FIXED        = 1, // Fixed points
   SPREAD_RANDOM_RANGE = 2  // Jitter within min/max bounds
};

//--- Slippage Simulation Model
enum ENUM_SLIPPAGE_MODEL
{
   SLIPPAGE_NONE   = 0, // Zero slippage
   SLIPPAGE_FIXED  = 1, // Fixed point deviation
   SLIPPAGE_RANDOM = 2  // Stochastic normal deviation
};

//--- Simulation Constants
#define SIM_DEFAULT_INITIAL_BALANCE  10000.0
#define SIM_DEFAULT_LEVERAGE          100.0
#define SIM_DEFAULT_COMMISSION_LOT    7.0
#define SIM_TIMER_INTERVAL_MS         25      // 40 fps clock cycle
#define SIM_MAX_POSITIONS             100
#define SIM_MAX_PENDING               50

//--- Virtual Position Struct
struct SimPosition
{
   long                 ticket;          // Unique virtual ticket ID
   string               symbol;          // Symbol name
   ENUM_TRADE_DIRECTION direction;       // BUY or SELL
   double               lots;            // Volume in lots
   double               open_price;      // Open price (Ask for BUY, Bid for SELL)
   datetime             open_time;       // Historical timestamp of entry
   double               sl;              // Stop Loss price
   double               tp;              // Take Profit price
   double               current_price;   // Marked-to-market current price
   double               floating_profit; // Current floating P/L ($)
   double               floating_pips;   // Current floating pips
   double               commission;      // Round-turn commission
   double               swap;            // Accumulated swap
   string               comment;         // Trade comment
   bool                 is_open;         // Active status flag
};

//--- Virtual Pending Order Struct
struct SimPendingOrder
{
   long                 ticket;          // Unique order ticket
   string               symbol;          // Symbol
   ENUM_SIM_ORDER_TYPE  order_type;      // BUY_LIMIT, SELL_LIMIT, BUY_STOP, SELL_STOP
   double               lots;            // Volume
   double               target_price;    // Order trigger price
   double               sl;              // Stop Loss
   double               tp;              // Take Profit
   datetime             placed_time;     // Time placed
   string               comment;         // Comment
   bool                 is_active;       // Active state
};

//--- Closed Trade Struct (for Journal & Visualization)
struct SimClosedTrade
{
   long                 ticket;
   string               symbol;
   ENUM_TRADE_DIRECTION direction;
   double               lots;
   double               open_price;
   datetime             open_time;
   double               close_price;
   datetime             close_time;
   double               realized_profit;
   double               pips;
   string               close_reason;    // "MANUAL", "SL", "TP", "CLOSE_ALL"
};

//--- Virtual Account State
struct SimAccountState
{
   double balance;
   double equity;
   double margin;
   double free_margin;
   double margin_level;
   double floating_pnl;
   double realized_pnl;
   double peak_equity;
   double max_drawdown;
   double max_drawdown_pct;
   double daily_pnl;
   int    open_positions_count;
   int    pending_orders_count;
};
`;

export const MARKET_DATA_MQH = `//+------------------------------------------------------------------+
//|                                                   MarketData.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"

//+------------------------------------------------------------------+
//| Class CMarketData: Authoritative Historical Cache & Accessor    |
//| Enforces ZERO LOOK-AHEAD: Downstream components cannot access    |
//| bars beyond the current replay cursor.                          |
//+------------------------------------------------------------------+
class CMarketData
{
private:
   string       m_symbol;
   ENUM_TIMEFRAMES m_timeframe;
   MqlRates     m_rates[];           // Ascending chronological array [0..N-1]
   int          m_total_bars;
   double       m_point;
   int          m_digits;
   double       m_contract_size;
   double       m_tick_value;
   double       m_tick_size;

public:
   CMarketData()
   {
      m_symbol = "";
      m_timeframe = PERIOD_CURRENT;
      m_total_bars = 0;
      m_point = 0.00001;
      m_digits = 5;
      m_contract_size = 100000.0;
      m_tick_value = 1.0;
      m_tick_size = 0.00001;
      ArrayResize(m_rates, 0);
   }

   bool LoadHistoryCount(const string symbol, const ENUM_TIMEFRAMES timeframe, const int count)
   {
      m_symbol = (symbol == "") ? _Symbol : symbol;
      m_timeframe = (timeframe == PERIOD_CURRENT) ? _Period : timeframe;

      m_point         = SymbolInfoDouble(m_symbol, SYMBOL_POINT);
      m_digits        = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
      m_contract_size = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_CONTRACT_SIZE);
      m_tick_value    = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_VALUE);
      m_tick_size     = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_SIZE);

      if (m_point == 0.0) m_point = 0.001;
      if (m_tick_size == 0.0) m_tick_size = m_point;
      if (m_tick_value == 0.0) m_tick_value = 1.0;
      if (m_contract_size == 0.0) m_contract_size = 100.0; // e.g. Gold 100oz

      ArraySetAsSeries(m_rates, false);
      int copied = CopyRates(m_symbol, m_timeframe, 0, count, m_rates);
      if (copied <= 0)
      {
         PrintFormat("[CMarketData] Error: CopyRates failed for %s. Code: %d", m_symbol, GetLastError());
         return false;
      }

      m_total_bars = copied;
      PrintFormat("[CMarketData] Successfully cached %d historical bars for %s. Time span: %s -> %s",
                  m_total_bars, m_symbol, TimeToString(m_rates[0].time), TimeToString(m_rates[m_total_bars-1].time));
      return true;
   }

   bool GetBar(const int index, MqlRates &out_rate) const
   {
      if (index < 0 || index >= m_total_bars) return false;
      out_rate = m_rates[index];
      return true;
   }

   int             GetTotalBars() const     { return m_total_bars; }
   string          GetSymbol() const        { return m_symbol; }
   ENUM_TIMEFRAMES GetTimeframe() const     { return m_timeframe; }
   double          GetPoint() const         { return m_point; }
   int             GetDigits() const        { return m_digits; }
   double          GetContractSize() const  { return m_contract_size; }
   double          GetTickValue() const     { return m_tick_value; }
   double          GetTickSize() const      { return m_tick_size; }
};
`;

export const REPLAY_ENGINE_MQH = `//+------------------------------------------------------------------+
//|                                                 ReplayEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"

//+------------------------------------------------------------------+
//| Class CReplayEngine: Replay clock, pacing, and stepping controller|
//+------------------------------------------------------------------+
class CReplayEngine
{
private:
   CMarketData      *m_market_data;
   ENUM_REPLAY_STATE m_state;
   ENUM_REPLAY_SPEED m_speed;
   ENUM_REPLAY_MODE  m_mode;
   int               m_current_bar_index;
   datetime          m_current_time;
   ulong             m_last_timer_tick;
   double            m_accumulated_ms;
   double            m_speed_multipliers[10];

public:
   CReplayEngine()
   {
      m_market_data = NULL;
      m_state = REPLAY_STATE_PAUSED;
      m_speed = SPEED_1X;
      m_mode = REPLAY_MODE_CANDLE;
      m_current_bar_index = 0;
      m_current_time = 0;
      m_last_timer_tick = 0;
      m_accumulated_ms = 0.0;

      m_speed_multipliers[0] = 0.10;
      m_speed_multipliers[1] = 0.25;
      m_speed_multipliers[2] = 0.50;
      m_speed_multipliers[3] = 1.00;
      m_speed_multipliers[4] = 2.00;
      m_speed_multipliers[5] = 5.00;
      m_speed_multipliers[6] = 10.0;
      m_speed_multipliers[7] = 25.0;
      m_speed_multipliers[8] = 50.0;
      m_speed_multipliers[9] = 100.0;
   }

   bool Initialize(CMarketData *market_data, const int start_bar_index = 100)
   {
      if (market_data == NULL) return false;
      m_market_data = market_data;
      int total = m_market_data.GetTotalBars();
      if (total <= 0) return false;

      m_current_bar_index = MathMin(start_bar_index, total - 1);
      m_current_bar_index = MathMax(0, m_current_bar_index);

      MqlRates rate;
      if (m_market_data.GetBar(m_current_bar_index, rate)) m_current_time = rate.time;
      m_state = REPLAY_STATE_PAUSED;
      m_last_timer_tick = GetMicrosecondCount() / 1000;
      return true;
   }

   void Play()               { m_state = REPLAY_STATE_RUNNING; }
   void Pause()              { m_state = REPLAY_STATE_PAUSED; }
   void TogglePlayPause()    { if (m_state == REPLAY_STATE_RUNNING) Pause(); else Play(); }
   void Reset(const int start_bar = 50)
   {
      m_current_bar_index = MathMax(0, start_bar);
      MqlRates rate;
      if (m_market_data != NULL && m_market_data.GetBar(m_current_bar_index, rate))
         m_current_time = rate.time;
      m_state = REPLAY_STATE_PAUSED;
      m_accumulated_ms = 0.0;
   }

   bool StepNext()
   {
      if (m_market_data == NULL) return false;
      int total = m_market_data.GetTotalBars();
      if (m_current_bar_index + 1 >= total)
      {
         m_state = REPLAY_STATE_STOPPED;
         return false;
      }
      m_current_bar_index++;
      MqlRates rate;
      if (m_market_data.GetBar(m_current_bar_index, rate)) m_current_time = rate.time;
      return true;
   }

   bool StepPrev()
   {
      if (m_market_data == NULL || m_current_bar_index <= 0) return false;
      m_current_bar_index--;
      MqlRates rate;
      if (m_market_data.GetBar(m_current_bar_index, rate)) m_current_time = rate.time;
      return true;
   }

   void FastForward(const int bars = 10)
   {
      for (int i = 0; i < bars; i++)
      {
         if (!StepNext()) break;
      }
   }

   void SetSpeed(const ENUM_REPLAY_SPEED speed) { m_speed = speed; }
   void SetMode(const ENUM_REPLAY_MODE mode)    { m_mode = mode; }

   bool OnTimerTick(const ulong current_tick_ms)
   {
      if (m_last_timer_tick == 0) { m_last_timer_tick = current_tick_ms; return false; }
      ulong delta_ms = current_tick_ms - m_last_timer_tick;
      m_last_timer_tick = current_tick_ms;

      if (m_state != REPLAY_STATE_RUNNING) return false;

      double mult = m_speed_multipliers[(int)m_speed];
      double ms_per_bar = 1000.0 / mult;
      m_accumulated_ms += (double)delta_ms;

      bool stepped = false;
      while (m_accumulated_ms >= ms_per_bar)
      {
         m_accumulated_ms -= ms_per_bar;
         if (!StepNext()) break;
         stepped = true;
      }
      return stepped;
   }

   ENUM_REPLAY_STATE   GetState() const { return m_state; }
   ENUM_REPLAY_SPEED   GetSpeed() const { return m_speed; }
   ENUM_REPLAY_MODE    GetMode() const  { return m_mode; }
   int                 GetCurrentIndex() const { return m_current_bar_index; }
   datetime            GetCurrentTime() const { return m_current_time; }
   double              GetSpeedMultiplier() const { return m_speed_multipliers[(int)m_speed]; }
   string              GetSpeedString() const
   {
      switch(m_speed)
      {
         case SPEED_0_1X:  return "0.1X";
         case SPEED_0_25X: return "0.25X";
         case SPEED_0_5X:  return "0.5X";
         case SPEED_1X:    return "1X";
         case SPEED_2X:    return "2X";
         case SPEED_5X:    return "5X";
         case SPEED_10X:   return "10X";
         case SPEED_25X:   return "25X";
         case SPEED_50X:   return "50X";
         case SPEED_100X:  return "100X";
         default:          return "1X";
      }
   }
   double GetProgressPercent() const
   {
      if (m_market_data == NULL || m_market_data.GetTotalBars() <= 1) return 0.0;
      return ((double)m_current_bar_index / (double)(m_market_data.GetTotalBars() - 1)) * 100.0;
   }
};
`;

export const MARKET_ENGINE_MQH = `//+------------------------------------------------------------------+
//|                                                 MarketEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Core/ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CMarketEngine: Synthetic Bid/Ask, Spread, and Slippage     |
//+------------------------------------------------------------------+
class CMarketEngine
{
private:
   CMarketData        *m_market_data;
   CReplayEngine      *m_replay_engine;
   ENUM_SPREAD_MODEL   m_spread_model;
   ENUM_SLIPPAGE_MODEL m_slippage_model;
   double              m_fixed_spread_pts;
   double              m_fixed_slippage_pts;
   double              m_current_bid;
   double              m_current_ask;
   double              m_current_spread_pts;

public:
   CMarketEngine()
   {
      m_market_data = NULL;
      m_replay_engine = NULL;
      m_spread_model = SPREAD_HISTORICAL;
      m_slippage_model = SLIPPAGE_NONE;
      m_fixed_spread_pts = 15.0;
      m_fixed_slippage_pts = 0.0;
      m_current_bid = 0.0;
      m_current_ask = 0.0;
      m_current_spread_pts = 15.0;
   }

   bool Initialize(CMarketData *market_data, CReplayEngine *replay_engine)
   {
      if (market_data == NULL || replay_engine == NULL) return false;
      m_market_data = market_data;
      m_replay_engine = replay_engine;
      UpdateQuotes();
      return true;
   }

   void SetSpreadModel(const ENUM_SPREAD_MODEL model, const double fixed_pts = 15.0)
   {
      m_spread_model = model;
      m_fixed_spread_pts = fixed_pts;
   }

   void SetSlippageModel(const ENUM_SLIPPAGE_MODEL model, const double fixed_pts = 0.0)
   {
      m_slippage_model = model;
      m_fixed_slippage_pts = fixed_pts;
   }

   void UpdateQuotes()
   {
      if (m_market_data == NULL || m_replay_engine == NULL) return;

      int cur_idx = m_replay_engine.GetCurrentIndex();
      MqlRates bar;
      if (!m_market_data.GetBar(cur_idx, bar)) return;

      m_current_bid = bar.close;
      double pt = m_market_data.GetPoint();

      if (m_spread_model == SPREAD_FIXED)
      {
         m_current_spread_pts = m_fixed_spread_pts;
      }
      else if (m_spread_model == SPREAD_RANDOM_RANGE)
      {
         m_current_spread_pts = m_fixed_spread_pts + (MathMod(GetMicrosecondCount(), 10) - 5);
         if (m_current_spread_pts < 5.0) m_current_spread_pts = 5.0;
      }
      else
      {
         m_current_spread_pts = (bar.spread > 0) ? (double)bar.spread : m_fixed_spread_pts;
      }

      m_current_ask = NormalizeDouble(m_current_bid + (m_current_spread_pts * pt), m_market_data.GetDigits());
   }

   double ApplySlippage(const double requested_price, const ENUM_TRADE_DIRECTION dir, const bool is_entry)
   {
      if (m_slippage_model == SLIPPAGE_NONE || m_market_data == NULL) return requested_price;
      double pt = m_market_data.GetPoint();
      double dev = m_fixed_slippage_pts * pt;

      if (m_slippage_model == SLIPPAGE_RANDOM)
      {
         int r = (int)MathMod(GetMicrosecondCount(), 5);
         dev = (double)r * pt;
      }

      if (dir == DIRECTION_BUY)
         return is_entry ? requested_price + dev : requested_price - dev;
      else
         return is_entry ? requested_price - dev : requested_price + dev;
   }

   double GetBid() const           { return m_current_bid; }
   double GetAsk() const           { return m_current_ask; }
   double GetSpreadPoints() const  { return m_current_spread_pts; }
   double GetSpreadPips() const    { return m_current_spread_pts / 10.0; }
};
`;

export const ACCOUNT_ENGINE_MQH = `//+------------------------------------------------------------------+
//|                                                AccountEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"

//+------------------------------------------------------------------+
//| Class CAccountEngine: Virtual Balance, Margin, Equity & Drawdown |
//+------------------------------------------------------------------+
class CAccountEngine
{
private:
   CMarketData     *m_market_data;
   SimAccountState  m_state;
   double           m_leverage;
   double           m_commission_per_lot;
   datetime         m_current_day_start;
   double           m_day_start_equity;

public:
   CAccountEngine()
   {
      m_market_data = NULL;
      m_leverage = SIM_DEFAULT_LEVERAGE;
      m_commission_per_lot = SIM_DEFAULT_COMMISSION_LOT;
      ZeroMemory(m_state);
      m_current_day_start = 0;
      m_day_start_equity = 0.0;
   }

   bool Initialize(CMarketData *market_data, const double initial_balance = SIM_DEFAULT_INITIAL_BALANCE, const double leverage = SIM_DEFAULT_LEVERAGE)
   {
      if (market_data == NULL) return false;
      m_market_data = market_data;
      m_leverage = (leverage <= 0) ? 100.0 : leverage;

      m_state.balance = initial_balance;
      m_state.equity = initial_balance;
      m_state.peak_equity = initial_balance;
      m_state.margin = 0.0;
      m_state.free_margin = initial_balance;
      m_state.margin_level = 0.0;
      m_state.floating_pnl = 0.0;
      m_state.realized_pnl = 0.0;
      m_state.max_drawdown = 0.0;
      m_state.max_drawdown_pct = 0.0;
      m_state.daily_pnl = 0.0;
      m_state.open_positions_count = 0;
      m_state.pending_orders_count = 0;

      m_day_start_equity = initial_balance;
      return true;
   }

   void SetCommissionPerLot(const double comm) { m_commission_per_lot = comm; }

   double CalculateRequiredMargin(const double lots, const double price) const
   {
      if (m_market_data == NULL || m_leverage <= 0) return 0.0;
      double contract = m_market_data.GetContractSize();
      return (lots * contract * price) / m_leverage;
   }

   bool HasSufficientMargin(const double lots, const double price) const
   {
      double req = CalculateRequiredMargin(lots, price);
      return (m_state.free_margin >= req);
   }

   void ApplyRealizedTrade(const double pnl, const double commission, const double swap = 0.0)
   {
      double net = pnl - commission + swap;
      m_state.balance += net;
      m_state.realized_pnl += net;
   }

   void UpdateEquityAndMargin(const double total_floating_profit, const double total_used_margin, const int open_pos_count, const int pending_count, const datetime current_time = 0)
   {
      m_state.floating_pnl = total_floating_profit;
      m_state.margin = total_used_margin;
      m_state.equity = m_state.balance + m_state.floating_pnl;
      m_state.free_margin = m_state.equity - m_state.margin;
      m_state.open_positions_count = open_pos_count;
      m_state.pending_orders_count = pending_count;

      if (m_state.margin > 0.0)
         m_state.margin_level = (m_state.equity / m_state.margin) * 100.0;
      else
         m_state.margin_level = 0.0;

      if (m_state.equity > m_state.peak_equity)
         m_state.peak_equity = m_state.equity;

      double dd = m_state.peak_equity - m_state.equity;
      if (dd > m_state.max_drawdown) m_state.max_drawdown = dd;

      if (m_state.peak_equity > 0.0)
      {
         double dd_pct = (dd / m_state.peak_equity) * 100.0;
         if (dd_pct > m_state.max_drawdown_pct) m_state.max_drawdown_pct = dd_pct;
      }

      // Check daily P/L reset at 00:00
      if (current_time > 0)
      {
         datetime day_floor = current_time - (current_time % 86400);
         if (m_current_day_start != day_floor)
         {
            m_current_day_start = day_floor;
            m_day_start_equity = m_state.equity;
         }
         m_state.daily_pnl = m_state.equity - m_day_start_equity;
      }
   }

   SimAccountState GetState() const               { return m_state; }
   double          GetBalance() const             { return m_state.balance; }
   double          GetEquity() const              { return m_state.equity; }
   double          GetFloatingPnL() const         { return m_state.floating_pnl; }
   double          GetRealizedPnL() const         { return m_state.realized_pnl; }
   double          GetMargin() const              { return m_state.margin; }
   double          GetFreeMargin() const          { return m_state.free_margin; }
   double          GetMarginLevel() const         { return m_state.margin_level; }
   double          GetDrawdownPct() const         { return m_state.max_drawdown_pct; }
   double          GetDailyPnL() const            { return m_state.daily_pnl; }
   double          GetCommissionPerLot() const    { return m_commission_per_lot; }
};
`;

export const POSITION_MANAGER_MQH = `//+------------------------------------------------------------------+
//|                                              PositionManager.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Core/AccountEngine.mqh"

//+------------------------------------------------------------------+
//| Class CPositionManager: Virtual Hedging Positions & SL/TP Engine |
//+------------------------------------------------------------------+
class CPositionManager
{
private:
   CMarketData     *m_market_data;
   CAccountEngine  *m_account_engine;
   SimPosition      m_positions[];
   SimClosedTrade   m_closed_history[];
   long             m_next_ticket;
   int              m_total_positions;
   int              m_total_closed;

public:
   CPositionManager()
   {
      m_market_data = NULL;
      m_account_engine = NULL;
      m_next_ticket = 1001;
      m_total_positions = 0;
      m_total_closed = 0;
      ArrayResize(m_positions, 0);
      ArrayResize(m_closed_history, 0);
   }

   bool Initialize(CMarketData *market_data, CAccountEngine *account_engine)
   {
      if (market_data == NULL || account_engine == NULL) return false;
      m_market_data = market_data;
      m_account_engine = account_engine;
      return true;
   }

   long AddPosition(const string symbol, const ENUM_TRADE_DIRECTION dir, const double lots, const double price, const datetime open_time, const double sl = 0.0, const double tp = 0.0, const string comment = "")
   {
      if (m_total_positions >= SIM_MAX_POSITIONS)
      {
         Print("[CPositionManager] Max active positions reached!");
         return 0;
      }

      int new_size = m_total_positions + 1;
      ArrayResize(m_positions, new_size);

      long ticket = m_next_ticket++;
      m_positions[m_total_positions].ticket          = ticket;
      m_positions[m_total_positions].symbol          = symbol;
      m_positions[m_total_positions].direction       = dir;
      m_positions[m_total_positions].lots            = lots;
      m_positions[m_total_positions].open_price      = price;
      m_positions[m_total_positions].open_time       = open_time;
      m_positions[m_total_positions].sl              = sl;
      m_positions[m_total_positions].tp              = tp;
      m_positions[m_total_positions].current_price   = price;
      m_positions[m_total_positions].floating_profit = 0.0;
      m_positions[m_total_positions].floating_pips   = 0.0;
      m_positions[m_total_positions].commission      = lots * m_account_engine.GetCommissionPerLot();
      m_positions[m_total_positions].swap            = 0.0;
      m_positions[m_total_positions].comment         = comment;
      m_positions[m_total_positions].is_open         = true;

      m_total_positions++;
      PrintFormat("[CPositionManager] Opened #%d %s %.2f @ %.5f | SL: %.5f | TP: %.5f",
                  ticket, (dir == DIRECTION_BUY ? "BUY" : "SELL"), lots, price, sl, tp);
      return ticket;
   }

   bool ClosePosition(const long ticket, const double close_price, const datetime close_time, const string reason = "MANUAL")
   {
      int idx = FindPositionIndex(ticket);
      if (idx < 0) return false;

      SimPosition pos = m_positions[idx];
      double pt = m_market_data.GetPoint();
      double tv = m_market_data.GetTickValue();
      double ts = m_market_data.GetTickSize();
      if (ts == 0.0) ts = pt;

      double diff = (pos.direction == DIRECTION_BUY) ? (close_price - pos.open_price) : (pos.open_price - close_price);
      double pnl = (diff / ts) * tv * pos.lots;
      double pips = diff / (pt * 10.0);

      // Record in closed trade history
      int c_idx = m_total_closed;
      m_total_closed++;
      ArrayResize(m_closed_history, m_total_closed);
      m_closed_history[c_idx].ticket          = pos.ticket;
      m_closed_history[c_idx].symbol          = pos.symbol;
      m_closed_history[c_idx].direction       = pos.direction;
      m_closed_history[c_idx].lots            = pos.lots;
      m_closed_history[c_idx].open_price      = pos.open_price;
      m_closed_history[c_idx].open_time       = pos.open_time;
      m_closed_history[c_idx].close_price     = close_price;
      m_closed_history[c_idx].close_time      = close_time;
      m_closed_history[c_idx].realized_profit = pnl;
      m_closed_history[c_idx].pips            = pips;
      m_closed_history[c_idx].close_reason    = reason;

      m_account_engine.ApplyRealizedTrade(pnl, pos.commission, pos.swap);

      // Remove from active array
      for (int i = idx; i < m_total_positions - 1; i++)
      {
         m_positions[i] = m_positions[i + 1];
      }
      m_total_positions--;
      ArrayResize(m_positions, m_total_positions);

      PrintFormat("[CPositionManager] Closed #%d %s %.2f @ %.5f [P/L: $%.2f / %.1f pips] Reason: %s",
                  ticket, (pos.direction == DIRECTION_BUY ? "BUY" : "SELL"), pos.lots, close_price, pnl, pips, reason);
      return true;
   }

   bool PartialClose(const long ticket, const double close_lots, const double close_price, const datetime close_time)
   {
      int idx = FindPositionIndex(ticket);
      if (idx < 0) return false;

      SimPosition pos = m_positions[idx];
      if (close_lots >= pos.lots - 0.0001)
      {
         return ClosePosition(ticket, close_price, close_time, "PARTIAL_FULL");
      }

      double remaining_lots = pos.lots - close_lots;
      double pt = m_market_data.GetPoint();
      double tv = m_market_data.GetTickValue();
      double ts = m_market_data.GetTickSize();
      if (ts == 0.0) ts = pt;

      double diff = (pos.direction == DIRECTION_BUY) ? (close_price - pos.open_price) : (pos.open_price - close_price);
      double pnl = (diff / ts) * tv * close_lots;
      double comm = close_lots * m_account_engine.GetCommissionPerLot();

      m_account_engine.ApplyRealizedTrade(pnl, comm, 0.0);

      m_positions[idx].lots = remaining_lots;
      m_positions[idx].commission = remaining_lots * m_account_engine.GetCommissionPerLot();

      PrintFormat("[CPositionManager] Partial closed #%d: %.2f lots closed @ %.5f (P/L: $%.2f), %.2f lots remain",
                  ticket, close_lots, close_price, pnl, remaining_lots);
      return true;
   }

   void ModifyPosition(const long ticket, const double new_sl, const double new_tp)
   {
      int idx = FindPositionIndex(ticket);
      if (idx < 0) return;
      m_positions[idx].sl = new_sl;
      m_positions[idx].tp = new_tp;
      PrintFormat("[CPositionManager] Modified #%d SL: %.5f | TP: %.5f", ticket, new_sl, new_tp);
   }

   void MoveToBreakeven(const long ticket)
   {
      int idx = FindPositionIndex(ticket);
      if (idx < 0) return;
      m_positions[idx].sl = m_positions[idx].open_price;
      PrintFormat("[CPositionManager] Moved #%d to Break-Even @ %.5f", ticket, m_positions[idx].open_price);
   }

   void UpdatePositions(const double bid, const double ask, const datetime current_time)
   {
      if (m_market_data == NULL) return;
      double pt = m_market_data.GetPoint();
      double tv = m_market_data.GetTickValue();
      double ts = m_market_data.GetTickSize();
      if (ts == 0.0) ts = pt;

      for (int i = m_total_positions - 1; i >= 0; i--)
      {
         SimPosition pos = m_positions[i];
         double cur_p = (pos.direction == DIRECTION_BUY) ? bid : ask;
         m_positions[i].current_price = cur_p;

         double diff = (pos.direction == DIRECTION_BUY) ? (cur_p - pos.open_price) : (pos.open_price - cur_p);
         m_positions[i].floating_profit = (diff / ts) * tv * pos.lots - pos.commission + pos.swap;
         m_positions[i].floating_pips = diff / (pt * 10.0);

         // Check SL / TP triggers
         if (pos.direction == DIRECTION_BUY)
         {
            if (pos.sl > 0.0 && bid <= pos.sl)
            {
               ClosePosition(pos.ticket, pos.sl, current_time, "SL");
               continue;
            }
            if (pos.tp > 0.0 && bid >= pos.tp)
            {
               ClosePosition(pos.ticket, pos.tp, current_time, "TP");
               continue;
            }
         }
         else // SELL
         {
            if (pos.sl > 0.0 && ask >= pos.sl)
            {
               ClosePosition(pos.ticket, pos.sl, current_time, "SL");
               continue;
            }
            if (pos.tp > 0.0 && ask <= pos.tp)
            {
               ClosePosition(pos.ticket, pos.tp, current_time, "TP");
               continue;
            }
         }
      }
   }

   void CloseAll(const double bid, const double ask, const datetime current_time)
   {
      for (int i = m_total_positions - 1; i >= 0; i--)
      {
         double p = (m_positions[i].direction == DIRECTION_BUY) ? bid : ask;
         ClosePosition(m_positions[i].ticket, p, current_time, "CLOSE_ALL");
      }
   }

   void CloseWinners(const double bid, const double ask, const datetime current_time)
   {
      for (int i = m_total_positions - 1; i >= 0; i--)
      {
         if (m_positions[i].floating_profit > 0.0)
         {
            double p = (m_positions[i].direction == DIRECTION_BUY) ? bid : ask;
            ClosePosition(m_positions[i].ticket, p, current_time, "CLOSE_WINNERS");
         }
      }
   }

   void CloseLosers(const double bid, const double ask, const datetime current_time)
   {
      for (int i = m_total_positions - 1; i >= 0; i--)
      {
         if (m_positions[i].floating_profit < 0.0)
         {
            double p = (m_positions[i].direction == DIRECTION_BUY) ? bid : ask;
            ClosePosition(m_positions[i].ticket, p, current_time, "CLOSE_LOSERS");
         }
      }
   }

   int FindPositionIndex(const long ticket) const
   {
      for (int i = 0; i < m_total_positions; i++)
      {
         if (m_positions[i].ticket == ticket) return i;
      }
      return -1;
   }

   int  GetCount() const            { return m_total_positions; }
   int  GetClosedCount() const      { return m_total_closed; }
   bool GetPosition(const int index, SimPosition &pos) const
   {
      if (index < 0 || index >= m_total_positions) return false;
      pos = m_positions[index];
      return true;
   }
   bool GetClosedTrade(const int index, SimClosedTrade &trade) const
   {
      if (index < 0 || index >= m_total_closed) return false;
      trade = m_closed_history[index];
      return true;
   }

   double GetTotalFloatingProfit() const
   {
      double sum = 0.0;
      for (int i = 0; i < m_total_positions; i++) sum += m_positions[i].floating_profit;
      return sum;
   }

   double GetTotalUsedMargin() const
   {
      if (m_account_engine == NULL) return 0.0;
      double sum = 0.0;
      for (int i = 0; i < m_total_positions; i++)
      {
         sum += m_account_engine.CalculateRequiredMargin(m_positions[i].lots, m_positions[i].open_price);
      }
      return sum;
   }
};
`;

export const ORDER_EXECUTION_ENGINE_MQH = `//+------------------------------------------------------------------+
//|                                         OrderExecutionEngine.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Core/MarketEngine.mqh"
#include "../Core/AccountEngine.mqh"
#include "../Positions/PositionManager.mqh"

//+------------------------------------------------------------------+
//| Class COrderExecutionEngine: Validation, Margin & Market Orders  |
//+------------------------------------------------------------------+
class COrderExecutionEngine
{
private:
   CMarketData      *m_market_data;
   CMarketEngine    *m_market_engine;
   CAccountEngine   *m_account_engine;
   CPositionManager *m_position_manager;

   double NormalizeLotSize(const double requested_lots) const
   {
      if (requested_lots <= 0.0) return 0.01;
      return MathMax(0.01, MathRound(requested_lots * 100.0) / 100.0);
   }

public:
   COrderExecutionEngine()
   {
      m_market_data = NULL;
      m_market_engine = NULL;
      m_account_engine = NULL;
      m_position_manager = NULL;
   }

   bool Initialize(CMarketData *data, CMarketEngine *market, CAccountEngine *account, CPositionManager *positions)
   {
      if (data == NULL || market == NULL || account == NULL || positions == NULL) return false;
      m_market_data = data;
      m_market_engine = market;
      m_account_engine = account;
      m_position_manager = positions;
      return true;
   }

   long ExecuteMarketBuy(const double lots, const double sl = 0.0, const double tp = 0.0, const string comment = "")
   {
      double norm_lots = NormalizeLotSize(lots);
      double raw_ask = m_market_engine.GetAsk();
      double exec_ask = m_market_engine.ApplySlippage(raw_ask, DIRECTION_BUY, true);

      if (!m_account_engine.HasSufficientMargin(norm_lots, exec_ask))
      {
         Print("[Execution] Margin check FAILED. Insufficient free margin for BUY.");
         return 0;
      }

      datetime cur_t = TimeCurrent();
      return m_position_manager.AddPosition(m_market_data.GetSymbol(), DIRECTION_BUY, norm_lots, exec_ask, cur_t, sl, tp, comment);
   }

   long ExecuteMarketSell(const double lots, const double sl = 0.0, const double tp = 0.0, const string comment = "")
   {
      double norm_lots = NormalizeLotSize(lots);
      double raw_bid = m_market_engine.GetBid();
      double exec_bid = m_market_engine.ApplySlippage(raw_bid, DIRECTION_SELL, true);

      if (!m_account_engine.HasSufficientMargin(norm_lots, exec_bid))
      {
         Print("[Execution] Margin check FAILED. Insufficient free margin for SELL.");
         return 0;
      }

      datetime cur_t = TimeCurrent();
      return m_position_manager.AddPosition(m_market_data.GetSymbol(), DIRECTION_SELL, norm_lots, exec_bid, cur_t, sl, tp, comment);
   }
};
`;

export const ORDER_MANAGER_MQH = `//+------------------------------------------------------------------+
//|                                                 OrderManager.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Positions/PositionManager.mqh"

//+------------------------------------------------------------------+
//| Class COrderManager: Virtual Pending Orders (Limit & Stop)       |
//+------------------------------------------------------------------+
class COrderManager
{
private:
   CMarketData      *m_market_data;
   CPositionManager *m_position_manager;
   SimPendingOrder   m_orders[];
   long              m_next_order_ticket;
   int               m_total_orders;

public:
   COrderManager()
   {
      m_market_data = NULL;
      m_position_manager = NULL;
      m_next_order_ticket = 5001;
      m_total_orders = 0;
      ArrayResize(m_orders, 0);
   }

   bool Initialize(CMarketData *data, CPositionManager *positions)
   {
      if (data == NULL || positions == NULL) return false;
      m_market_data = data;
      m_position_manager = positions;
      return true;
   }

   long PlacePendingOrder(const ENUM_SIM_ORDER_TYPE order_type, const double lots, const double target_price, const double sl = 0.0, const double tp = 0.0, const string comment = "")
   {
      if (m_total_orders >= SIM_MAX_PENDING)
      {
         Print("[COrderManager] Max pending orders reached!");
         return 0;
      }

      int new_size = m_total_orders + 1;
      ArrayResize(m_orders, new_size);

      long ticket = m_next_order_ticket++;
      m_orders[m_total_orders].ticket       = ticket;
      m_orders[m_total_orders].symbol       = m_market_data.GetSymbol();
      m_orders[m_total_orders].order_type   = order_type;
      m_orders[m_total_orders].lots         = lots;
      m_orders[m_total_orders].target_price = target_price;
      m_orders[m_total_orders].sl           = sl;
      m_orders[m_total_orders].tp           = tp;
      m_orders[m_total_orders].placed_time  = TimeCurrent();
      m_orders[m_total_orders].comment      = comment;
      m_orders[m_total_orders].is_active    = true;

      m_total_orders++;
      PrintFormat("[COrderManager] Placed Pending #%d Type: %d @ %.5f", ticket, (int)order_type, target_price);
      return ticket;
   }

   void CancelPendingOrder(const long ticket)
   {
      for (int i = 0; i < m_total_orders; i++)
      {
         if (m_orders[i].ticket == ticket)
         {
            for (int j = i; j < m_total_orders - 1; j++) m_orders[j] = m_orders[j + 1];
            m_total_orders--;
            ArrayResize(m_orders, m_total_orders);
            PrintFormat("[COrderManager] Cancelled Pending #%d", ticket);
            return;
         }
      }
   }

   void UpdatePendingOrders(const double bid, const double ask, const datetime current_time)
   {
      for (int i = m_total_orders - 1; i >= 0; i--)
      {
         SimPendingOrder ord = m_orders[i];
         bool triggered = false;
         ENUM_TRADE_DIRECTION dir = DIRECTION_BUY;
         double exec_price = 0.0;

         switch(ord.order_type)
         {
            case SIM_ORDER_BUY_LIMIT:
               if (ask <= ord.target_price) { triggered = true; dir = DIRECTION_BUY; exec_price = ord.target_price; }
               break;
            case SIM_ORDER_SELL_LIMIT:
               if (bid >= ord.target_price) { triggered = true; dir = DIRECTION_SELL; exec_price = ord.target_price; }
               break;
            case SIM_ORDER_BUY_STOP:
               if (ask >= ord.target_price) { triggered = true; dir = DIRECTION_BUY; exec_price = ord.target_price; }
               break;
            case SIM_ORDER_SELL_STOP:
               if (bid <= ord.target_price) { triggered = true; dir = DIRECTION_SELL; exec_price = ord.target_price; }
               break;
            default:
               break;
         }

         if (triggered)
         {
            m_position_manager.AddPosition(ord.symbol, dir, ord.lots, exec_price, current_time, ord.sl, ord.tp, "TRIGGERED_" + IntegerToString(ord.ticket));
            CancelPendingOrder(ord.ticket);
         }
      }
   }

   int  GetCount() const { return m_total_orders; }
   bool GetOrder(const int index, SimPendingOrder &ord) const
   {
      if (index < 0 || index >= m_total_orders) return false;
      ord = m_orders[index];
      return true;
   }
};
`;

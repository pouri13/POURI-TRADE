import { REPLAY_DATA_FEED_MQH } from './chart';
export const REPLAY_DATA_FEED_MQH_FILE = REPLAY_DATA_FEED_MQH;

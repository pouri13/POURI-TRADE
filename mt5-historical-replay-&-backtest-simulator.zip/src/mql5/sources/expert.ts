export const MODULAR_EA_MQL5 = `//+------------------------------------------------------------------+
//|                                  POURI-ESCOBAR-MARKET-REPLAY.mq5 |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright   "Copyright 2026, Pouri-Escobar"
#property link        "https://github.com/pouri-escobar/market-replay"
#property version     "3.00"
#property description "Professional Soft4FX-Style Historical Trading Simulator & Market Replay Workspace"
#property description "Dedicated Canvas Replay Engine with Zero Look-Ahead Guarantee for MT5 Strategy Tester"
#property strict

//--- Core Simulation Architecture Includes
#include "../Include/PouriReplay/Core/SimulationDefines.mqh"
#include "../Include/PouriReplay/Data/MarketData.mqh"
#include "../Include/PouriReplay/Data/ReplayDataFeed.mqh"
#include "../Include/PouriReplay/Core/ReplayEngine.mqh"
#include "../Include/PouriReplay/Core/MarketEngine.mqh"
#include "../Include/PouriReplay/Core/AccountEngine.mqh"
#include "../Include/PouriReplay/Positions/PositionManager.mqh"
#include "../Include/PouriReplay/Positions/OrderExecutionEngine.mqh"
#include "../Include/PouriReplay/Positions/OrderManager.mqh"
#include "../Include/PouriReplay/Chart/ReplayCandleRenderer.mqh"
#include "../Include/PouriReplay/Chart/TradeRenderer.mqh"
#include "../Include/PouriReplay/Chart/ReplayRenderer.mqh"
#include "../Include/PouriReplay/Chart/ReplayChart.mqh"
#include "../Include/PouriReplay/UI/MainWorkspace.mqh"

//--- Inputs
input group "=== SIMULATION ACCOUNT CONFIGURATION ==="
input double              InpInitialBalance    = 10000.0;           // Virtual Initial Balance ($)
input double              InpLeverage           = 100.0;             // Virtual Leverage (1:X)
input double              InpCommissionLot      = 7.0;               // Commission per Round-Turn Lot ($)

input group "=== SPREAD & SLIPPAGE EXECUTION MODEL ==="
input ENUM_SPREAD_MODEL   InpSpreadModel       = SPREAD_HISTORICAL; // Spread Simulation Model
input double              InpFixedSpreadPts     = 15.0;              // Fixed Spread (if enabled, points)
input ENUM_SLIPPAGE_MODEL InpSlippageModel     = SLIPPAGE_NONE;     // Slippage Simulation Model
input double              InpFixedSlippagePts   = 0.0;               // Fixed Slippage (points)

input group "=== REPLAY ENGINE & DATA SOURCE ==="
input int                 InpStartHistoryBars  = 5000;              // Historical Bars to Cache
input int                 InpInitialBarOffset  = 100;               // Starting Replay Bar Offset
input ENUM_REPLAY_SPEED   InpInitialSpeed      = SPEED_1X;          // Initial Replay Speed
input ENUM_REPLAY_MODE    InpReplayMode        = REPLAY_MODE_CANDLE;// Replay Stepping Mode

//--- System Subsystem Global Instances
CMarketData             ExtMarketData;
CReplayEngine           ExtReplayEngine;
CReplayDataFeed         ExtReplayDataFeed;
CMarketEngine           ExtMarketEngine;
CAccountEngine          ExtAccountEngine;
CPositionManager        ExtPositionManager;
COrderExecutionEngine   ExtExecutionEngine;
COrderManager           ExtOrderManager;
CReplayChart            ExtReplayChart;
CMainWorkspace          ExtMainWorkspace;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("==================================================================");
   Print("  POURI-ESCOBAR-MARKET-REPLAY: Soft4FX-Style Simulator Initializing... ");
   Print("==================================================================");

   // 1. Detect MT5 Strategy Tester Visual Mode
   bool is_tester = (bool)MQLInfoInteger(MQL_TESTER);
   bool is_visual = (bool)MQLInfoInteger(MQL_VISUAL_MODE);
   PrintFormat("[Mode] Strategy Tester: %s | Visual Mode: %s",
               (is_tester ? "YES" : "NO"), (is_visual ? "YES (Dedicated Replay Active)" : "NO"));

   // 2. Load Historical Rates from MT5
   if (!ExtMarketData.LoadHistoryCount(_Symbol, _Period, InpStartHistoryBars))
   {
      Print("[OnInit] CRITICAL ERROR: Could not load historical rates for symbol ", _Symbol);
      return INIT_FAILED;
   }

   // 3. Initialize Replay Clock & Stepping Engine
   if (!ExtReplayEngine.Initialize(&ExtMarketData, InpInitialBarOffset))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Replay Engine.");
      return INIT_FAILED;
   }
   ExtReplayEngine.SetSpeed(InpInitialSpeed);
   ExtReplayEngine.SetMode(InpReplayMode);

   // 4. Initialize Zero Look-Ahead Replay Data Feed
   if (!ExtReplayDataFeed.Initialize(&ExtMarketData, &ExtReplayEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Replay Data Feed.");
      return INIT_FAILED;
   }

   // 5. Initialize Market Quotes & Spread Engine
   if (!ExtMarketEngine.Initialize(&ExtMarketData, &ExtReplayEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Market Engine.");
      return INIT_FAILED;
   }
   ExtMarketEngine.SetSpreadModel(InpSpreadModel, InpFixedSpreadPts);
   ExtMarketEngine.SetSlippageModel(InpSlippageModel, InpFixedSlippagePts);

   // 6. Initialize Virtual Account
   if (!ExtAccountEngine.Initialize(&ExtMarketData, InpInitialBalance, InpLeverage))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Account Engine.");
      return INIT_FAILED;
   }
   ExtAccountEngine.SetCommissionPerLot(InpCommissionLot);

   // 7. Initialize Virtual Hedging Position Manager
   if (!ExtPositionManager.Initialize(&ExtMarketData, &ExtAccountEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Position Manager.");
      return INIT_FAILED;
   }

   // 8. Initialize Virtual Pending Order Manager
   if (!ExtOrderManager.Initialize(&ExtMarketData, &ExtPositionManager))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Order Manager.");
      return INIT_FAILED;
   }

   // 9. Initialize Execution Engine
   if (!ExtExecutionEngine.Initialize(&ExtMarketData, &ExtMarketEngine, &ExtAccountEngine, &ExtPositionManager))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Execution Engine.");
      return INIT_FAILED;
   }

   // 10. Initialize Dedicated Historical Replay Chart with Canvas Engine
   int chart_w = (int)ChartGetInteger(ChartID(), CHART_WIDTH_IN_PIXELS);
   int chart_h = (int)ChartGetInteger(ChartID(), CHART_HEIGHT_IN_PIXELS);
   if (chart_w <= 0) chart_w = 1100;
   if (chart_h <= 0) chart_h = 700;

   // Replay Chart canvas occupies the right viewport
   int replay_x = 510;
   int replay_y = 32;
   int replay_w = MathMax(400, chart_w - replay_x - 10);
   int replay_h = MathMax(300, chart_h - replay_y - 20);

   if (!ExtReplayChart.Initialize(ChartID(), &ExtMarketData, &ExtReplayDataFeed, &ExtReplayEngine, &ExtPositionManager, &ExtOrderManager, replay_x, replay_y, replay_w, replay_h))
   {
      Print("[OnInit] Warning: Could not initialize Replay Chart.");
   }

   // 11. Initialize Soft4FX-Style In-Chart Main Workspace
   if (!ExtMainWorkspace.Initialize(ChartID(), &ExtReplayEngine, &ExtMarketEngine, &ExtAccountEngine,
                                    &ExtPositionManager, &ExtExecutionEngine, &ExtOrderManager, &ExtReplayChart))
   {
      Print("[OnInit] Warning: Could not initialize Main Workspace GUI.");
   }

   // 12. Start High-Precision Millisecond Timer
   EventSetMillisecondTimer(SIM_TIMER_INTERVAL_MS);

   PrintFormat("[OnInit] Simulator Ready. Symbol: %s, %s | Bars: %d | Time: %s",
               _Symbol, EnumToString(_Period), ExtMarketData.GetTotalBars(),
               TimeToString(ExtReplayEngine.GetCurrentTime()));
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   ExtMainWorkspace.Destroy();
   ExtReplayChart.Cleanup();
   PrintFormat("[OnDeinit] Historical simulator session terminated. Code: %d", reason);
}

//+------------------------------------------------------------------+
//| High-Frequency Millisecond Timer Event Handler                   |
//+------------------------------------------------------------------+
void OnTimer()
{
   ulong cur_ms = GetMicrosecondCount() / 1000;

   // 1. Advance replay step if playing
   ExtReplayEngine.OnTimerTick(cur_ms);

   // 2. Update Simulated Bid/Ask & Spread
   ExtMarketEngine.UpdateQuotes();
   double bid      = ExtMarketEngine.GetBid();
   double ask      = ExtMarketEngine.GetAsk();
   double spread   = ExtMarketEngine.GetSpreadPoints();
   datetime r_time = ExtReplayEngine.GetCurrentTime();

   // 3. Evaluate Virtual Pending Orders (Limit & Stop)
   ExtOrderManager.UpdatePendingOrders(bid, ask, r_time);

   // 4. Update Active Positions & SL/TP Triggers
   ExtPositionManager.UpdatePositions(bid, ask, r_time);

   // 5. Update Virtual Account Equity & Margin
   double fl_pnl = ExtPositionManager.GetTotalFloatingProfit();
   double used_m = ExtPositionManager.GetTotalUsedMargin();
   ExtAccountEngine.UpdateEquityAndMargin(fl_pnl, used_m, ExtPositionManager.GetCount(), ExtOrderManager.GetCount(), r_time);

   // 6. Refresh Dedicated Replay Chart (Canvas candles + live active virtual trades)
   ExtReplayChart.Update(bid, ask, spread);

   // 7. Refresh Soft4FX Simulator Workspace Panels
   ExtMainWorkspace.Update();
}

//+------------------------------------------------------------------+
//| Chart Event Handler (Clicks, Hotkeys, Dynamic Resize)            |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if (id == CHARTEVENT_CHART_CHANGE)
   {
      int chart_w = (int)ChartGetInteger(ChartID(), CHART_WIDTH_IN_PIXELS);
      int chart_h = (int)ChartGetInteger(ChartID(), CHART_HEIGHT_IN_PIXELS);
      int replay_x = 510;
      int replay_y = 32;
      int replay_w = MathMax(400, chart_w - replay_x - 10);
      int replay_h = MathMax(300, chart_h - replay_y - 20);
      ExtReplayChart.Resize(replay_w, replay_h);
   }

   if (ExtMainWorkspace.OnChartEvent(id, lparam, dparam, sparam))
   {
      ExtMarketEngine.UpdateQuotes();
      ExtReplayChart.Update(ExtMarketEngine.GetBid(), ExtMarketEngine.GetAsk(), ExtMarketEngine.GetSpreadPoints());
      ExtMainWorkspace.Update();
   }
}

//+------------------------------------------------------------------+
//| Expert tick function (Strategy Tester Tick Synchronization)      |
//+------------------------------------------------------------------+
void OnTick()
{
   ExtMarketEngine.UpdateQuotes();
   OnTimer();
}
`;

export const README_INSTALLATION_TXT = `================================================================================
POURI-ESCOBAR-MARKET-REPLAY: PROFESSIONAL MT5 SIMULATOR SETUP GUIDE
================================================================================

HOW TO RUN IN MT5 STRATEGY TESTER VISUAL MODE (THE RECOMMENDED WORKFLOW)
--------------------------------------------------------------------------------
1. Open MetaTrader 5 on your Windows PC.
2. Open MetaEditor 5 (press F4).
3. In MetaEditor, create or copy "POURI-ESCOBAR-MARKET-REPLAY.mq5" into your
   MQL5/Experts/ directory.
4. Press F7 to Compile (0 errors, 0 warnings).
5. Switch back to MetaTrader 5.
6. Open the Strategy Tester window (Ctrl + R).
7. Configure the Strategy Tester:
   - Type: Expert Advisor
   - Expert: POURI-ESCOBAR-MARKET-REPLAY
   - Symbol: XAUUSD (or EURUSD, GBPUSD, etc.)
   - Period: M5 (or M15, H1, etc.)
   - Date: Select your desired historical backtest date range (e.g. 2025.01.01 to 2025.06.01)
   - Execution: Every tick OR 1 minute OHLC
   - Deposit: 10000 USD, Leverage 1:100
   - CHECK THE BOX: [x] Visual mode with display of charts, indicators and trades
8. Click "Start".

WHAT HAPPENS WHEN LAUNCHED:
--------------------------------------------------------------------------------
- MT5 opens a dedicated Historical Visual Chart.
- The EA detects Visual Mode and transforms the chart into a Soft4FX-style workspace:
  * Top Replay Header Banner with Symbol, Period, and Mode status.
  * Replay Control Bar: [RESET], [|< STEP], [> PLAY / || PAUSE], [STEP >|], [FAST >>],
    plus 9 calibrated Speed buttons: [0.1x] [0.5x] [1x] [2x] [5x] [10x] [25x] [50x] [100x].
  * Manual Trading Panel: One-click BUY MARKET and SELL MARKET, Volume (+ / - / presets),
    configurable SL/TP in pips, Pending Orders (BUY/SELL LIMIT & STOP), and Quick Close
    buttons (CLOSE ALL, CLOSE WINNERS, CLOSE LOSERS, BREAKEVEN).
  * Permanent Account Telemetry Panel: Live Balance, Equity, Floating P/L, Realized P/L,
    Margin, Free Margin, Margin Level %, Drawdown %, and Daily P/L.
  * Active Positions Table: Real-time list of virtual positions with Ticket, Direction,
    Lots, Entry, Current, P/L ($), Pips, and one-click action buttons:
    [X] Close position, [½] Partial close 50%, [BE] Move Stop Loss to breakeven!
  * Dedicated Canvas Replay Chart: High-performance CCanvas renderer displaying historical
    candlesticks up to the current replay timestamp with dynamic zoom, scroll, bid/ask badges,
    and overlaid trade levels!

ZERO LOOK-AHEAD GUARANTEE:
--------------------------------------------------------------------------------
All market progression is strictly sequential. CReplayDataFeed quarantines future candles
so that candles beyond the current replay index are NEVER drawn or accessible.
Trades execute purely against the virtual simulator account. No real broker orders
are ever sent.
`;

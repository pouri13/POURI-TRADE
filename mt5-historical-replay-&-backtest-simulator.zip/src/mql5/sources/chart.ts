export const REPLAY_DATA_FEED_MQH = `//+------------------------------------------------------------------+
//|                                           ReplayDataFeed.mqh     |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Core/ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CReplayDataFeed: High-Performance Data Feed with           |
//| Absolute Zero Look-Ahead Quarantine.                             |
//| Safely feeds only historical bars [0 .. current_replay_index].   |
//| Can generate Custom Symbol synthetic bars if requested, or feed |
//| the dedicated Canvas Replay Renderer.                           |
//+------------------------------------------------------------------+
class CReplayDataFeed
{
private:
   CMarketData      *m_market_data;
   CReplayEngine    *m_replay_engine;
   string            m_custom_symbol_name;
   bool              m_custom_symbol_created;

public:
   CReplayDataFeed()
   {
      m_market_data = NULL;
      m_replay_engine = NULL;
      m_custom_symbol_name = "POURI_XAUUSD_REPLAY";
      m_custom_symbol_created = false;
   }

   bool Initialize(CMarketData *data, CReplayEngine *replay, const string custom_sym = "POURI_XAUUSD_REPLAY")
   {
      if (data == NULL || replay == NULL) return false;
      m_market_data = data;
      m_replay_engine = replay;
      m_custom_symbol_name = custom_sym;
      return true;
   }

   //--- Safe slice: Returns only available history up to cursor (Zero Look-Ahead)
   int GetAvailableBarsCount() const
   {
      if (m_replay_engine == NULL) return 0;
      return m_replay_engine.GetCurrentIndex() + 1;
   }

   //--- Retrieve single bar only if <= current_replay_index
   bool GetSafeBar(const int bar_index, MqlRates &out_rate) const
   {
      if (m_replay_engine == NULL || m_market_data == NULL) return false;
      int max_allowed = m_replay_engine.GetCurrentIndex();
      if (bar_index < 0 || bar_index > max_allowed)
      {
         // Strictly refuse any future candle access
         return false;
      }
      return m_market_data.GetBar(bar_index, out_rate);
   }

   //--- Retrieve current active replay candle
   bool GetCurrentBar(MqlRates &out_rate) const
   {
      if (m_replay_engine == NULL) return false;
      return GetSafeBar(m_replay_engine.GetCurrentIndex(), out_rate);
   }

   //--- Retrieve a window of visible candles [start_index .. end_index]
   //--- All indices are clamped to m_replay_engine.GetCurrentIndex()
   int GetSafeBarRange(const int start_index, const int count, MqlRates &out_rates[]) const
   {
      if (m_replay_engine == NULL || m_market_data == NULL) return 0;
      int cur_cursor = m_replay_engine.GetCurrentIndex();
      if (cur_cursor < 0) return 0;

      int actual_start = MathMax(0, start_index);
      int max_available = cur_cursor - actual_start + 1;
      if (max_available <= 0) return 0;

      int actual_count = MathMin(count, max_available);
      ArrayResize(out_rates, actual_count);

      int copied = 0;
      for (int i = 0; i < actual_count; i++)
      {
         MqlRates r;
         if (m_market_data.GetBar(actual_start + i, r))
         {
            out_rates[i] = r;
            copied++;
         }
      }
      return copied;
   }

   //--- Custom Symbol Manager (For MT5 platforms supporting CustomSymbolCreate)
   bool SetupCustomSymbol()
   {
      ResetLastError();
      if (!SymbolInfoInteger(m_custom_symbol_name, SYMBOL_CUSTOM))
      {
         if (!CustomSymbolCreate(m_custom_symbol_name, "POURI_REPLAY", _Symbol))
         {
            PrintFormat("[CReplayDataFeed] CustomSymbolCreate %s info: %d", m_custom_symbol_name, GetLastError());
            return false;
         }
         CustomSymbolSetInteger(m_custom_symbol_name, SYMBOL_DIGITS, m_market_data.GetDigits());
         CustomSymbolSetDouble(m_custom_symbol_name, SYMBOL_POINT, m_market_data.GetPoint());
         CustomSymbolSetDouble(m_custom_symbol_name, SYMBOL_TRADE_TICK_SIZE, m_market_data.GetTickSize());
         CustomSymbolSetDouble(m_custom_symbol_name, SYMBOL_TRADE_TICK_VALUE, m_market_data.GetTickValue());
         CustomSymbolSetDouble(m_custom_symbol_name, SYMBOL_TRADE_CONTRACT_SIZE, m_market_data.GetContractSize());
         SymbolSelect(m_custom_symbol_name, true);
         m_custom_symbol_created = true;
      }
      return true;
   }

   //--- Push current bar to Custom Symbol if active
   bool FeedCustomSymbolBar()
   {
      if (!m_custom_symbol_created) return false;
      MqlRates cur_rate;
      if (!GetCurrentBar(cur_rate)) return false;

      MqlRates rates_arr[1];
      rates_arr[0] = cur_rate;
      int res = CustomRatesReplace(m_custom_symbol_name, cur_rate.time, cur_rate.time, rates_arr, 1);
      return (res > 0);
   }

   string GetCustomSymbolName() const { return m_custom_symbol_name; }
};
`;

export const REPLAY_CANDLE_RENDERER_MQH = `//+------------------------------------------------------------------+
//|                                        ReplayCandleRenderer.mqh  |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include <Canvas/Canvas.mqh>
#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Core/ReplayEngine.mqh"
#include "../Data/ReplayDataFeed.mqh"

//+------------------------------------------------------------------+
//| Class CReplayCandleRenderer: High-Performance CCanvas Engine     |
//| Renders ONLY historical candles [0 .. current_replay_index].     |
//| Guaranteed: Future bars [current_replay_index + 1 .. N] are      |
//| NEVER rendered or visible.                                       |
//| Provides zoom (candle width), scroll offset, grid, price axis,   |
//| and time axis.                                                   |
//+------------------------------------------------------------------+
class CReplayCandleRenderer
{
private:
   CCanvas          m_canvas;
   long             m_chart_id;
   CReplayDataFeed *m_feed;
   string           m_canvas_name;
   int              m_x, m_y, m_w, m_h;

   // Viewport configuration
   int              m_candle_width;  // Pixel width of each candle body (3..24)
   int              m_candle_gap;    // Pixel spacing between candles (1..4)
   int              m_scroll_offset; // Bars scrolled back from latest bar (0 = locked to live cursor)
   
   // Computed scale
   double           m_min_price;
   double           m_max_price;
   int              m_right_margin_px; // Reserved space for price scale
   int              m_bottom_margin_px;// Reserved space for time scale

   // Colors
   uint             m_clr_bg;
   uint             m_clr_grid;
   uint             m_clr_bull_body;
   uint             m_clr_bull_border;
   uint             m_clr_bear_body;
   uint             m_clr_bear_border;
   uint             m_clr_text;
   uint             m_clr_cursor_line;

   // Coordinate transforms
   int PriceToY(const double price) const
   {
      if (m_max_price <= m_min_price) return m_y + (m_h / 2);
      int chart_h = m_h - m_bottom_margin_px - 20;
      double ratio = (m_max_price - price) / (m_max_price - m_min_price);
      int y = m_y + 10 + (int)(ratio * chart_h);
      return MathMin(m_y + m_h - m_bottom_margin_px, MathMax(m_y + 5, y));
   }

   double YToPrice(const int y) const
   {
      int chart_h = m_h - m_bottom_margin_px - 20;
      if (chart_h <= 0) return m_min_price;
      double ratio = (double)(y - (m_y + 10)) / (double)chart_h;
      return m_max_price - ratio * (m_max_price - m_min_price);
   }

public:
   CReplayCandleRenderer()
   {
      m_chart_id = 0;
      m_feed = NULL;
      m_canvas_name = "PE_REPLAY_CANVAS";
      m_x = 0; m_y = 30; m_w = 800; m_h = 500;
      m_candle_width = 8;
      m_candle_gap = 2;
      m_scroll_offset = 0;
      m_min_price = 0.0;
      m_max_price = 1.0;
      m_right_margin_px = 65;
      m_bottom_margin_px = 22;

      // Deep Obsidian Theme
      m_clr_bg          = 0xFF0B0E14; // ARGB Dark Slate Background
      m_clr_grid        = 0xFF181F2C; // ARGB Grid lines
      m_clr_bull_body   = 0xFF059669; // Emerald Bull Body
      m_clr_bull_border = 0xFF10B981; // Vibrant Bull Wick
      m_clr_bear_body   = 0xFFDC2626; // Crimson Bear Body
      m_clr_bear_border = 0xFFEF4444; // Vibrant Bear Wick
      m_clr_text        = 0xFF94A3B8; // Slate muted labels
      m_clr_cursor_line = 0xFF38BDF8; // Cyan cursor
   }

   bool Initialize(const long chart_id, CReplayDataFeed *feed, const int x, const int y, const int w, const int h)
   {
      m_chart_id = chart_id;
      m_feed = feed;
      m_x = x; m_y = y; m_w = w; m_h = h;

      if (m_canvas.CreateBitmapLabel(m_chart_id, 0, m_canvas_name, m_x, m_y, m_w, m_h, COLOR_FORMAT_ARGB_NORMALIZE))
      {
         m_canvas.Erase(m_clr_bg);
         m_canvas.Update();
         return true;
      }
      return false;
   }

   void Resize(const int w, const int h)
   {
      if (w <= 100 || h <= 100) return;
      m_w = w;
      m_h = h;
      m_canvas.Resize(m_w, m_h);
   }

   //--- Zoom and Scroll Controls
   void ZoomIn()  { m_candle_width = MathMin(24, m_candle_width + 2); }
   void ZoomOut() { m_candle_width = MathMax(3, m_candle_width - 2); }
   void ScrollLeft(const int bars = 5) { m_scroll_offset += bars; }
   void ScrollRight(const int bars = 5) { m_scroll_offset = MathMax(0, m_scroll_offset - bars); }
   void ResetScroll() { m_scroll_offset = 0; }

   //--- Main Drawing Method: Strictly renders only up to current replay index
   void Render()
   {
      if (m_feed == NULL || m_w <= 0 || m_h <= 0) return;

      int total_available = m_feed->GetAvailableBarsCount();
      if (total_available <= 0) return;

      int cur_cursor = total_available - 1; // latest allowable historical index
      int end_bar = cur_cursor - m_scroll_offset;
      end_bar = MathMin(cur_cursor, MathMax(0, end_bar));

      // Calculate how many candles fit in the chart area
      int plot_w = m_w - m_right_margin_px;
      int candle_pitch = m_candle_width + m_candle_gap;
      int max_visible_bars = plot_w / candle_pitch;
      if (max_visible_bars <= 0) max_visible_bars = 10;

      int start_bar = MathMax(0, end_bar - max_visible_bars + 1);
      int actual_bars = end_bar - start_bar + 1;

      // 1. Fetch safe bars strictly within [start_bar .. end_bar]
      MqlRates visible_rates[];
      int fetched = m_feed->GetSafeBarRange(start_bar, actual_bars, visible_rates);
      if (fetched <= 0) return;

      // 2. Compute min/max price for the visible window
      m_min_price = visible_rates[0].low;
      m_max_price = visible_rates[0].high;
      for (int i = 1; i < fetched; i++)
      {
         if (visible_rates[i].low < m_min_price)  m_min_price = visible_rates[i].low;
         if (visible_rates[i].high > m_max_price) m_max_price = visible_rates[i].high;
      }
      // Add slight vertical headroom (5%)
      double padding = (m_max_price - m_min_price) * 0.05;
      if (padding <= 0.0) padding = 1.0;
      m_min_price -= padding;
      m_max_price += padding;

      // 3. Clear Canvas Background
      m_canvas.Erase(m_clr_bg);

      // 4. Render Horizontal Price Grid lines
      int grid_divisions = 6;
      for (int g = 0; g <= grid_divisions; g++)
      {
         double p = m_min_price + (m_max_price - m_min_price) * (double)g / (double)grid_divisions;
         int gy = PriceToY(p);
         m_canvas.Line(0, gy, plot_w, gy, m_clr_grid);

         // Price Axis Label on the right
         string p_str = DoubleToString(p, 2);
         m_canvas.TextOut(plot_w + 6, gy - 6, p_str, m_clr_text, TA_LEFT);
      }

      // Vertical separator between plot area and price axis
      m_canvas.Line(plot_w, 0, plot_w, m_h, m_clr_grid);

      // Horizontal separator between plot area and time axis
      int time_y = m_h - m_bottom_margin_px;
      m_canvas.Line(0, time_y, m_w, time_y, m_clr_grid);

      // 5. Render Candlesticks from Left to Right
      for (int i = 0; i < fetched; i++)
      {
         MqlRates r = visible_rates[i];
         int candle_x = plot_w - (fetched - i) * candle_pitch;
         if (candle_x < 0 || candle_x >= plot_w) continue;

         int y_open  = PriceToY(r.open);
         int y_close = PriceToY(r.close);
         int y_high  = PriceToY(r.high);
         int y_low   = PriceToY(r.low);

         bool is_bull = (r.close >= r.open);
         uint clr_body = is_bull ? m_clr_bull_body : m_clr_bear_body;
         uint clr_wick = is_bull ? m_clr_bull_border : m_clr_bear_border;

         // Wick (High to Low vertical line)
         int mid_x = candle_x + (m_candle_width / 2);
         m_canvas.Line(mid_x, y_high, mid_x, y_low, clr_wick);

         // Body
         int top_y = MathMin(y_open, y_close);
         int bot_y = MathMax(y_open, y_close);
         int body_h = MathMax(1, bot_y - top_y);

         m_canvas.FillRectangle(candle_x, top_y, candle_x + m_candle_width, top_y + body_h, clr_body);
         m_canvas.Rectangle(candle_x, top_y, candle_x + m_candle_width, top_y + body_h, clr_wick);

         // Periodic time label on bottom axis (every ~10 candles)
         if (i % 10 == 0)
         {
            m_canvas.Line(mid_x, time_y, mid_x, time_y + 4, m_clr_grid);
            string t_str = TimeToString(r.time, TIME_MINUTES);
            m_canvas.TextOut(mid_x - 14, time_y + 5, t_str, m_clr_text, TA_LEFT);
         }
      }

      // 6. Highlight Current Replay Candle (Rightmost available candle)
      if (fetched > 0)
      {
         MqlRates cur_bar = visible_rates[fetched - 1];
         int cur_x = plot_w - candle_pitch + (m_candle_width / 2);
         int cur_close_y = PriceToY(cur_bar.close);

         // Horizontal line through current replay price
         m_canvas.Line(cur_x, cur_close_y, plot_w, cur_close_y, m_clr_cursor_line);

         // Current Price Badge on Right Margin
         m_canvas.FillRectangle(plot_w + 1, cur_close_y - 8, m_w - 2, cur_close_y + 8, 0xFF0284C7);
         m_canvas.TextOut(plot_w + 5, cur_close_y - 6, DoubleToString(cur_bar.close, 2), 0xFFFFFFFF, TA_LEFT);
      }

      m_canvas.Update();
   }

   //--- Coordinate helpers for overlays (TradeRenderer)
   int GetPlotWidth() const { return m_w - m_right_margin_px; }
   int GetCandlePitch() const { return m_candle_width + m_candle_gap; }
   int GetXForBar(const int bar_index) const
   {
      int cur_cursor = m_feed ? m_feed->GetAvailableBarsCount() - 1 : 0;
      int end_bar = cur_cursor - m_scroll_offset;
      int plot_w = GetPlotWidth();
      int candle_pitch = GetCandlePitch();
      return plot_w - (end_bar - bar_index + 1) * candle_pitch + (m_candle_width / 2);
   }

   int GetYForPrice(const double price) const { return PriceToY(price); }
   CCanvas* GetCanvas() { return &m_canvas; }

   void Destroy()
   {
      m_canvas.Destroy();
   }
};
`;

export const TRADE_RENDERER_MQH = `//+------------------------------------------------------------------+
//|                                            TradeRenderer.mqh     |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include <Canvas/Canvas.mqh>
#include "../Core/SimulationDefines.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Positions/OrderManager.mqh"
#include "ReplayCandleRenderer.mqh"

//+------------------------------------------------------------------+
//| Class CTradeRenderer: Renders Virtual Trade Elements on CCanvas  |
//| - Buy / Sell Entry Arrows & Markers                              |
//| - Entry Lines, Stop Loss & Take Profit with P/L Badges           |
//| - Pending Order Lines (Limits & Stops)                           |
//| - Closed Trade Connectors (Green for Profit, Red for Loss)       |
//+------------------------------------------------------------------+
class CTradeRenderer
{
private:
   CPositionManager      *m_position_manager;
   COrderManager         *m_order_manager;
   CReplayCandleRenderer *m_candle_renderer;

   uint m_clr_buy_marker;
   uint m_clr_sell_marker;
   uint m_clr_sl_line;
   uint m_clr_tp_line;
   uint m_clr_pending_line;

public:
   CTradeRenderer()
   {
      m_position_manager = NULL;
      m_order_manager = NULL;
      m_candle_renderer = NULL;

      m_clr_buy_marker   = 0xFF10B981; // Green
      m_clr_sell_marker  = 0xFFEF4444; // Red
      m_clr_sl_line      = 0xFFF43F5E; // Dotted Red
      m_clr_tp_line      = 0xFF10B981; // Dotted Green
      m_clr_pending_line = 0xFFF59E0B; // Amber
   }

   bool Initialize(CPositionManager *positions, COrderManager *orders, CReplayCandleRenderer *candle_renderer)
   {
      m_position_manager = positions;
      m_order_manager = orders;
      m_candle_renderer = candle_renderer;
      return true;
   }

   void RenderTrades()
   {
      if (m_candle_renderer == NULL || m_position_manager == NULL) return;
      CCanvas *canvas = m_candle_renderer->GetCanvas();
      if (canvas == NULL) return;

      int plot_w = m_candle_renderer->GetPlotWidth();

      // 1. Render Active Virtual Positions (Entry lines, SL, TP)
      int total_pos = m_position_manager->GetCount();
      for (int i = 0; i < total_pos; i++)
      {
         SimPosition pos;
         if (!m_position_manager->GetPosition(i, pos)) continue;

         int entry_y = m_candle_renderer->GetYForPrice(pos.open_price);
         uint dir_color = (pos.direction == DIRECTION_BUY) ? 0xFF0284C7 : 0xFFEA580C;

         // Horizontal entry line
         canvas->Line(0, entry_y, plot_w, entry_y, dir_color);
         string pos_tag = StringFormat("#%d %s %.2f @ %.2f (P/L: %s$%.2f)",
                                       pos.ticket, (pos.direction == DIRECTION_BUY ? "BUY" : "SELL"),
                                       pos.lots, pos.open_price,
                                       (pos.floating_profit >= 0 ? "+" : ""), pos.floating_profit);
         canvas->TextOut(8, entry_y - 12, pos_tag, dir_color, TA_LEFT);

         // Stop Loss Line
         if (pos.sl > 0.0)
         {
            int sl_y = m_candle_renderer->GetYForPrice(pos.sl);
            canvas->Line(0, sl_y, plot_w, sl_y, m_clr_sl_line);
            canvas->TextOut(8, sl_y - 12, StringFormat("#%d SL @ %.2f", pos.ticket, pos.sl), m_clr_sl_line, TA_LEFT);
         }

         // Take Profit Line
         if (pos.tp > 0.0)
         {
            int tp_y = m_candle_renderer->GetYForPrice(pos.tp);
            canvas->Line(0, tp_y, plot_w, tp_y, m_clr_tp_line);
            canvas->TextOut(8, tp_y - 12, StringFormat("#%d TP @ %.2f", pos.ticket, pos.tp), m_clr_tp_line, TA_LEFT);
         }
      }

      // 2. Render Virtual Pending Orders
      if (m_order_manager != NULL)
      {
         int total_ord = m_order_manager->GetCount();
         for (int i = 0; i < total_ord; i++)
         {
            SimPendingOrder ord;
            if (!m_order_manager.GetOrder(i, ord)) continue;

            int ord_y = m_candle_renderer->GetYForPrice(ord.target_price);
            canvas->Line(0, ord_y, plot_w, ord_y, m_clr_pending_line);
            string type_name = "PENDING";
            switch(ord.order_type)
            {
               case SIM_ORDER_BUY_LIMIT:  type_name = "BUY LIMIT"; break;
               case SIM_ORDER_SELL_LIMIT: type_name = "SELL LIMIT"; break;
               case SIM_ORDER_BUY_STOP:   type_name = "BUY STOP"; break;
               case SIM_ORDER_SELL_STOP:  type_name = "SELL STOP"; break;
               default: break;
            }
            string ord_tag = StringFormat("#%d %s %.2f @ %.2f", ord.ticket, type_name, ord.lots, ord.target_price);
            canvas->TextOut(plot_w - 180, ord_y - 12, ord_tag, m_clr_pending_line, TA_LEFT);
         }
      }

      canvas->Update();
   }
};
`;

export const REPLAY_RENDERER_MQH = `//+------------------------------------------------------------------+
//|                                           ReplayRenderer.mqh     |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Data/ReplayDataFeed.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Positions/OrderManager.mqh"
#include "ReplayCandleRenderer.mqh"
#include "TradeRenderer.mqh"

//+------------------------------------------------------------------+
//| Class CReplayRenderer: Master Replay Visual Engine               |
//| Orchestrates CReplayCandleRenderer and CTradeRenderer            |
//| Enforces ZERO LOOK-AHEAD: Never renders beyond current index.    |
//| Provides Bid/Ask badges, Zoom, Pan/Scroll, and Redraws.          |
//+------------------------------------------------------------------+
class CReplayRenderer
{
private:
   long                  m_chart_id;
   CReplayDataFeed      *m_feed;
   CPositionManager     *m_position_manager;
   COrderManager        *m_order_manager;

   CReplayCandleRenderer m_candle_renderer;
   CTradeRenderer        m_trade_renderer;

   int                   m_x, m_y, m_w, m_h;
   bool                  m_initialized;

public:
   CReplayRenderer()
   {
      m_chart_id = 0;
      m_feed = NULL;
      m_position_manager = NULL;
      m_order_manager = NULL;
      m_x = 0; m_y = 32; m_w = 900; m_h = 460;
      m_initialized = false;
   }

   bool Initialize(const long chart_id, CReplayDataFeed *feed, CPositionManager *positions, COrderManager *orders, const int x, const int y, const int w, const int h)
   {
      m_chart_id = chart_id;
      m_feed = feed;
      m_position_manager = positions;
      m_order_manager = orders;
      m_x = x; m_y = y; m_w = w; m_h = h;

      if (!m_candle_renderer.Initialize(m_chart_id, m_feed, m_x, m_y, m_w, m_h))
         return false;

      if (!m_trade_renderer.Initialize(m_position_manager, m_order_manager, &m_candle_renderer))
         return false;

      m_initialized = true;
      Render();
      return true;
   }

   void Resize(const int w, const int h)
   {
      m_w = w;
      m_h = h;
      m_candle_renderer.Resize(m_w, m_h);
      Render();
   }

   //--- Navigation Controls
   void ZoomIn()          { m_candle_renderer.ZoomIn(); Render(); }
   void ZoomOut()         { m_candle_renderer.ZoomOut(); Render(); }
   void ScrollLeft(int n) { m_candle_renderer.ScrollLeft(n); Render(); }
   void ScrollRight(int n){ m_candle_renderer.ScrollRight(n); Render(); }
   void ResetScroll()     { m_candle_renderer.ResetScroll(); Render(); }

   //--- Master Render: Candle Canvas + Trades Overlaid
   void Render()
   {
      if (!m_initialized) return;
      // Step 1: Render historical candles up to current index (Strict No Look-Ahead)
      m_candle_renderer.Render();
      // Step 2: Overlay active virtual positions & orders
      m_trade_renderer.RenderTrades();
   }

   void Destroy()
   {
      m_candle_renderer.Destroy();
      m_initialized = false;
   }
};
`;

export const REPLAY_CHART_MQH = `//+------------------------------------------------------------------+
//|                                                  ReplayChart.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Data/MarketData.mqh"
#include "../Data/ReplayDataFeed.mqh"
#include "../Core/ReplayEngine.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Positions/OrderManager.mqh"
#include "ReplayRenderer.mqh"

//+------------------------------------------------------------------+
//| Class CReplayChart: Dedicated Historical Chart Visualizer        |
//| Responsibilities:                                                |
//| - Initialize replay chart & configure workspace dimensions       |
//| - Maintain visible replay range with ZERO LOOK-AHEAD             |
//| - Render candles via CReplayRenderer (CCanvas)                   |
//| - Render trade markers, SL/TP lines, and pending orders          |
//| - Support zoom, pan/scroll, and current replay timestamp         |
//+------------------------------------------------------------------+
class CReplayChart
{
private:
   long              m_chart_id;
   CMarketData      *m_market_data;
   CReplayDataFeed  *m_data_feed;
   CReplayEngine    *m_replay_engine;
   CPositionManager *m_position_manager;
   COrderManager    *m_order_manager;
   CReplayRenderer   m_replay_renderer;

   string            m_prefix;
   bool              m_is_tester_visual;
   int               m_x, m_y, m_w, m_h;

public:
   CReplayChart()
   {
      m_chart_id = 0;
      m_market_data = NULL;
      m_data_feed = NULL;
      m_replay_engine = NULL;
      m_position_manager = NULL;
      m_order_manager = NULL;
      m_prefix = "PE_CHT_";
      m_is_tester_visual = false;
      m_x = 0; m_y = 32; m_w = 900; m_h = 460;
   }

   bool Initialize(const long chart_id, CMarketData *data, CReplayDataFeed *feed, CReplayEngine *replay, CPositionManager *positions, COrderManager *orders, const int x = 0, const int y = 32, const int w = 900, const int h = 460)
   {
      m_chart_id = chart_id;
      m_market_data = data;
      m_data_feed = feed;
      m_replay_engine = replay;
      m_position_manager = positions;
      m_order_manager = orders;
      m_x = x; m_y = y; m_w = w; m_h = h;

      m_is_tester_visual = (bool)MQLInfoInteger(MQL_TESTER) && (bool)MQLInfoInteger(MQL_VISUAL_MODE);

      ConfigureChartWorkspace();

      // Initialize dedicated Canvas Replay Renderer
      if (m_data_feed != NULL)
      {
         m_replay_renderer.Initialize(m_chart_id, m_data_feed, m_position_manager, m_order_manager, m_x, m_y, m_w, m_h);
      }

      return true;
   }

   //--- Configure the Dedicated Simulator Workspace Presentation
   void ConfigureChartWorkspace()
   {
      // Blank out native chart to avoid lookahead interference
      ChartSetInteger(m_chart_id, CHART_AUTOSCROLL, false);
      ChartSetInteger(m_chart_id, CHART_SHIFT, false);
      ChartSetInteger(m_chart_id, CHART_MODE, CHART_CANDLES);

      // Deep Obsidian Dark Theme
      ChartSetInteger(m_chart_id, CHART_COLOR_BACKGROUND, (color)0x0B0E14);
      ChartSetInteger(m_chart_id, CHART_COLOR_FOREGROUND, (color)0x94A3B8);
      ChartSetInteger(m_chart_id, CHART_COLOR_GRID, (color)0x161B26);
      ChartSetInteger(m_chart_id, CHART_COLOR_VOLUME, (color)0x334155);
      ChartSetInteger(m_chart_id, CHART_SHOW_GRID, false);
      ChartSetInteger(m_chart_id, CHART_SHOW_PERIOD_SEP, false);

      ChartRedraw(m_chart_id);
   }

   //--- Zoom and Scroll Controls
   void ZoomIn()          { m_replay_renderer.ZoomIn(); }
   void ZoomOut()         { m_replay_renderer.ZoomOut(); }
   void ScrollLeft(int n) { m_replay_renderer.ScrollLeft(n); }
   void ScrollRight(int n){ m_replay_renderer.ScrollRight(n); }
   void ResetScroll()     { m_replay_renderer.ResetScroll(); }

   void Resize(const int w, const int h)
   {
      m_w = w;
      m_h = h;
      m_replay_renderer.Resize(m_w, m_h);
   }

   //--- Master Update Called on Every Replay Tick
   void Update(const double bid, const double ask, const double spread_pts)
   {
      // Render candles and active trades via Canvas engine
      m_replay_renderer.Render();
      ChartRedraw(m_chart_id);
   }

   void Cleanup()
   {
      m_replay_renderer.Destroy();
      ObjectsDeleteAll(m_chart_id, m_prefix);
      ChartSetInteger(m_chart_id, CHART_AUTOSCROLL, true);
      ChartRedraw(m_chart_id);
   }
};
`;

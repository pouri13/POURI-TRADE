export const REPLAY_CONTROL_PANEL_MQH = `//+------------------------------------------------------------------+
//|                                           ReplayControlPanel.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Core/ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CReplayControlPanel: Soft4FX-Style Fixed Replay Controller |
//+------------------------------------------------------------------+
class CReplayControlPanel
{
private:
   long           m_chart_id;
   CReplayEngine *m_replay_engine;
   string         m_prefix;
   int            m_x, m_y, m_w, m_h;

   void CreateBtn(const string id, const int x, const int y, const int w, const int h, const string txt, const color bg, const color fg, const int fsize = 8)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XSIZE, w);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YSIZE, h);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_BGCOLOR, bg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

   void CreateLbl(const string id, const int x, const int y, const string txt, const color fg, const int fsize = 8)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

public:
   CReplayControlPanel()
   {
      m_chart_id = 0;
      m_replay_engine = NULL;
      m_prefix = "PE_RCP_";
      m_x = 10; m_y = 35; m_w = 480; m_h = 75;
   }

   bool Initialize(const long chart_id, CReplayEngine *replay, const int x = 10, const int y = 35)
   {
      m_chart_id = chart_id;
      m_replay_engine = replay;
      m_x = x; m_y = y;
      Render();
      return true;
   }

   void Render()
   {
      Destroy();

      // Card Background
      string bg_name = m_prefix + "BG";
      ObjectCreate(m_chart_id, bg_name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XDISTANCE, m_x);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YDISTANCE, m_y);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XSIZE, m_w);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YSIZE, m_h);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BGCOLOR, (color)0x121722);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_COLOR, (color)0x2D3748);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_TYPE, BORDER_FLAT);

      // Section Title & Status
      CreateLbl("TITLE", m_x + 8, m_y + 6, "REPLAY CONTROL BAR", (color)0x10B981, 9);
      CreateLbl("READOUT", m_x + 180, m_y + 6, "2025.06.17 14:35:00 | SPEED 1X | CANDLE", (color)0x38BDF8, 9);

      // Buttons Row 1: Transport Controls
      int by = m_y + 24;
      CreateBtn("RESET",  m_x + 8,   by, 50, 22, "RESET", (color)0x334155, (color)0xF1F5F9);
      CreateBtn("PREV",   m_x + 62,  by, 48, 22, "|< STEP", (color)0x1E293B, (color)0xF1F5F9);
      CreateBtn("PLAY",   m_x + 114, by, 62, 22, "> PLAY", (color)0x059669, (color)0xFFFFFF);
      CreateBtn("NEXT",   m_x + 180, by, 48, 22, "STEP >|", (color)0x1E293B, (color)0xF1F5F9);
      CreateBtn("FAST",   m_x + 232, by, 50, 22, "FAST >>", (color)0x1E293B, (color)0xF1F5F9);

      // Speed Selectors Row
      int sy = m_y + 49;
      CreateLbl("SPEED_LBL", m_x + 8, sy + 3, "SPEED:", (color)0x94A3B8, 8);
      int sx = m_x + 55;
      CreateBtn("SPD_01", sx,       sy, 36, 19, "0.1x", (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("SPD_05", sx + 40,  sy, 36, 19, "0.5x", (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("SPD_1",  sx + 80,  sy, 36, 19, "1x",   (color)0x334155, (color)0x38BDF8, 7);
      CreateBtn("SPD_2",  sx + 120, sy, 36, 19, "2x",   (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("SPD_5",  sx + 160, sy, 36, 19, "5x",   (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("SPD_10", sx + 200, sy, 36, 19, "10x",  (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("SPD_25", sx + 240, sy, 36, 19, "25x",  (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("SPD_50", sx + 280, sy, 36, 19, "50x",  (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("SPD_100",sx + 320, sy, 42, 19, "100x", (color)0x1E293B, (color)0x94A3B8, 7);

      ChartRedraw(m_chart_id);
   }

   void Update()
   {
      if (m_replay_engine == NULL) return;

      datetime cur_t = m_replay_engine.GetCurrentTime();
      string state_str = (m_replay_engine.GetState() == REPLAY_STATE_RUNNING) ? "RUNNING" : "PAUSED";
      string readout = StringFormat("%s | SPEED %s | %s",
                                    TimeToString(cur_t, TIME_DATE|TIME_SECONDS),
                                    m_replay_engine.GetSpeedString(),
                                    state_str);
      ObjectSetString(m_chart_id, m_prefix + "READOUT", OBJPROP_TEXT, readout);

      string play_btn = m_prefix + "PLAY";
      if (m_replay_engine.GetState() == REPLAY_STATE_RUNNING)
      {
         ObjectSetString(m_chart_id, play_btn, OBJPROP_TEXT, "|| PAUSE");
         ObjectSetInteger(m_chart_id, play_btn, OBJPROP_BGCOLOR, (color)0xD97706);
      }
      else
      {
         ObjectSetString(m_chart_id, play_btn, OBJPROP_TEXT, "> PLAY");
         ObjectSetInteger(m_chart_id, play_btn, OBJPROP_BGCOLOR, (color)0x059669);
      }
   }

   bool OnClick(const string name)
   {
      if (StringFind(name, m_prefix) != 0) return false;

      if (name == m_prefix + "PLAY")   { m_replay_engine.TogglePlayPause(); Update(); return true; }
      if (name == m_prefix + "NEXT")   { m_replay_engine.StepNext(); Update(); return true; }
      if (name == m_prefix + "PREV")   { m_replay_engine.StepPrev(); Update(); return true; }
      if (name == m_prefix + "FAST")   { m_replay_engine.FastForward(10); Update(); return true; }
      if (name == m_prefix + "RESET")  { m_replay_engine.Reset(); Update(); return true; }

      if (name == m_prefix + "SPD_01")  { m_replay_engine.SetSpeed(SPEED_0_1X); Update(); return true; }
      if (name == m_prefix + "SPD_05")  { m_replay_engine.SetSpeed(SPEED_0_5X); Update(); return true; }
      if (name == m_prefix + "SPD_1")   { m_replay_engine.SetSpeed(SPEED_1X); Update(); return true; }
      if (name == m_prefix + "SPD_2")   { m_replay_engine.SetSpeed(SPEED_2X); Update(); return true; }
      if (name == m_prefix + "SPD_5")   { m_replay_engine.SetSpeed(SPEED_5X); Update(); return true; }
      if (name == m_prefix + "SPD_10")  { m_replay_engine.SetSpeed(SPEED_10X); Update(); return true; }
      if (name == m_prefix + "SPD_25")  { m_replay_engine.SetSpeed(SPEED_25X); Update(); return true; }
      if (name == m_prefix + "SPD_50")  { m_replay_engine.SetSpeed(SPEED_50X); Update(); return true; }
      if (name == m_prefix + "SPD_100") { m_replay_engine.SetSpeed(SPEED_100X); Update(); return true; }

      return false;
   }

   void Destroy()
   {
      ObjectsDeleteAll(m_chart_id, m_prefix);
   }
};
`;

export const TRADING_PANEL_MQH = `//+------------------------------------------------------------------+
//|                                                 TradingPanel.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Positions/OrderExecutionEngine.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Positions/OrderManager.mqh"
#include "../Core/MarketEngine.mqh"
#include "../Core/ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CTradingPanel: Dedicated Soft4FX Manual Trading Interface  |
//+------------------------------------------------------------------+
class CTradingPanel
{
private:
   long                   m_chart_id;
   COrderExecutionEngine *m_exec_engine;
   CPositionManager      *m_position_manager;
   COrderManager         *m_order_manager;
   CMarketEngine         *m_market_engine;
   CReplayEngine         *m_replay_engine;
   string                 m_prefix;
   int                    m_x, m_y, m_w, m_h;
   double                 m_lots;
   double                 m_sl_pips;
   double                 m_tp_pips;

   void CreateBtn(const string id, const int x, const int y, const int w, const int h, const string txt, const color bg, const color fg, const int fsize = 8)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XSIZE, w);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YSIZE, h);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_BGCOLOR, bg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

   void CreateLbl(const string id, const int x, const int y, const string txt, const color fg, const int fsize = 8)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

public:
   CTradingPanel()
   {
      m_chart_id = 0;
      m_exec_engine = NULL;
      m_position_manager = NULL;
      m_order_manager = NULL;
      m_market_engine = NULL;
      m_replay_engine = NULL;
      m_prefix = "PE_TRD_";
      m_x = 10; m_y = 115; m_w = 235; m_h = 240;
      m_lots = 0.10;
      m_sl_pips = 20.0;
      m_tp_pips = 40.0;
   }

   bool Initialize(const long chart_id, COrderExecutionEngine *exec, CPositionManager *pos, COrderManager *ord, CMarketEngine *mkt, CReplayEngine *rpl, const int x = 10, const int y = 115)
   {
      m_chart_id = chart_id;
      m_exec_engine = exec;
      m_position_manager = pos;
      m_order_manager = ord;
      m_market_engine = mkt;
      m_replay_engine = rpl;
      m_x = x; m_y = y;
      Render();
      return true;
   }

   void Render()
   {
      Destroy();

      // Card Background
      string bg_name = m_prefix + "BG";
      ObjectCreate(m_chart_id, bg_name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XDISTANCE, m_x);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YDISTANCE, m_y);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XSIZE, m_w);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YSIZE, m_h);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BGCOLOR, (color)0x121722);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_COLOR, (color)0x2D3748);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_TYPE, BORDER_FLAT);

      CreateLbl("TITLE", m_x + 8, m_y + 6, "MANUAL TRADING", (color)0x10B981, 9);

      // Volume Section
      int ly = m_y + 25;
      CreateLbl("VOL_LBL", m_x + 8, ly + 2, "Volume:", (color)0x94A3B8, 8);
      CreateBtn("VOL_MINUS", m_x + 55, ly, 22, 18, "-", (color)0x1E293B, (color)0xF1F5F9);
      CreateBtn("VOL_VAL",   m_x + 80, ly, 45, 18, StringFormat("%.2f", m_lots), (color)0x0F172A, (color)0x38BDF8);
      CreateBtn("VOL_PLUS",  m_x + 128, ly, 22, 18, "+", (color)0x1E293B, (color)0xF1F5F9);
      CreateBtn("VOL_001",   m_x + 155, ly, 34, 18, "0.01", (color)0x1E293B, (color)0x94A3B8, 7);
      CreateBtn("VOL_010",   m_x + 192, ly, 34, 18, "0.10", (color)0x1E293B, (color)0x94A3B8, 7);

      // SL / TP Configuration
      int sy = m_y + 47;
      CreateLbl("SL_LBL", m_x + 8, sy + 2, "SL (pips):", (color)0x94A3B8, 8);
      CreateBtn("SL_VAL", m_x + 65, sy, 45, 18, StringFormat("%.0f", m_sl_pips), (color)0x1E293B, (color)0xEF4444);
      CreateLbl("TP_LBL", m_x + 120, sy + 2, "TP (pips):", (color)0x94A3B8, 8);
      CreateBtn("TP_VAL", m_x + 180, sy, 45, 18, StringFormat("%.0f", m_tp_pips), (color)0x1E293B, (color)0x10B981);

      // Primary Market Execution Buttons
      int my = m_y + 70;
      CreateBtn("BUY_MKT",  m_x + 8,   my, 105, 32, "BUY MARKET", (color)0x16A34A, (color)0xFFFFFF, 9);
      CreateBtn("SELL_MKT", m_x + 120, my, 105, 32, "SELL MARKET", (color)0xDC2626, (color)0xFFFFFF, 9);

      // Pending Orders Buttons
      int py = m_y + 107;
      CreateBtn("BUY_LIMIT",  m_x + 8,   py, 52, 22, "BUY LMT", (color)0x1E293B, (color)0x38BDF8, 7);
      CreateBtn("SELL_LIMIT", m_x + 63,  py, 52, 22, "SELL LMT", (color)0x1E293B, (color)0xF43F5E, 7);
      CreateBtn("BUY_STOP",   m_x + 120, py, 52, 22, "BUY STP", (color)0x1E293B, (color)0x38BDF8, 7);
      CreateBtn("SELL_STOP",  m_x + 175, py, 52, 22, "SELL STP", (color)0x1E293B, (color)0xF43F5E, 7);

      // Fast Close Actions
      int cy = m_y + 135;
      CreateBtn("CLOSE_ALL",     m_x + 8, cy, 218, 22, "CLOSE ALL POSITIONS", (color)0xB45309, (color)0xFFFFFF, 8);
      CreateBtn("CLOSE_WINNERS", m_x + 8, cy + 26, 105, 20, "CLOSE WINNERS", (color)0x065F46, (color)0xD1FAE5, 7);
      CreateBtn("CLOSE_LOSERS",  m_x + 120, cy + 26, 106, 20, "CLOSE LOSERS", (color)0x991B1B, (color)0xFEE2E2, 7);

      // Breakeven Helper
      CreateBtn("BREAKEVEN_ALL", m_x + 8, cy + 50, 218, 19, "SET ALL SL TO BREAKEVEN (BE)", (color)0x334155, (color)0xCBD5E1, 7);

      ChartRedraw(m_chart_id);
   }

   bool OnClick(const string name)
   {
      if (StringFind(name, m_prefix) != 0) return false;

      double ask = m_market_engine.GetAsk();
      double bid = m_market_engine.GetBid();
      double pt  = 0.001; // dynamically converted

      // Lots adjustment
      if (name == m_prefix + "VOL_PLUS")  { m_lots = MathMin(100.0, m_lots + 0.05); Render(); return true; }
      if (name == m_prefix + "VOL_MINUS") { m_lots = MathMax(0.01, m_lots - 0.05); Render(); return true; }
      if (name == m_prefix + "VOL_001")   { m_lots = 0.01; Render(); return true; }
      if (name == m_prefix + "VOL_010")   { m_lots = 0.10; Render(); return true; }

      // SL adjustment
      if (name == m_prefix + "SL_VAL")
      {
         m_sl_pips = (m_sl_pips == 20.0) ? 50.0 : (m_sl_pips == 50.0) ? 100.0 : 20.0;
         Render();
         return true;
      }
      // TP adjustment
      if (name == m_prefix + "TP_VAL")
      {
         m_tp_pips = (m_tp_pips == 40.0) ? 100.0 : (m_tp_pips == 100.0) ? 200.0 : 40.0;
         Render();
         return true;
      }

      // Execute BUY MARKET
      if (name == m_prefix + "BUY_MKT")
      {
         double sl = (m_sl_pips > 0.0) ? ask - (m_sl_pips * 0.1) : 0.0;
         double tp = (m_tp_pips > 0.0) ? ask + (m_tp_pips * 0.1) : 0.0;
         m_exec_engine.ExecuteMarketBuy(m_lots, sl, tp, "SIM_BUY");
         return true;
      }

      // Execute SELL MARKET
      if (name == m_prefix + "SELL_MKT")
      {
         double sl = (m_sl_pips > 0.0) ? bid + (m_sl_pips * 0.1) : 0.0;
         double tp = (m_tp_pips > 0.0) ? bid - (m_tp_pips * 0.1) : 0.0;
         m_exec_engine.ExecuteMarketSell(m_lots, sl, tp, "SIM_SELL");
         return true;
      }

      // Execute Pending Orders (offset by 20 pips)
      if (name == m_prefix + "BUY_LIMIT")
      {
         double target = ask - (20.0 * 0.1);
         m_order_manager.PlacePendingOrder(SIM_ORDER_BUY_LIMIT, m_lots, target, target - (m_sl_pips * 0.1), target + (m_tp_pips * 0.1));
         return true;
      }
      if (name == m_prefix + "SELL_LIMIT")
      {
         double target = bid + (20.0 * 0.1);
         m_order_manager.PlacePendingOrder(SIM_ORDER_SELL_LIMIT, m_lots, target, target + (m_sl_pips * 0.1), target - (m_tp_pips * 0.1));
         return true;
      }
      if (name == m_prefix + "BUY_STOP")
      {
         double target = ask + (20.0 * 0.1);
         m_order_manager.PlacePendingOrder(SIM_ORDER_BUY_STOP, m_lots, target, target - (m_sl_pips * 0.1), target + (m_tp_pips * 0.1));
         return true;
      }
      if (name == m_prefix + "SELL_STOP")
      {
         double target = bid - (20.0 * 0.1);
         m_order_manager.PlacePendingOrder(SIM_ORDER_SELL_STOP, m_lots, target, target + (m_sl_pips * 0.1), target - (m_tp_pips * 0.1));
         return true;
      }

      // Fast Close Actions
      datetime cur_t = m_replay_engine.GetCurrentTime();
      if (name == m_prefix + "CLOSE_ALL")
      {
         m_position_manager.CloseAll(bid, ask, cur_t);
         return true;
      }
      if (name == m_prefix + "CLOSE_WINNERS")
      {
         m_position_manager.CloseWinners(bid, ask, cur_t);
         return true;
      }
      if (name == m_prefix + "CLOSE_LOSERS")
      {
         m_position_manager.CloseLosers(bid, ask, cur_t);
         return true;
      }
      if (name == m_prefix + "BREAKEVEN_ALL")
      {
         int count = m_position_manager.GetCount();
         for (int i = 0; i < count; i++)
         {
            SimPosition p;
            if (m_position_manager.GetPosition(i, p)) m_position_manager.MoveToBreakeven(p.ticket);
         }
         return true;
      }

      return false;
   }

   void Destroy()
   {
      ObjectsDeleteAll(m_chart_id, m_prefix);
   }
};
`;

export const ACCOUNT_PANEL_MQH = `//+------------------------------------------------------------------+
//|                                                 AccountPanel.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Core/AccountEngine.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Positions/OrderManager.mqh"

//+------------------------------------------------------------------+
//| Class CAccountPanel: Permanent Account & Risk Telemetry Panel    |
//+------------------------------------------------------------------+
class CAccountPanel
{
private:
   long              m_chart_id;
   CAccountEngine   *m_account_engine;
   CPositionManager *m_position_manager;
   COrderManager    *m_order_manager;
   string            m_prefix;
   int               m_x, m_y, m_w, m_h;

   void CreateLbl(const string id, const int x, const int y, const string txt, const color fg, const int fsize = 8)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

public:
   CAccountPanel()
   {
      m_chart_id = 0;
      m_account_engine = NULL;
      m_position_manager = NULL;
      m_order_manager = NULL;
      m_prefix = "PE_ACC_";
      m_x = 255; m_y = 115; m_w = 235; m_h = 240;
   }

   bool Initialize(const long chart_id, CAccountEngine *account, CPositionManager *pos, COrderManager *ord, const int x = 255, const int y = 115)
   {
      m_chart_id = chart_id;
      m_account_engine = account;
      m_position_manager = pos;
      m_order_manager = ord;
      m_x = x; m_y = y;
      Render();
      return true;
   }

   void Render()
   {
      Destroy();

      // Card Background
      string bg_name = m_prefix + "BG";
      ObjectCreate(m_chart_id, bg_name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XDISTANCE, m_x);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YDISTANCE, m_y);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XSIZE, m_w);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YSIZE, m_h);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BGCOLOR, (color)0x121722);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_COLOR, (color)0x2D3748);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_TYPE, BORDER_FLAT);

      CreateLbl("TITLE", m_x + 8, m_y + 6, "VIRTUAL ACCOUNT TELEMETRY", (color)0x10B981, 9);

      int ly = m_y + 25;
      CreateLbl("L_BAL",     m_x + 8, ly,       "BALANCE:      $10,000.00", (color)0xCBD5E1);
      CreateLbl("L_EQ",      m_x + 8, ly + 18,  "EQUITY:       $10,000.00", (color)0x38BDF8);
      CreateLbl("L_FL_PNL",  m_x + 8, ly + 36,  "FLOATING P/L: +$0.00",     (color)0x10B981);
      CreateLbl("L_RL_PNL",  m_x + 8, ly + 54,  "REALIZED P/L: $0.00",      (color)0x94A3B8);
      CreateLbl("L_MARGIN",  m_x + 8, ly + 72,  "MARGIN:       $0.00",      (color)0x94A3B8);
      CreateLbl("L_FREE_M",  m_x + 8, ly + 90,  "FREE MARGIN:  $10,000.00", (color)0xCBD5E1);
      CreateLbl("L_M_LEVEL", m_x + 8, ly + 108, "MARGIN LEVEL: 0.0%",       (color)0xCBD5E1);
      CreateLbl("L_DAILY",   m_x + 8, ly + 126, "DAILY P/L:    $0.00",      (color)0x94A3B8);
      CreateLbl("L_MAX_DD",  m_x + 8, ly + 144, "DRAWDOWN:     0.0%",       (color)0xF59E0B);
      CreateLbl("L_COUNTS",  m_x + 8, ly + 165, "POSITIONS: 0 | ORDERS: 0", (color)0x38BDF8);

      ChartRedraw(m_chart_id);
   }

   void Update()
   {
      if (m_account_engine == NULL || m_position_manager == NULL) return;

      SimAccountState st = m_account_engine.GetState();
      ObjectSetString(m_chart_id, m_prefix + "L_BAL", OBJPROP_TEXT, StringFormat("BALANCE:      $%.2f", st.balance));
      ObjectSetString(m_chart_id, m_prefix + "L_EQ", OBJPROP_TEXT,  StringFormat("EQUITY:       $%.2f", st.equity));

      string fl_str = StringFormat("FLOATING P/L: %s$%.2f", (st.floating_pnl >= 0 ? "+" : ""), st.floating_pnl);
      ObjectSetString(m_chart_id, m_prefix + "L_FL_PNL", OBJPROP_TEXT, fl_str);
      ObjectSetInteger(m_chart_id, m_prefix + "L_FL_PNL", OBJPROP_COLOR, (st.floating_pnl >= 0) ? (color)0x10B981 : (color)0xEF4444);

      string rl_str = StringFormat("REALIZED P/L: %s$%.2f", (st.realized_pnl >= 0 ? "+" : ""), st.realized_pnl);
      ObjectSetString(m_chart_id, m_prefix + "L_RL_PNL", OBJPROP_TEXT, rl_str);

      ObjectSetString(m_chart_id, m_prefix + "L_MARGIN",  OBJPROP_TEXT, StringFormat("MARGIN:       $%.2f", st.margin));
      ObjectSetString(m_chart_id, m_prefix + "L_FREE_M",  OBJPROP_TEXT, StringFormat("FREE MARGIN:  $%.2f", st.free_margin));
      ObjectSetString(m_chart_id, m_prefix + "L_M_LEVEL", OBJPROP_TEXT, StringFormat("MARGIN LEVEL: %.1f%%", st.margin_level));
      ObjectSetString(m_chart_id, m_prefix + "L_DAILY",   OBJPROP_TEXT, StringFormat("DAILY P/L:    %s$%.2f", (st.daily_pnl >= 0 ? "+" : ""), st.daily_pnl));
      ObjectSetString(m_chart_id, m_prefix + "L_MAX_DD",  OBJPROP_TEXT, StringFormat("DRAWDOWN:     %.2f%%", st.max_drawdown_pct));

      int pos_count = m_position_manager.GetCount();
      int ord_count = (m_order_manager != NULL) ? m_order_manager.GetCount() : 0;
      ObjectSetString(m_chart_id, m_prefix + "L_COUNTS", OBJPROP_TEXT, StringFormat("POSITIONS: %d | ORDERS: %d", pos_count, ord_count));
   }

   void Destroy()
   {
      ObjectsDeleteAll(m_chart_id, m_prefix);
   }
};
`;

export const POSITIONS_PANEL_MQH = `//+------------------------------------------------------------------+
//|                                               PositionsPanel.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Core/MarketEngine.mqh"
#include "../Core/ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CPositionsPanel: Open Virtual Positions Table & Trade Actions|
//+------------------------------------------------------------------+
class CPositionsPanel
{
private:
   long              m_chart_id;
   CPositionManager *m_position_manager;
   CMarketEngine    *m_market_engine;
   CReplayEngine    *m_replay_engine;
   string            m_prefix;
   int               m_x, m_y, m_w, m_h;

   void CreateBtn(const string id, const int x, const int y, const int w, const int h, const string txt, const color bg, const color fg, const int fsize = 7)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_BUTTON, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XSIZE, w);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YSIZE, h);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_BGCOLOR, bg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

   void CreateLbl(const string id, const int x, const int y, const string txt, const color fg, const int fsize = 8)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

public:
   CPositionsPanel()
   {
      m_chart_id = 0;
      m_position_manager = NULL;
      m_market_engine = NULL;
      m_replay_engine = NULL;
      m_prefix = "PE_POSP_";
      m_x = 10; m_y = 360; m_w = 480; m_h = 130;
   }

   bool Initialize(const long chart_id, CPositionManager *pos, CMarketEngine *mkt, CReplayEngine *rpl, const int x = 10, const int y = 360)
   {
      m_chart_id = chart_id;
      m_position_manager = pos;
      m_market_engine = mkt;
      m_replay_engine = rpl;
      m_x = x; m_y = y;
      Render();
      return true;
   }

   void Render()
   {
      Destroy();

      // Card Background
      string bg_name = m_prefix + "BG";
      ObjectCreate(m_chart_id, bg_name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XDISTANCE, m_x);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YDISTANCE, m_y);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XSIZE, m_w);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YSIZE, m_h);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BGCOLOR, (color)0x121722);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_COLOR, (color)0x2D3748);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_TYPE, BORDER_FLAT);

      CreateLbl("TITLE", m_x + 8, m_y + 6, "ACTIVE SIMULATOR POSITIONS", (color)0x10B981, 9);

      // Table Column Headers
      int hy = m_y + 24;
      CreateLbl("TH_TICKET", m_x + 8,   hy, "Ticket", (color)0x64748B, 7);
      CreateLbl("TH_TYPE",   m_x + 55,  hy, "Type",   (color)0x64748B, 7);
      CreateLbl("TH_LOTS",   m_x + 95,  hy, "Lots",   (color)0x64748B, 7);
      CreateLbl("TH_ENTRY",  m_x + 135, hy, "Entry",  (color)0x64748B, 7);
      CreateLbl("TH_PRICE",  m_x + 195, hy, "Current",(color)0x64748B, 7);
      CreateLbl("TH_PNL",    m_x + 255, hy, "P/L ($)",(color)0x64748B, 7);
      CreateLbl("TH_PIPS",   m_x + 325, hy, "Pips",   (color)0x64748B, 7);
      CreateLbl("TH_ACTION", m_x + 380, hy, "Trade Actions", (color)0x64748B, 7);

      Update();
   }

   void Update()
   {
      if (m_position_manager == NULL) return;

      // Clear previous row items
      ObjectsDeleteAll(m_chart_id, m_prefix + "ROW_");

      int count = m_position_manager.GetCount();
      int max_display = MathMin(count, 4); // Display up to 4 positions in table

      if (count == 0)
      {
         CreateLbl("ROW_EMPTY", m_x + 150, m_y + 60, "No open virtual positions.", (color)0x64748B, 8);
         return;
      }

      for (int i = 0; i < max_display; i++)
      {
         SimPosition p;
         if (!m_position_manager.GetPosition(i, p)) continue;

         int ry = m_y + 42 + (i * 20);
         string r_id = StringFormat("ROW_%d_", p.ticket);

         CreateLbl(r_id + "TKT", m_x + 8,   ry, StringFormat("#%d", p.ticket), (color)0xCBD5E1, 7);
         CreateLbl(r_id + "TYP", m_x + 55,  ry, (p.direction == DIRECTION_BUY ? "BUY" : "SELL"),
                   (p.direction == DIRECTION_BUY ? (color)0x10B981 : (color)0xEF4444), 7);
         CreateLbl(r_id + "LOT", m_x + 95,  ry, StringFormat("%.2f", p.lots), (color)0xCBD5E1, 7);
         CreateLbl(r_id + "ENT", m_x + 135, ry, StringFormat("%.4f", p.open_price), (color)0xCBD5E1, 7);
         CreateLbl(r_id + "CUR", m_x + 195, ry, StringFormat("%.4f", p.current_price), (color)0x38BDF8, 7);

         color pnl_c = (p.floating_profit >= 0) ? (color)0x10B981 : (color)0xEF4444;
         CreateLbl(r_id + "PNL", m_x + 255, ry, StringFormat("%s$%.2f", (p.floating_profit >= 0 ? "+" : ""), p.floating_profit), pnl_c, 7);
         CreateLbl(r_id + "PIP", m_x + 325, ry, StringFormat("%.1fp", p.floating_pips), pnl_c, 7);

         // Actions: [Close (X)], [Partial 50% (½)], [BE]
         CreateBtn(r_id + "CLS", m_x + 380, ry - 1, 24, 16, "X", (color)0x991B1B, (color)0xFFFFFF, 7);
         CreateBtn(r_id + "PRT", m_x + 408, ry - 1, 24, 16, "½", (color)0x334155, (color)0xF1F5F9, 7);
         CreateBtn(r_id + "BE",  m_x + 436, ry - 1, 26, 16, "BE", (color)0x1E293B, (color)0x38BDF8, 7);
      }

      ChartRedraw(m_chart_id);
   }

   bool OnClick(const string name)
   {
      if (StringFind(name, m_prefix + "ROW_") != 0) return false;

      // Extract Ticket from name: PE_POSP_ROW_<ticket>_<ACTION>
      int count = m_position_manager.GetCount();
      for (int i = 0; i < count; i++)
      {
         SimPosition p;
         if (!m_position_manager.GetPosition(i, p)) continue;

         string r_id = StringFormat("ROW_%d_", p.ticket);
         double close_p = (p.direction == DIRECTION_BUY) ? m_market_engine.GetBid() : m_market_engine.GetAsk();
         datetime cur_t = m_replay_engine.GetCurrentTime();

         if (name == m_prefix + r_id + "CLS")
         {
            m_position_manager.ClosePosition(p.ticket, close_p, cur_t, "MANUAL_ROW");
            Update();
            return true;
         }
         if (name == m_prefix + r_id + "PRT")
         {
            m_position_manager.PartialClose(p.ticket, p.lots * 0.5, close_p, cur_t);
            Update();
            return true;
         }
         if (name == m_prefix + r_id + "BE")
         {
            m_position_manager.MoveToBreakeven(p.ticket);
            Update();
            return true;
         }
      }
      return false;
   }

   void Destroy()
   {
      ObjectsDeleteAll(m_chart_id, m_prefix);
   }
};
`;

export const JOURNAL_PANEL_MQH = `//+------------------------------------------------------------------+
//|                                              JournalPanel.mqh    |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Core/ReplayEngine.mqh"

//+------------------------------------------------------------------+
//| Class CJournalPanel: Replay Trade Log & Journal History          |
//| Displays closed trades, timestamps, P/L, execution reasons,      |
//| and real-time simulator audit logs.                              |
//+------------------------------------------------------------------+
class CJournalPanel
{
private:
   long              m_chart_id;
   CPositionManager *m_position_manager;
   CReplayEngine    *m_replay_engine;
   string            m_prefix;
   int               m_x, m_y, m_w, m_h;

   void CreateLbl(const string id, const int x, const int y, const string txt, const color fg, const int fsize = 7)
   {
      string name = m_prefix + id;
      ObjectCreate(m_chart_id, name, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name, OBJPROP_XDISTANCE, x);
      ObjectSetInteger(m_chart_id, name, OBJPROP_YDISTANCE, y);
      ObjectSetString(m_chart_id, name, OBJPROP_TEXT, txt);
      ObjectSetInteger(m_chart_id, name, OBJPROP_COLOR, fg);
      ObjectSetInteger(m_chart_id, name, OBJPROP_FONTSIZE, fsize);
      ObjectSetInteger(m_chart_id, name, OBJPROP_SELECTABLE, false);
   }

public:
   CJournalPanel()
   {
      m_chart_id = 0;
      m_position_manager = NULL;
      m_replay_engine = NULL;
      m_prefix = "PE_JRN_";
      m_x = 10; m_y = 500; m_w = 480; m_h = 100;
   }

   bool Initialize(const long chart_id, CPositionManager *positions, CReplayEngine *replay, const int x = 10, const int y = 500, const int w = 480, const int h = 100)
   {
      m_chart_id = chart_id;
      m_position_manager = positions;
      m_replay_engine = replay;
      m_x = x; m_y = y; m_w = w; m_h = h;
      Render();
      return true;
   }

   void Render()
   {
      Destroy();

      // Card Background
      string bg_name = m_prefix + "BG";
      ObjectCreate(m_chart_id, bg_name, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XDISTANCE, m_x);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YDISTANCE, m_y);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_XSIZE, m_w);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_YSIZE, m_h);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BGCOLOR, (color)0x121722);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_COLOR, (color)0x2D3748);
      ObjectSetInteger(m_chart_id, bg_name, OBJPROP_BORDER_TYPE, BORDER_FLAT);

      CreateLbl("TITLE", m_x + 8, m_y + 4, "SIMULATION TRADE JOURNAL & AUDIT LOG", (color)0x38BDF8, 8);
      CreateLbl("HEADER", m_x + 8, m_y + 18, "TKT    DIR  LOTS  OPEN      CLOSE     P/L ($)   REASON", (color)0x64748B, 7);

      for (int i = 0; i < 4; i++)
      {
         CreateLbl(StringFormat("ROW_%d", i), m_x + 8, m_y + 32 + (i * 15), "---", (color)0x475569, 7);
      }
      ChartRedraw(m_chart_id);
   }

   void Update()
   {
      if (m_position_manager == NULL) return;
      int closed_total = m_position_manager.GetClosedCount();

      for (int i = 0; i < 4; i++)
      {
         string row_id = StringFormat("ROW_%d", i);
         int trade_idx = closed_total - 1 - i;
         if (trade_idx >= 0)
         {
            SimClosedTrade ct;
            if (m_position_manager.GetClosedTrade(trade_idx, ct))
            {
               string dir_str = (ct.direction == DIRECTION_BUY) ? "BUY " : "SELL";
               string sign = (ct.realized_profit >= 0) ? "+" : "";
               string row_txt = StringFormat("#%-5d %-4s %-4.2f %-9.2f %-9.2f %s$%-7.2f %s",
                                             ct.ticket, dir_str, ct.lots,
                                             ct.open_price, ct.close_price,
                                             sign, ct.realized_profit, ct.close_reason);
               ObjectSetString(m_chart_id, m_prefix + row_id, OBJPROP_TEXT, row_txt);
               color c = (ct.realized_profit >= 0) ? (color)0x10B981 : (color)0xEF4444;
               ObjectSetInteger(m_chart_id, m_prefix + row_id, OBJPROP_COLOR, c);
            }
         }
         else
         {
            ObjectSetString(m_chart_id, m_prefix + row_id, OBJPROP_TEXT, "--- No closed trades yet ---");
            ObjectSetInteger(m_chart_id, m_prefix + row_id, OBJPROP_COLOR, (color)0x334155);
         }
      }
   }

   void Destroy()
   {
      ObjectsDeleteAll(m_chart_id, m_prefix);
   }
};
`;

export const MAIN_WORKSPACE_MQH = `//+------------------------------------------------------------------+
//|                                                MainWorkspace.mqh |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright "Copyright 2026, Pouri-Escobar"
#property link      "https://github.com/pouri-escobar/market-replay"
#property strict

#include "../Core/SimulationDefines.mqh"
#include "../Core/ReplayEngine.mqh"
#include "../Core/MarketEngine.mqh"
#include "../Core/AccountEngine.mqh"
#include "../Positions/PositionManager.mqh"
#include "../Positions/OrderExecutionEngine.mqh"
#include "../Positions/OrderManager.mqh"
#include "../Chart/ReplayChart.mqh"
#include "../UI/ReplayControlPanel.mqh"
#include "../UI/TradingPanel.mqh"
#include "../UI/AccountPanel.mqh"
#include "../UI/PositionsPanel.mqh"
#include "../UI/JournalPanel.mqh"

//+------------------------------------------------------------------+
//| Class CMainWorkspace: Master Soft4FX-Style Simulator Environment |
//| Coordinates Top Status Banner, Replay Controls, Trading Panel,   |
//| Account Telemetry, Positions Table, Journal, and Dynamic Resizing|
//+------------------------------------------------------------------+
class CMainWorkspace
{
private:
   long                   m_chart_id;
   CReplayEngine         *m_replay_engine;
   CMarketEngine         *m_market_engine;
   CAccountEngine        *m_account_engine;
   CPositionManager      *m_position_manager;
   COrderExecutionEngine *m_exec_engine;
   COrderManager         *m_order_manager;
   CReplayChart          *m_chart_renderer;

   CReplayControlPanel    m_ctrl_panel;
   CTradingPanel          m_trading_panel;
   CAccountPanel          m_account_panel;
   CPositionsPanel        m_positions_panel;
   CJournalPanel          m_journal_panel;

   string                 m_prefix;
   bool                   m_is_tester_visual;

public:
   CMainWorkspace()
   {
      m_chart_id = 0;
      m_prefix = "PE_WS_";
      m_is_tester_visual = false;
   }

   bool Initialize(const long chart_id, CReplayEngine *replay, CMarketEngine *market, CAccountEngine *account, CPositionManager *positions, COrderExecutionEngine *exec, COrderManager *orders, CReplayChart *chart_renderer)
   {
      m_chart_id = chart_id;
      m_replay_engine = replay;
      m_market_engine = market;
      m_account_engine = account;
      m_position_manager = positions;
      m_exec_engine = exec;
      m_order_manager = orders;
      m_chart_renderer = chart_renderer;

      m_is_tester_visual = (bool)MQLInfoInteger(MQL_TESTER) && (bool)MQLInfoInteger(MQL_VISUAL_MODE);

      RenderHeaderBanner();

      // Initialize all sub-panels with fixed pixel coordinates
      m_ctrl_panel.Initialize(m_chart_id, m_replay_engine, 10, 32);
      m_trading_panel.Initialize(m_chart_id, m_exec_engine, m_position_manager, m_order_manager, m_market_engine, m_replay_engine, 10, 112);
      m_account_panel.Initialize(m_chart_id, m_account_engine, m_position_manager, m_order_manager, 255, 112);
      m_positions_panel.Initialize(m_chart_id, m_position_manager, m_market_engine, m_replay_engine, 10, 360);
      m_journal_panel.Initialize(m_chart_id, m_position_manager, m_replay_engine, 10, 500);

      return true;
   }

   void RenderHeaderBanner()
   {
      string name_bg = m_prefix + "HDR_BG";
      int chart_w = (int)ChartGetInteger(m_chart_id, CHART_WIDTH_IN_PIXELS);
      if (chart_w <= 0) chart_w = 1200;

      ObjectCreate(m_chart_id, name_bg, OBJ_RECTANGLE_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_XDISTANCE, 0);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_YDISTANCE, 0);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_XSIZE, chart_w);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_YSIZE, 28);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_BGCOLOR, (color)0x0D1117);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_BORDER_COLOR, (color)0x21262D);
      ObjectSetInteger(m_chart_id, name_bg, OBJPROP_BORDER_TYPE, BORDER_FLAT);

      string name_title = m_prefix + "HDR_TITLE";
      ObjectCreate(m_chart_id, name_title, OBJ_LABEL, 0, 0, 0);
      ObjectSetInteger(m_chart_id, name_title, OBJPROP_CORNER, CORNER_LEFT_UPPER);
      ObjectSetInteger(m_chart_id, name_title, OBJPROP_XDISTANCE, 12);
      ObjectSetInteger(m_chart_id, name_title, OBJPROP_YDISTANCE, 6);
      string mode_str = m_is_tester_visual ? "[STRATEGY TESTER VISUAL WORKSPACE]" : "[STANDALONE REPLAY WORKSPACE]";
      ObjectSetString(m_chart_id, name_title, OBJPROP_TEXT, "POURI-ESCOBAR MARKET REPLAY  " + mode_str + "  |  " + _Symbol + ", " + EnumToString(_Period));
      ObjectSetInteger(m_chart_id, name_title, OBJPROP_COLOR, (color)0x34D399);
      ObjectSetInteger(m_chart_id, name_title, OBJPROP_FONTSIZE, 9);
   }

   void Update()
   {
      m_ctrl_panel.Update();
      m_account_panel.Update();
      m_positions_panel.Update();
      m_journal_panel.Update();
      ChartRedraw(m_chart_id);
   }

   bool OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
   {
      if (id == CHARTEVENT_OBJECT_CLICK)
      {
         if (m_ctrl_panel.OnClick(sparam))      { Update(); return true; }
         if (m_trading_panel.OnClick(sparam))   { Update(); return true; }
         if (m_positions_panel.OnClick(sparam)) { Update(); return true; }
      }

      // Hotkey triggers: [Space] = Play/Pause, [Right Arrow] = Step forward, [Left Arrow] = Step back
      if (id == CHARTEVENT_KEYDOWN)
      {
         if (lparam == 32) { m_replay_engine.TogglePlayPause(); Update(); return true; }
         if (lparam == 39) { m_replay_engine.StepNext(); Update(); return true; }
         if (lparam == 37) { m_replay_engine.StepPrev(); Update(); return true; }
         if (lparam == 187 || lparam == 107) { if (m_chart_renderer != NULL) m_chart_renderer.ZoomIn(); }  // '+' Zoom In
         if (lparam == 189 || lparam == 109) { if (m_chart_renderer != NULL) m_chart_renderer.ZoomOut(); } // '-' Zoom Out
      }

      // Dynamic Resizing
      if (id == CHARTEVENT_CHART_CHANGE)
      {
         int w = (int)ChartGetInteger(m_chart_id, CHART_WIDTH_IN_PIXELS);
         ObjectSetInteger(m_chart_id, m_prefix + "HDR_BG", OBJPROP_XSIZE, w);
         ChartRedraw(m_chart_id);
      }

      return false;
   }

   void Destroy()
   {
      ObjectsDeleteAll(m_chart_id, m_prefix);
      m_ctrl_panel.Destroy();
      m_trading_panel.Destroy();
      m_account_panel.Destroy();
      m_positions_panel.Destroy();
      m_journal_panel.Destroy();
      ChartRedraw(m_chart_id);
   }
};
`;

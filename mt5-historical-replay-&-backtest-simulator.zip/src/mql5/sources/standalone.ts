import {
  SIMULATION_DEFINES_MQH,
  MARKET_DATA_MQH,
  REPLAY_ENGINE_MQH,
  MARKET_ENGINE_MQH,
  ACCOUNT_ENGINE_MQH,
  POSITION_MANAGER_MQH,
  ORDER_EXECUTION_ENGINE_MQH,
  ORDER_MANAGER_MQH
} from './core';
import {
  REPLAY_DATA_FEED_MQH,
  REPLAY_CANDLE_RENDERER_MQH,
  TRADE_RENDERER_MQH,
  REPLAY_RENDERER_MQH,
  REPLAY_CHART_MQH
} from './chart';
import {
  REPLAY_CONTROL_PANEL_MQH,
  TRADING_PANEL_MQH,
  ACCOUNT_PANEL_MQH,
  POSITIONS_PANEL_MQH,
  MAIN_WORKSPACE_MQH
} from './ui';

// Strip #include lines for clean single-file compilation (keep standard Canvas.mqh)
function stripIncludes(code: string): string {
  return code
    .replace(/#include\s+["<](?!Canvas\/Canvas\.mqh)[^">]+[">]/g, '')
    .replace(/#property\s+copyright\s+"[^"]+"/g, '')
    .replace(/#property\s+link\s+"[^"]+"/g, '')
    .replace(/#property\s+strict/g, '');
}

export const STANDALONE_WORKSPACE_EA_MQL5 = `//+------------------------------------------------------------------+
//|                        POURI-ESCOBAR-MARKET-REPLAY-STANDALONE.mq5 |
//|                                  Copyright 2026, Pouri-Escobar   |
//|                        Professional MT5 Market Replay Simulator |
//+------------------------------------------------------------------+
#property copyright   "Copyright 2026, Pouri-Escobar"
#property link        "https://github.com/pouri-escobar/market-replay"
#property version     "3.00"
#property description "Professional Soft4FX-Style Historical Trading Simulator & Market Replay Workspace"
#property description "100% Self-Contained Standalone Edition with Dedicated Canvas Replay Engine & Zero Look-Ahead"
#property strict

#include <Canvas/Canvas.mqh>

//====================================================================
// SECTION 1: CORE DEFINES & DATA STRUCTURES
//====================================================================
${stripIncludes(SIMULATION_DEFINES_MQH)}

//====================================================================
// SECTION 2: AUTHORITATIVE MARKET DATA & ZERO LOOK-AHEAD DATA FEED
//====================================================================
${stripIncludes(MARKET_DATA_MQH)}
${stripIncludes(REPLAY_ENGINE_MQH)}
${stripIncludes(REPLAY_DATA_FEED_MQH)}
${stripIncludes(MARKET_ENGINE_MQH)}

//====================================================================
// SECTION 3: VIRTUAL ACCOUNT & POSITION MANAGEMENT
//====================================================================
${stripIncludes(ACCOUNT_ENGINE_MQH)}
${stripIncludes(POSITION_MANAGER_MQH)}
${stripIncludes(ORDER_MANAGER_MQH)}
${stripIncludes(ORDER_EXECUTION_ENGINE_MQH)}

//====================================================================
// SECTION 4: DEDICATED CANVAS REPLAY RENDERER & REPLAY CHART
//====================================================================
${stripIncludes(REPLAY_CANDLE_RENDERER_MQH)}
${stripIncludes(TRADE_RENDERER_MQH)}
${stripIncludes(REPLAY_RENDERER_MQH)}
${stripIncludes(REPLAY_CHART_MQH)}

//====================================================================
// SECTION 5: SOFT4FX-STYLE MODULAR WORKSPACE PANELS
//====================================================================
${stripIncludes(REPLAY_CONTROL_PANEL_MQH)}
${stripIncludes(TRADING_PANEL_MQH)}
${stripIncludes(ACCOUNT_PANEL_MQH)}
${stripIncludes(POSITIONS_PANEL_MQH)}
${stripIncludes(MAIN_WORKSPACE_MQH)}

//====================================================================
// SECTION 6: GLOBAL INSTANCES, INPUTS & MT5 EVENT HANDLERS
//====================================================================
input group "=== SIMULATION ACCOUNT CONFIGURATION ==="
input double              InpInitialBalance    = 10000.0;           // Virtual Initial Balance ($)
input double              InpLeverage           = 100.0;             // Virtual Leverage (1:X)
input double              InpCommissionLot      = 7.0;               // Commission per Round-Turn Lot ($)

input group "=== SPREAD & SLIPPAGE EXECUTION MODEL ==="
input ENUM_SPREAD_MODEL   InpSpreadModel       = SPREAD_HISTORICAL; // Spread Simulation Model
input double              InpFixedSpreadPts     = 15.0;              // Fixed Spread (if enabled, points)
input ENUM_SLIPPAGE_MODEL InpSlippageModel     = SLIPPAGE_NONE;     // Slippage Simulation Model
input double              InpFixedSlippagePts   = 0.0;               // Fixed Slippage (points)

input group "=== REPLAY ENGINE & DATA SOURCE ==="
input int                 InpStartHistoryBars  = 5000;              // Historical Bars to Cache
input int                 InpInitialBarOffset  = 100;               // Starting Replay Bar Offset
input ENUM_REPLAY_SPEED   InpInitialSpeed      = SPEED_1X;          // Initial Replay Speed
input ENUM_REPLAY_MODE    InpReplayMode        = REPLAY_MODE_CANDLE;// Replay Stepping Mode

//--- System Subsystem Global Instances
CMarketData             ExtMarketData;
CReplayEngine           ExtReplayEngine;
CReplayDataFeed         ExtReplayDataFeed;
CMarketEngine           ExtMarketEngine;
CAccountEngine          ExtAccountEngine;
CPositionManager        ExtPositionManager;
COrderExecutionEngine   ExtExecutionEngine;
COrderManager           ExtOrderManager;
CReplayChart            ExtReplayChart;
CMainWorkspace          ExtMainWorkspace;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("==================================================================");
   Print("  POURI-ESCOBAR-MARKET-REPLAY: Standalone Simulator Initializing... ");
   Print("==================================================================");

   // 1. Detect MT5 Strategy Tester Visual Mode
   bool is_tester = (bool)MQLInfoInteger(MQL_TESTER);
   bool is_visual = (bool)MQLInfoInteger(MQL_VISUAL_MODE);
   PrintFormat("[Mode] Strategy Tester: %s | Visual Mode: %s",
               (is_tester ? "YES" : "NO"), (is_visual ? "YES (Dedicated Replay Active)" : "NO"));

   // 2. Load Historical Rates from MT5
   if (!ExtMarketData.LoadHistoryCount(_Symbol, _Period, InpStartHistoryBars))
   {
      Print("[OnInit] CRITICAL ERROR: Could not load historical rates for symbol ", _Symbol);
      return INIT_FAILED;
   }

   // 3. Initialize Replay Clock & Stepping Engine
   if (!ExtReplayEngine.Initialize(&ExtMarketData, InpInitialBarOffset))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Replay Engine.");
      return INIT_FAILED;
   }
   ExtReplayEngine.SetSpeed(InpInitialSpeed);
   ExtReplayEngine.SetMode(InpReplayMode);

   // 4. Initialize Zero Look-Ahead Replay Data Feed
   if (!ExtReplayDataFeed.Initialize(&ExtMarketData, &ExtReplayEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Replay Data Feed.");
      return INIT_FAILED;
   }

   // 5. Initialize Market Quotes & Spread Engine
   if (!ExtMarketEngine.Initialize(&ExtMarketData, &ExtReplayEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Market Engine.");
      return INIT_FAILED;
   }
   ExtMarketEngine.SetSpreadModel(InpSpreadModel, InpFixedSpreadPts);
   ExtMarketEngine.SetSlippageModel(InpSlippageModel, InpFixedSlippagePts);

   // 6. Initialize Virtual Account
   if (!ExtAccountEngine.Initialize(&ExtMarketData, InpInitialBalance, InpLeverage))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Account Engine.");
      return INIT_FAILED;
   }
   ExtAccountEngine.SetCommissionPerLot(InpCommissionLot);

   // 7. Initialize Virtual Hedging Position Manager
   if (!ExtPositionManager.Initialize(&ExtMarketData, &ExtAccountEngine))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Position Manager.");
      return INIT_FAILED;
   }

   // 8. Initialize Virtual Pending Order Manager
   if (!ExtOrderManager.Initialize(&ExtMarketData, &ExtPositionManager))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Order Manager.");
      return INIT_FAILED;
   }

   // 9. Initialize Execution Engine
   if (!ExtExecutionEngine.Initialize(&ExtMarketData, &ExtMarketEngine, &ExtAccountEngine, &ExtPositionManager))
   {
      Print("[OnInit] CRITICAL ERROR: Could not initialize Execution Engine.");
      return INIT_FAILED;
   }

   // 10. Initialize Dedicated Historical Replay Chart with Canvas Engine
   int chart_w = (int)ChartGetInteger(ChartID(), CHART_WIDTH_IN_PIXELS);
   int chart_h = (int)ChartGetInteger(ChartID(), CHART_HEIGHT_IN_PIXELS);
   if (chart_w <= 0) chart_w = 1100;
   if (chart_h <= 0) chart_h = 700;

   int replay_x = 510;
   int replay_y = 32;
   int replay_w = MathMax(400, chart_w - replay_x - 10);
   int replay_h = MathMax(300, chart_h - replay_y - 20);

   if (!ExtReplayChart.Initialize(ChartID(), &ExtMarketData, &ExtReplayDataFeed, &ExtReplayEngine, &ExtPositionManager, &ExtOrderManager, replay_x, replay_y, replay_w, replay_h))
   {
      Print("[OnInit] Warning: Could not initialize Replay Chart.");
   }

   // 11. Initialize Soft4FX-Style In-Chart Main Workspace
   if (!ExtMainWorkspace.Initialize(ChartID(), &ExtReplayEngine, &ExtMarketEngine, &ExtAccountEngine,
                                    &ExtPositionManager, &ExtExecutionEngine, &ExtOrderManager, &ExtReplayChart))
   {
      Print("[OnInit] Warning: Could not initialize Main Workspace GUI.");
   }

   // 12. Start High-Precision Millisecond Timer
   EventSetMillisecondTimer(SIM_TIMER_INTERVAL_MS);

   PrintFormat("[OnInit] Simulator Ready. Symbol: %s, %s | Bars: %d | Time: %s",
               _Symbol, EnumToString(_Period), ExtMarketData.GetTotalBars(),
               TimeToString(ExtReplayEngine.GetCurrentTime()));
   return INIT_SUCCEEDED;
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   EventKillTimer();
   ExtMainWorkspace.Destroy();
   ExtReplayChart.Cleanup();
   PrintFormat("[OnDeinit] Historical simulator session terminated. Code: %d", reason);
}

//+------------------------------------------------------------------+
//| High-Frequency Millisecond Timer Event Handler                   |
//+------------------------------------------------------------------+
void OnTimer()
{
   ulong cur_ms = GetMicrosecondCount() / 1000;

   // 1. Advance replay step if playing
   ExtReplayEngine.OnTimerTick(cur_ms);

   // 2. Update Simulated Bid/Ask & Spread
   ExtMarketEngine.UpdateQuotes();
   double bid      = ExtMarketEngine.GetBid();
   double ask      = ExtMarketEngine.GetAsk();
   double spread   = ExtMarketEngine.GetSpreadPoints();
   datetime r_time = ExtReplayEngine.GetCurrentTime();

   // 3. Evaluate Virtual Pending Orders (Limit & Stop)
   ExtOrderManager.UpdatePendingOrders(bid, ask, r_time);

   // 4. Update Active Positions & SL/TP Triggers
   ExtPositionManager.UpdatePositions(bid, ask, r_time);

   // 5. Update Virtual Account Equity & Margin
   double fl_pnl = ExtPositionManager.GetTotalFloatingProfit();
   double used_m = ExtPositionManager.GetTotalUsedMargin();
   ExtAccountEngine.UpdateEquityAndMargin(fl_pnl, used_m, ExtPositionManager.GetCount(), ExtOrderManager.GetCount(), r_time);

   // 6. Refresh Dedicated Replay Chart (Canvas candles + live active virtual trades)
   ExtReplayChart.Update(bid, ask, spread);

   // 7. Refresh Soft4FX Simulator Workspace Panels
   ExtMainWorkspace.Update();
}

//+------------------------------------------------------------------+
//| Chart Event Handler (Clicks, Hotkeys, Dynamic Resize)            |
//+------------------------------------------------------------------+
void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
{
   if (id == CHARTEVENT_CHART_CHANGE)
   {
      int chart_w = (int)ChartGetInteger(ChartID(), CHART_WIDTH_IN_PIXELS);
      int chart_h = (int)ChartGetInteger(ChartID(), CHART_HEIGHT_IN_PIXELS);
      int replay_x = 510;
      int replay_y = 32;
      int replay_w = MathMax(400, chart_w - replay_x - 10);
      int replay_h = MathMax(300, chart_h - replay_y - 20);
      ExtReplayChart.Resize(replay_w, replay_h);
   }

   if (ExtMainWorkspace.OnChartEvent(id, lparam, dparam, sparam))
   {
      ExtMarketEngine.UpdateQuotes();
      ExtReplayChart.Update(ExtMarketEngine.GetBid(), ExtMarketEngine.GetAsk(), ExtMarketEngine.GetSpreadPoints());
      ExtMainWorkspace.Update();
   }
}

//+------------------------------------------------------------------+
//| Expert tick function (Strategy Tester Tick Synchronization)      |
//+------------------------------------------------------------------+
void OnTick()
{
   ExtMarketEngine.UpdateQuotes();
   OnTimer();
}
`;

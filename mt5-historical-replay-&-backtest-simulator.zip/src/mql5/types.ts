export interface MqlFile {
  path: string;
  name: string;
  category: 'Core' | 'Trading' | 'Analytics' | 'Journal' | 'UI' | 'Chart' | 'Expert' | 'Documentation';
  code: string;
  description: string;
}

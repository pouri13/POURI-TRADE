import { ClosedTrade, AdvancedStatistics } from '../types/simulator';

export function calculateStatistics(
  trades: ClosedTrade[],
  initialBalance: number = 10000
): AdvancedStatistics {
  if (trades.length === 0) {
    return {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      breakevenTrades: 0,
      winRate: 0,
      lossRate: 0,
      grossProfit: 0,
      grossLoss: 0,
      netProfit: 0,
      profitFactor: 0,
      expectancy: 0,
      averageR: 0,
      medianR: 0,
      averageWin: 0,
      averageLoss: 0,
      winLossRatio: 0,
      largestWin: 0,
      largestLoss: 0,
      maxConsecutiveWins: 0,
      maxConsecutiveLosses: 0,
      maxDrawdown: 0,
      maxDrawdownPercent: 0,
      recoveryFactor: 0,
      sharpeRatio: 0,
      sortinoRatio: 0,
      calmarRatio: 0,
      sqn: 0,
      averageHoldingTimeMinutes: 0,
      bestDay: 'N/A',
      worstDay: 'N/A',
      bestSession: 'N/A',
      worstSession: 'N/A',
    };
  }

  let grossProfit = 0;
  let grossLoss = 0;
  let winningTrades = 0;
  let losingTrades = 0;
  let breakevenTrades = 0;
  let largestWin = 0;
  let largestLoss = 0;

  let currentConsecWins = 0;
  let maxConsecWins = 0;
  let currentConsecLosses = 0;
  let maxConsecLosses = 0;

  const rMultiples: number[] = [];
  const returns: number[] = [];
  let totalHoldingSeconds = 0;

  const dayProfits: Record<string, number> = {};
  const sessionProfits: Record<string, number> = {};

  trades.forEach((t) => {
    const pnl = t.netProfit;
    returns.push(pnl);
    rMultiples.push(t.rMultiple || (t.riskAmount > 0 ? pnl / t.riskAmount : 0));
    totalHoldingSeconds += t.holdingTimeSeconds || 60;

    const date = new Date(t.closeTime * 1000);
    const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
    dayProfits[dayName] = (dayProfits[dayName] || 0) + pnl;

    const hour = date.getUTCHours();
    let session = 'Asian';
    if (hour >= 8 && hour < 13) session = 'London';
    else if (hour >= 13 && hour < 17) session = 'Overlap (LDN/NY)';
    else if (hour >= 17 && hour < 21) session = 'New York';
    else if (hour >= 21 || hour < 0) session = 'Sydney';
    sessionProfits[session] = (sessionProfits[session] || 0) + pnl;

    if (pnl > 0.001) {
      winningTrades++;
      grossProfit += pnl;
      largestWin = Math.max(largestWin, pnl);
      currentConsecWins++;
      currentConsecLosses = 0;
      maxConsecWins = Math.max(maxConsecWins, currentConsecWins);
    } else if (pnl < -0.001) {
      losingTrades++;
      grossLoss += Math.abs(pnl);
      largestLoss = Math.min(largestLoss, pnl);
      currentConsecLosses++;
      currentConsecWins = 0;
      maxConsecLosses = Math.max(maxConsecLosses, currentConsecLosses);
    } else {
      breakevenTrades++;
      currentConsecWins = 0;
      currentConsecLosses = 0;
    }
  });

  const totalTrades = trades.length;
  const netProfit = grossProfit - grossLoss;
  const winRate = Number(((winningTrades / totalTrades) * 100).toFixed(1));
  const lossRate = Number(((losingTrades / totalTrades) * 100).toFixed(1));
  const profitFactor = grossLoss > 0 ? Number((grossProfit / grossLoss).toFixed(2)) : (grossProfit > 0 ? 99.9 : 0);

  const averageWin = winningTrades > 0 ? Number((grossProfit / winningTrades).toFixed(2)) : 0;
  const averageLoss = losingTrades > 0 ? Number((grossLoss / losingTrades).toFixed(2)) : 0;
  const winLossRatio = averageLoss > 0 ? Number((averageWin / averageLoss).toFixed(2)) : 0;

  // Expectancy formula: (WinRate * AvgWin) - (LossRate * AvgLoss) in $
  const winProb = winningTrades / totalTrades;
  const lossProb = losingTrades / totalTrades;
  const expectancy = Number(((winProb * averageWin) - (lossProb * averageLoss)).toFixed(2));

  // R statistics
  const sumR = rMultiples.reduce((a, b) => a + b, 0);
  const averageR = Number((sumR / totalTrades).toFixed(2));

  const sortedR = [...rMultiples].sort((a, b) => a - b);
  const medianR = sortedR.length % 2 === 0
    ? Number(((sortedR[sortedR.length / 2 - 1] + sortedR[sortedR.length / 2]) / 2).toFixed(2))
    : Number(sortedR[Math.floor(sortedR.length / 2)].toFixed(2));

  // Max Drawdown tracking
  let peak = initialBalance;
  let maxDD = 0;
  let maxDDPct = 0;
  let runningBalance = initialBalance;

  trades.forEach((t) => {
    runningBalance += t.netProfit;
    if (runningBalance > peak) {
      peak = runningBalance;
    }
    const currentDD = peak - runningBalance;
    const currentDDPct = peak > 0 ? (currentDD / peak) * 100 : 0;
    if (currentDD > maxDD) maxDD = currentDD;
    if (currentDDPct > maxDDPct) maxDDPct = currentDDPct;
  });

  const recoveryFactor = maxDD > 0 ? Number((netProfit / maxDD).toFixed(2)) : (netProfit > 0 ? 10 : 0);

  // Standard deviation of R for SQN
  const varianceR = rMultiples.reduce((acc, val) => acc + Math.pow(val - averageR, 2), 0) / totalTrades;
  const stdDevR = Math.sqrt(varianceR);
  // Van Tharp SQN = sqrt(N) * (Mean(R) / StdDev(R))
  const sqn = stdDevR > 0 ? Number((Math.sqrt(totalTrades) * (averageR / stdDevR)).toFixed(2)) : 0;

  // Sharpe & Sortino
  const meanReturn = netProfit / totalTrades;
  const returnVariance = returns.reduce((acc, val) => acc + Math.pow(val - meanReturn, 2), 0) / totalTrades;
  const returnStdDev = Math.sqrt(returnVariance);

  const downsideVariance = returns.filter(r => r < 0).reduce((acc, val) => acc + Math.pow(val, 2), 0) / totalTrades;
  const downsideStdDev = Math.sqrt(downsideVariance);

  // Annualized approximate multiplier (assuming ~252 trading days)
  const annualFactor = Math.sqrt(Math.min(252, Math.max(12, totalTrades)));
  const sharpeRatio = returnStdDev > 0 ? Number(((meanReturn / returnStdDev) * annualFactor).toFixed(2)) : 0;
  const sortinoRatio = downsideStdDev > 0 ? Number(((meanReturn / downsideStdDev) * annualFactor).toFixed(2)) : 0;
  const calmarRatio = maxDDPct > 0 ? Number(((netProfit / initialBalance * 100) / maxDDPct).toFixed(2)) : 0;

  const averageHoldingTimeMinutes = Number(((totalHoldingSeconds / totalTrades) / 60).toFixed(1));

  // Best/worst day
  let bestDay = 'N/A';
  let worstDay = 'N/A';
  let bestDayProfit = -Infinity;
  let worstDayProfit = Infinity;
  for (const [day, prof] of Object.entries(dayProfits)) {
    if (prof > bestDayProfit) {
      bestDayProfit = prof;
      bestDay = `${day} (+$${prof.toFixed(0)})`;
    }
    if (prof < worstDayProfit) {
      worstDayProfit = prof;
      worstDay = `${day} (-$${Math.abs(prof).toFixed(0)})`;
    }
  }

  // Best/worst session
  let bestSession = 'N/A';
  let worstSession = 'N/A';
  let bestSessProfit = -Infinity;
  let worstSessProfit = Infinity;
  for (const [sess, prof] of Object.entries(sessionProfits)) {
    if (prof > bestSessProfit) {
      bestSessProfit = prof;
      bestSession = `${sess} (+$${prof.toFixed(0)})`;
    }
    if (prof < worstSessProfit) {
      worstSessProfit = prof;
      worstSession = `${sess} (-$${Math.abs(prof).toFixed(0)})`;
    }
  }

  return {
    totalTrades,
    winningTrades,
    losingTrades,
    breakevenTrades,
    winRate,
    lossRate,
    grossProfit: Number(grossProfit.toFixed(2)),
    grossLoss: Number(grossLoss.toFixed(2)),
    netProfit: Number(netProfit.toFixed(2)),
    profitFactor,
    expectancy,
    averageR,
    medianR,
    averageWin,
    averageLoss,
    winLossRatio,
    largestWin: Number(largestWin.toFixed(2)),
    largestLoss: Number(largestLoss.toFixed(2)),
    maxConsecutiveWins: maxConsecWins,
    maxConsecutiveLosses: maxConsecLosses,
    maxDrawdown: Number(maxDD.toFixed(2)),
    maxDrawdownPercent: Number(maxDDPct.toFixed(1)),
    recoveryFactor,
    sharpeRatio,
    sortinoRatio,
    calmarRatio,
    sqn,
    averageHoldingTimeMinutes,
    bestDay,
    worstDay,
    bestSession,
    worstSession,
  };
}

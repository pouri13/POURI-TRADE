import { SymbolSpec } from '../types/simulator';

export interface RiskCalculationResult {
  recommendedLot: number;
  maxLossAmount: number;
  potentialProfitAmount: number;
  riskRewardRatio: number;
  slDistancePoints: number;
  tpDistancePoints: number;
  slDistancePips: number;
  tpDistancePips: number;
}

/**
 * Robust position sizing calculator using exact MT5 symbol specification metrics.
 * 
 * In MT5:
 * Point = 10^(-digits)
 * Pip = Forex: 10 points (5-digit / 3-digit broker)
 * One tick monetary change per lot = (TickValue / TickSize) * Point
 */
export function calculateRiskAndLots(
  accountBalance: number,
  riskPercent: number,
  entryPrice: number,
  slPrice: number,
  tpPrice: number,
  isBuy: boolean,
  spec: SymbolSpec
): RiskCalculationResult {
  const riskAmount = (accountBalance * Math.max(0.01, riskPercent)) / 100;
  const slDistancePrice = Math.abs(entryPrice - slPrice);
  const tpDistancePrice = Math.abs(tpPrice - entryPrice);

  const slDistancePoints = Math.round(slDistancePrice / spec.point);
  const tpDistancePoints = Math.round(tpDistancePrice / spec.point);

  // For 5-digit/3-digit brokers, 1 pip = 10 points. For 2-digit XAUUSD, 1 point = 0.01 USD (1 pip = 10 points = $0.10)
  const pipsDivider = spec.digits === 3 || spec.digits === 5 ? 10 : (spec.digits === 2 ? 10 : 1);
  const slDistancePips = Number((slDistancePoints / pipsDivider).toFixed(1));
  const tpDistancePips = Number((tpDistancePoints / pipsDivider).toFixed(1));

  // Monitary value per point per 1.00 lot:
  // For Forex: 100,000 * 0.00001 = $1 per point
  // For XAUUSD: 100 * 0.01 = $1 per point
  // For US30: 1 * 0.1 = $0.10 per point
  const valuePerPointPerLot = (spec.contractSize * spec.point);

  let rawLot = 0.01;
  if (slDistancePoints > 0 && valuePerPointPerLot > 0) {
    rawLot = riskAmount / (slDistancePoints * valuePerPointPerLot);
  }

  // Quantize according to lotStep, minLot, maxLot
  const steppedLot = Math.floor(rawLot / spec.lotStep) * spec.lotStep;
  const recommendedLot = Math.min(spec.maxLot, Math.max(spec.minLot, Number(steppedLot.toFixed(2))));

  const actualLoss = recommendedLot * slDistancePoints * valuePerPointPerLot;
  const actualProfit = tpPrice > 0 ? (recommendedLot * tpDistancePoints * valuePerPointPerLot) : 0;
  const rr = actualLoss > 0 && actualProfit > 0 ? Number((actualProfit / actualLoss).toFixed(2)) : 0;

  return {
    recommendedLot,
    maxLossAmount: Number(actualLoss.toFixed(2)),
    potentialProfitAmount: Number(actualProfit.toFixed(2)),
    riskRewardRatio: rr,
    slDistancePoints,
    tpDistancePoints,
    slDistancePips,
    tpDistancePips,
  };
}

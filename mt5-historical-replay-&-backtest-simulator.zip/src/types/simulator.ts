export type SymbolName = 'XAUUSD' | 'EURUSD' | 'GBPUSD' | 'USDJPY' | 'US30' | 'BTCUSD';

export type Timeframe = 'M1' | 'M5' | 'M15' | 'H1' | 'H4' | 'D1';

export type ReplaySpeed = 0.25 | 0.5 | 1 | 2 | 5 | 10 | 25 | 50 | 100;

export type OrderDirection = 'BUY' | 'SELL';

export type OrderType = 
  | 'MARKET_BUY'
  | 'MARKET_SELL'
  | 'BUY_LIMIT'
  | 'SELL_LIMIT'
  | 'BUY_STOP'
  | 'SELL_STOP';

export type PositionStatus = 'OPEN' | 'CLOSED';

export type PendingOrderStatus = 'PLACED' | 'TRIGGERED' | 'CANCELLED';

export type AccountType = 'HEDGING' | 'NETTING';

export type SpreadModel = 'FIXED' | 'HISTORICAL' | 'RANDOM_RANGE' | 'SCHEDULED';

export type SlippageModel = 'DISABLED' | 'FIXED' | 'RANDOM' | 'PERCENTAGE';

export type EmotionTag = 'CALM' | 'FEAR' | 'GREED' | 'FOMO' | 'REVENGE' | 'BOREDOM' | 'CONFIDENT';

export type StrategyTag = 'BREAKOUT' | 'PULLBACK' | 'REVERSAL' | 'SCALP' | 'SWING' | 'NEWS' | 'A+' | 'B' | 'C';

export interface SymbolSpec {
  symbol: SymbolName;
  description: string;
  digits: number;
  point: number;
  contractSize: number;
  tickSize: number;
  tickValue: number;
  minLot: number;
  maxLot: number;
  lotStep: number;
  typicalSpreadPoints: number;
  swapLong: number;
  swapShort: number;
  marginRate: number; // e.g., 1 / leverage
}

export interface Candle {
  time: number; // timestamp in seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  spread?: number;
}

export interface Tick {
  time: number; // timestamp in seconds or ms
  bid: number;
  ask: number;
  last?: number;
  volume?: number;
}

export interface OrderInput {
  symbol: SymbolName;
  type: OrderType;
  lots: number;
  price?: number; // for pending orders
  sl?: number;
  tp?: number;
  comment?: string;
  magicNumber?: number;
  riskPercent?: number;
  strategy?: StrategyTag;
}

export interface Position {
  id: number;
  ticket: number;
  symbol: SymbolName;
  direction: OrderDirection;
  lots: number;
  openPrice: number;
  openTime: number;
  sl: number;
  tp: number;
  currentPrice: number;
  profit: number; // floating gross profit in USD
  pips: number;
  commission: number;
  swap: number;
  netProfit: number;
  comment: string;
  magicNumber: number;
  strategy?: StrategyTag;
  maxFavorablePips: number;
  maxAdversePips: number;
}

export interface PendingOrder {
  id: number;
  ticket: number;
  symbol: SymbolName;
  type: OrderType;
  direction: OrderDirection;
  targetPrice: number;
  lots: number;
  sl: number;
  tp: number;
  comment: string;
  magicNumber: number;
  placedTime: number;
  status: PendingOrderStatus;
  strategy?: StrategyTag;
}

export interface ClosedTrade {
  tradeId: number;
  positionId: number;
  ticket: number;
  symbol: SymbolName;
  direction: OrderDirection;
  lots: number;
  openPrice: number;
  openTime: number;
  closePrice: number;
  closeTime: number;
  sl: number;
  tp: number;
  commission: number;
  swap: number;
  grossProfit: number;
  netProfit: number;
  pips: number;
  riskAmount: number;
  rewardAmount: number;
  rMultiple: number;
  holdingTimeSeconds: number;
  comment: string;
  magicNumber: number;
  strategy?: StrategyTag;
  emotion?: EmotionTag;
  confidence?: number; // 1-5
  followedRules?: boolean;
  notes?: string;
  maePips?: number;
  mfePips?: number;
  entryScreenshot?: string;
  exitScreenshot?: string;
}

export interface AccountState {
  initialBalance: number;
  balance: number;
  equity: number;
  usedMargin: number;
  freeMargin: number;
  marginLevel: number; // in %
  leverage: number;
  currency: string;
  accountType: AccountType;
  floatingProfit: number;
  realizedProfit: number;
  totalCommission: number;
  totalSwap: number;
}

export interface SimulationSettings {
  initialBalance: number;
  leverage: number;
  accountCurrency: string;
  spreadModel: SpreadModel;
  fixedSpreadPoints: number;
  slippageModel: SlippageModel;
  fixedSlippagePoints: number;
  commissionPerLot: number; // in USD round-turn
  swapEnabled: boolean;
  executionDelayMs: number;
  safeMode: boolean; // strictly prevents real execution
  challengeMode: boolean;
  challengeTargetProfit: number;
  challengeMaxDrawdownPercent: number;
  challengeDailyLossPercent: number;
}

export interface EconomicNewsEvent {
  id: string;
  time: number;
  currency: string;
  impact: 'LOW' | 'MEDIUM' | 'HIGH';
  event: string;
  forecast?: string;
  previous?: string;
  actual?: string;
}

export interface SessionInfo {
  name: 'Sydney' | 'Tokyo' | 'London' | 'New York';
  startHourUtc: number;
  endHourUtc: number;
  color: string;
}

export interface AdvancedStatistics {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  breakevenTrades: number;
  winRate: number; // in %
  lossRate: number; // in %
  grossProfit: number;
  grossLoss: number;
  netProfit: number;
  profitFactor: number;
  expectancy: number; // in $ per trade
  averageR: number;
  medianR: number;
  averageWin: number;
  averageLoss: number;
  winLossRatio: number;
  largestWin: number;
  largestLoss: number;
  maxConsecutiveWins: number;
  maxConsecutiveLosses: number;
  maxDrawdown: number;
  maxDrawdownPercent: number;
  recoveryFactor: number;
  sharpeRatio: number;
  sortinoRatio: number;
  calmarRatio: number;
  sqn: number; // System Quality Number (Van Tharp)
  averageHoldingTimeMinutes: number;
  bestDay: string;
  worstDay: string;
  bestSession: string;
  worstSession: string;
}

export interface DailyHeatmapCell {
  dateStr: string;
  tradesCount: number;
  netProfit: number;
  winRate: number;
}

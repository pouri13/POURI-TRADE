import { SymbolName, SymbolSpec, SessionInfo, EconomicNewsEvent, Candle } from '../types/simulator';

export const SYMBOL_SPECS: Record<SymbolName, SymbolSpec> = {
  XAUUSD: {
    symbol: 'XAUUSD',
    description: 'Gold vs US Dollar (Troy Ounce)',
    digits: 2,
    point: 0.01,
    contractSize: 100, // 100 oz per standard lot
    tickSize: 0.01,
    tickValue: 1.00, // 100 * 0.01 = $1.00 per tick for 1.00 lot
    minLot: 0.01,
    maxLot: 50.0,
    lotStep: 0.01,
    typicalSpreadPoints: 15, // 15 points = 0.15 USD spread
    swapLong: -3.5,
    swapShort: 1.2,
    marginRate: 0.01, // 1:100 leverage
  },
  EURUSD: {
    symbol: 'EURUSD',
    description: 'Euro vs US Dollar',
    digits: 5,
    point: 0.00001,
    contractSize: 100000, // 100,000 EUR
    tickSize: 0.00001,
    tickValue: 1.00, // $1 per point for 1.00 lot (or $10 per pip)
    minLot: 0.01,
    maxLot: 100.0,
    lotStep: 0.01,
    typicalSpreadPoints: 8, // 0.8 pips
    swapLong: -4.2,
    swapShort: 0.8,
    marginRate: 0.01,
  },
  GBPUSD: {
    symbol: 'GBPUSD',
    description: 'Great British Pound vs US Dollar',
    digits: 5,
    point: 0.00001,
    contractSize: 100000,
    tickSize: 0.00001,
    tickValue: 1.00,
    minLot: 0.01,
    maxLot: 100.0,
    lotStep: 0.01,
    typicalSpreadPoints: 12, // 1.2 pips
    swapLong: -2.8,
    swapShort: -0.5,
    marginRate: 0.01,
  },
  USDJPY: {
    symbol: 'USDJPY',
    description: 'US Dollar vs Japanese Yen',
    digits: 3,
    point: 0.001,
    contractSize: 100000,
    tickSize: 0.001,
    tickValue: 0.68,
    minLot: 0.01,
    maxLot: 100.0,
    lotStep: 0.01,
    typicalSpreadPoints: 10,
    swapLong: 5.2,
    swapShort: -9.8,
    marginRate: 0.01,
  },
  US30: {
    symbol: 'US30',
    description: 'Dow Jones Industrial Average CFD',
    digits: 1,
    point: 0.1,
    contractSize: 1, // 1 index unit
    tickSize: 0.1,
    tickValue: 0.1, // $1 per full point
    minLot: 0.1,
    maxLot: 50.0,
    lotStep: 0.1,
    typicalSpreadPoints: 25,
    swapLong: -5.0,
    swapShort: -3.0,
    marginRate: 0.02, // 1:50 leverage
  },
  BTCUSD: {
    symbol: 'BTCUSD',
    description: 'Bitcoin vs US Dollar',
    digits: 2,
    point: 0.01,
    contractSize: 1,
    tickSize: 0.01,
    tickValue: 0.01,
    minLot: 0.01,
    maxLot: 10.0,
    lotStep: 0.01,
    typicalSpreadPoints: 180, // $1.80 spread
    swapLong: -12.0,
    swapShort: -8.0,
    marginRate: 0.05, // 1:20 leverage
  },
};

export const SESSIONS: SessionInfo[] = [
  { name: 'Sydney', startHourUtc: 21, endHourUtc: 6, color: '#38bdf8' },
  { name: 'Tokyo', startHourUtc: 0, endHourUtc: 9, color: '#a855f7' },
  { name: 'London', startHourUtc: 8, endHourUtc: 16, color: '#22c55e' },
  { name: 'New York', startHourUtc: 13, endHourUtc: 21, color: '#f59e0b' },
];

export const SAMPLE_NEWS_EVENTS: EconomicNewsEvent[] = [
  { id: 'n1', time: 1713357000, currency: 'USD', impact: 'HIGH', event: 'US Core CPI (MoM)', forecast: '0.3%', previous: '0.4%', actual: '0.2%' },
  { id: 'n2', time: 1713441600, currency: 'USD', impact: 'HIGH', event: 'Fed Interest Rate Decision', forecast: '5.25%', previous: '5.25%', actual: '5.25%' },
  { id: 'n3', time: 1713528000, currency: 'USD', impact: 'HIGH', event: 'Non-Farm Payrolls (NFP)', forecast: '185K', previous: '275K', actual: '175K' },
  { id: 'n4', time: 1713787200, currency: 'GBP', impact: 'MEDIUM', event: 'UK Retail Sales (MoM)', forecast: '0.2%', previous: '0.0%', actual: '0.5%' },
  { id: 'n5', time: 1713873600, currency: 'EUR', impact: 'HIGH', event: 'ECB Monetary Policy Statement', forecast: '4.00%', previous: '4.00%', actual: '4.00%' },
];

/**
 * Generate synthetic realistic market dataset with trend, volatility, and mean-reversion
 */
export function generateMarketCandles(
  symbol: SymbolName,
  count: number = 300,
  startPrice?: number,
  baseTime: number = 1713340800 // Apr 17, 2024 08:00 UTC
): Candle[] {
  const spec = SYMBOL_SPECS[symbol];
  let price = startPrice ?? (
    symbol === 'XAUUSD' ? 2382.50 :
    symbol === 'EURUSD' ? 1.06500 :
    symbol === 'GBPUSD' ? 1.24800 :
    symbol === 'USDJPY' ? 154.200 :
    symbol === 'US30' ? 38240.0 :
    64800.00
  );

  const candles: Candle[] = [];
  let currentTime = baseTime;
  const timeframeSeconds = 300; // 5-minute candles

  let trend = 0.0001;
  const volatility = symbol === 'XAUUSD' ? 0.6 :
    symbol === 'EURUSD' ? 0.0002 :
    symbol === 'GBPUSD' ? 0.0003 :
    symbol === 'USDJPY' ? 0.04 :
    symbol === 'US30' ? 12.0 :
    45.0;

  for (let i = 0; i < count; i++) {
    // Weekend skip: if Saturday or Sunday, skip to Monday 00:00
    const date = new Date(currentTime * 1000);
    const dayOfWeek = date.getUTCDay();
    if (dayOfWeek === 6) { // Saturday
      currentTime += 86400 * 2;
    }

    // Regime shift every 40-60 candles
    if (i % 45 === 0) {
      trend = (Math.random() - 0.48) * (volatility * 0.4);
    }

    const candleDrift = trend + (Math.random() - 0.5) * volatility;
    const open = Number(price.toFixed(spec.digits));
    const close = Number(Math.max(open * 0.5, open + candleDrift).toFixed(spec.digits));
    
    // Wicks
    const wickHigh = Math.random() * volatility * 0.8;
    const wickLow = Math.random() * volatility * 0.8;
    const high = Number(Math.max(open, close, open + wickHigh, close + wickHigh).toFixed(spec.digits));
    const low = Number(Math.min(open, close, open - wickLow, close - wickLow).toFixed(spec.digits));
    
    const volume = Math.floor(120 + Math.random() * 450);

    candles.push({
      time: currentTime,
      open,
      high,
      low,
      close,
      volume,
      spread: spec.typicalSpreadPoints,
    });

    price = close;
    currentTime += timeframeSeconds;
  }

  return candles;
}

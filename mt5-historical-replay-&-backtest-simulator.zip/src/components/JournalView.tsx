import React, { useState } from 'react';
import { ClosedTrade, EmotionTag, StrategyTag } from '../types/simulator';
import { Download, Search, Filter, BookOpen, Star, CheckCircle, AlertTriangle } from 'lucide-react';

interface JournalViewProps {
  trades: ClosedTrade[];
  onUpdateTradeReview: (tradeId: number, emotion: EmotionTag, confidence: number, followedRules: boolean, notes: string) => void;
  onExportJSON: () => void;
  onExportCSV: () => void;
}

export const JournalView: React.FC<JournalViewProps> = ({
  trades,
  onUpdateTradeReview,
  onExportJSON,
  onExportCSV,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStrategy, setFilterStrategy] = useState<string>('ALL');
  const [selectedTrade, setSelectedTrade] = useState<ClosedTrade | null>(null);

  // Modal edit fields
  const [reviewEmotion, setReviewEmotion] = useState<EmotionTag>('CALM');
  const [reviewConfidence, setReviewConfidence] = useState<number>(4);
  const [reviewFollowed, setReviewFollowed] = useState<boolean>(true);
  const [reviewNotes, setReviewNotes] = useState<string>('');

  const openReviewModal = (t: ClosedTrade) => {
    setSelectedTrade(t);
    setReviewEmotion(t.emotion || 'CALM');
    setReviewConfidence(t.confidence || 4);
    setReviewFollowed(t.followedRules ?? true);
    setReviewNotes(t.notes || '');
  };

  const handleSaveReview = () => {
    if (selectedTrade) {
      onUpdateTradeReview(
        selectedTrade.tradeId,
        reviewEmotion,
        reviewConfidence,
        reviewFollowed,
        reviewNotes
      );
      setSelectedTrade(null);
    }
  };

  const filteredTrades = trades.filter((t) => {
    const matchesSearch =
      t.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.comment && t.comment.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (t.notes && t.notes.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStrategy = filterStrategy === 'ALL' || t.strategy === filterStrategy;
    return matchesSearch && matchesStrategy;
  });

  return (
    <div id="journal-view-container" className="w-full h-full flex flex-col bg-[#10141f] text-xs font-sans select-none">
      {/* Journal Controls Toolbar */}
      <div className="p-3 bg-[#141926] border-b border-[#242e44] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2 flex-1 max-w-md">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search by symbol, comment, or notes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#0c0f17] border border-[#27324b] rounded pl-8 pr-3 py-1.5 text-slate-200 text-xs focus:border-blue-500 outline-none"
            />
          </div>

          <div className="flex items-center space-x-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={filterStrategy}
              onChange={(e) => setFilterStrategy(e.target.value)}
              className="bg-[#0c0f17] border border-[#27324b] rounded px-2 py-1.5 text-slate-200 text-xs outline-none"
            >
              <option value="ALL">All Strategies</option>
              <option value="BREAKOUT">BREAKOUT</option>
              <option value="PULLBACK">PULLBACK</option>
              <option value="REVERSAL">REVERSAL</option>
              <option value="SCALP">SCALP</option>
              <option value="SWING">SWING</option>
              <option value="A+">Grade A+</option>
            </select>
          </div>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center space-x-2">
          <button
            id="btn-export-csv"
            onClick={onExportCSV}
            className="flex items-center space-x-1 px-3 py-1.5 rounded bg-[#1e273b] hover:bg-[#28344e] text-slate-200 text-xs font-medium border border-slate-700 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            id="btn-export-json"
            onClick={onExportJSON}
            className="flex items-center space-x-1 px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export JSON (AI-Ready)</span>
          </button>
        </div>
      </div>

      {/* Trades Table */}
      <div className="flex-1 overflow-auto">
        {filteredTrades.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-2 p-6 text-center">
            <BookOpen className="w-8 h-8 text-slate-400" />
            <p className="font-medium text-slate-300">No closed trades recorded yet</p>
            <p className="text-xs text-slate-400 max-w-sm">
              Trades will automatically generate journal records once closed via market order, SL, or TP.
            </p>
          </div>
        ) : (
          <table className="w-full text-left border-collapse font-mono text-[11px]">
            <thead>
              <tr className="border-b border-[#20293d] text-slate-400 bg-[#121724]">
                <th className="py-2.5 px-3">ID</th>
                <th className="py-2.5 px-2">Symbol</th>
                <th className="py-2.5 px-2">Type</th>
                <th className="py-2.5 px-2">Lots</th>
                <th className="py-2.5 px-2">Entry Time</th>
                <th className="py-2.5 px-2">Exit Time</th>
                <th className="py-2.5 px-2">Duration</th>
                <th className="py-2.5 px-2">Entry Price</th>
                <th className="py-2.5 px-2">Exit Price</th>
                <th className="py-2.5 px-2">Pips</th>
                <th className="py-2.5 px-2">Net P/L ($)</th>
                <th className="py-2.5 px-2">R:R</th>
                <th className="py-2.5 px-2">Setup</th>
                <th className="py-2.5 px-2">Emotion</th>
                <th className="py-2.5 px-3 text-right">Review</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1b2336]">
              {filteredTrades.map((t) => {
                const isBuy = t.direction === 'BUY';
                const isProfit = t.netProfit >= 0;
                const durationMinutes = Math.round((t.holdingTimeSeconds || 60) / 60);

                return (
                  <tr key={t.tradeId} className="hover:bg-[#161c2b] transition">
                    <td className="py-2 px-3 text-slate-400">#{t.tradeId}</td>
                    <td className="py-2 px-2 font-bold text-slate-200">{t.symbol}</td>
                    <td className="py-2 px-2">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          isBuy ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                        }`}
                      >
                        {t.direction}
                      </span>
                    </td>
                    <td className="py-2 px-2 text-slate-300">{t.lots.toFixed(2)}</td>
                    <td className="py-2 px-2 text-slate-400">
                      {new Date(t.openTime * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                    </td>
                    <td className="py-2 px-2 text-slate-400">
                      {new Date(t.closeTime * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                    </td>
                    <td className="py-2 px-2 text-slate-400">{durationMinutes}m</td>
                    <td className="py-2 px-2 text-slate-300">{t.openPrice.toFixed(2)}</td>
                    <td className="py-2 px-2 text-slate-300">{t.closePrice.toFixed(2)}</td>
                    <td className={`py-2 px-2 font-bold ${isProfit ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {t.pips >= 0 ? '+' : ''}{t.pips.toFixed(1)}
                    </td>
                    <td className={`py-2 px-2 font-bold ${isProfit ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {isProfit ? '+' : ''}${t.netProfit.toFixed(2)}
                    </td>
                    <td className="py-2 px-2 text-blue-400 font-bold">
                      {t.rMultiple ? `${t.rMultiple.toFixed(2)}R` : '---'}
                    </td>
                    <td className="py-2 px-2">
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                        {t.strategy || 'MANUAL'}
                      </span>
                    </td>
                    <td className="py-2 px-2">
                      <span className="text-[10px] text-amber-300 font-sans">
                        {t.emotion || 'CALM'}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right font-sans">
                      <button
                        onClick={() => openReviewModal(t)}
                        className="px-2 py-1 rounded bg-[#1e2638] hover:bg-[#28334a] text-blue-300 text-[10px] transition"
                      >
                        Reflect
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Trade Review Modal */}
      {selectedTrade && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div className="bg-[#141926] border border-[#27324b] rounded-lg max-w-lg w-full p-5 space-y-4 shadow-2xl text-slate-200">
            <div className="flex items-center justify-between border-b border-[#242e44] pb-3">
              <h3 className="text-sm font-bold flex items-center space-x-2">
                <BookOpen className="w-4 h-4 text-blue-400" />
                <span>Trade #{selectedTrade.tradeId} Psychology & Review</span>
              </h3>
              <span className={`font-mono font-bold text-xs ${selectedTrade.netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {selectedTrade.netProfit >= 0 ? '+' : ''}${selectedTrade.netProfit.toFixed(2)}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Emotion during execution</label>
                <select
                  value={reviewEmotion}
                  onChange={(e) => setReviewEmotion(e.target.value as EmotionTag)}
                  className="w-full bg-[#0c0f17] border border-[#27324b] rounded p-2 text-slate-200 text-xs"
                >
                  <option value="CALM">Calm / Objective</option>
                  <option value="CONFIDENT">Confident (A+ Setup)</option>
                  <option value="FEAR">Fear of Loss</option>
                  <option value="GREED">Greed / Overleveraged</option>
                  <option value="FOMO">FOMO / Chasing</option>
                  <option value="REVENGE">Revenge Trading</option>
                  <option value="BOREDOM">Boredom Trade</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Confidence Rating (1 - 5)</label>
                <div className="flex items-center space-x-1 pt-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setReviewConfidence(star)}
                      className="p-1 text-slate-400 hover:text-amber-400"
                    >
                      <Star
                        className={`w-4 h-4 ${
                          star <= reviewConfidence ? 'text-amber-400 fill-amber-400' : 'text-slate-400'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="flex items-center space-x-2 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={reviewFollowed}
                  onChange={(e) => setReviewFollowed(e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 text-blue-500"
                />
                <span className="text-slate-300">Did I strictly adhere to my predefined trading plan?</span>
              </label>
            </div>

            <div>
              <label className="text-slate-400 block mb-1 text-xs">Post-Trade Reflection Notes</label>
              <textarea
                rows={3}
                placeholder="Why did I enter? Did the market sweep liquidity? What could be improved?"
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                className="w-full bg-[#0c0f17] border border-[#27324b] rounded p-2 text-slate-200 text-xs outline-none focus:border-blue-500"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2 border-t border-[#242e44]">
              <button
                onClick={() => setSelectedTrade(null)}
                className="px-3 py-1.5 rounded bg-[#1e2638] hover:bg-[#27324a] text-slate-300 text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveReview}
                className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs shadow"
              >
                Save Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { AdvancedStatistics, ClosedTrade } from '../types/simulator';
import { TrendingUp, ShieldAlert, Award, Activity, BarChart2 } from 'lucide-react';

interface StatsDashboardProps {
  stats: AdvancedStatistics;
  trades: ClosedTrade[];
  initialBalance: number;
}

export const StatsDashboard: React.FC<StatsDashboardProps> = ({
  stats,
  trades,
  initialBalance,
}) => {
  // Build Equity Points for Curve
  const equityPoints: number[] = [initialBalance];
  let curBal = initialBalance;
  trades.forEach((t) => {
    curBal += t.netProfit;
    equityPoints.push(curBal);
  });

  const minEq = Math.min(...equityPoints);
  const maxEq = Math.max(...equityPoints);
  const range = maxEq - minEq || 1;

  // Build SVG Path
  const svgWidth = 600;
  const svgHeight = 160;
  const padding = 15;

  const pointsString = equityPoints
    .map((val, idx) => {
      const x = padding + (idx / Math.max(1, equityPoints.length - 1)) * (svgWidth - padding * 2);
      const y = svgHeight - padding - ((val - minEq) / range) * (svgHeight - padding * 2);
      return `${x},${y}`;
    })
    .join(' ');

  return (
    <div id="stats-dashboard-container" className="w-full h-full overflow-y-auto bg-[#10141f] p-4 text-xs font-sans text-slate-200 space-y-4 select-none">
      {/* Top Highlights Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* Card 1: Net Profit */}
        <div className="bg-[#141926] border border-[#242e44] p-3 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold">Net Profit</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className={`text-xl font-bold font-mono ${stats.netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {stats.netProfit >= 0 ? '+' : ''}${stats.netProfit.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Profit Factor: <span className="text-slate-200 font-mono font-bold">{stats.profitFactor}</span>
          </div>
        </div>

        {/* Card 2: Win Rate & Trades */}
        <div className="bg-[#141926] border border-[#242e44] p-3 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold">Win Rate</span>
            <Award className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl font-bold font-mono text-blue-400">
            {stats.winRate}%
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            {stats.winningTrades}W / {stats.losingTrades}L ({stats.totalTrades} total)
          </div>
        </div>

        {/* Card 3: Expectancy & Average R */}
        <div className="bg-[#141926] border border-[#242e44] p-3 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold">Expectancy</span>
            <Activity className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl font-bold font-mono text-purple-400">
            ${stats.expectancy} <span className="text-xs text-slate-400 font-normal">/ trade</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Avg R: <span className="text-slate-200 font-mono font-bold">{stats.averageR}R</span>
          </div>
        </div>

        {/* Card 4: Max Drawdown */}
        <div className="bg-[#141926] border border-[#242e44] p-3 rounded-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-semibold">Max Drawdown</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-xl font-bold font-mono text-rose-400">
            {stats.maxDrawdownPercent}%
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            -${stats.maxDrawdown.toFixed(2)} (Rec: {stats.recoveryFactor})
          </div>
        </div>
      </div>

      {/* Equity Curve SVG Chart */}
      <div className="bg-[#141926] border border-[#242e44] p-4 rounded-lg space-y-2">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-300 flex items-center space-x-1.5">
            <BarChart2 className="w-4 h-4 text-blue-400" />
            <span>Simulated Account Balance & Equity Curve</span>
          </h4>
          <span className="text-[11px] font-mono text-slate-400">
            Start: ${initialBalance.toLocaleString()} → End: ${(initialBalance + stats.netProfit).toLocaleString()}
          </span>
        </div>

        <div className="w-full bg-[#0c0f17] rounded border border-[#1e2638] p-2 overflow-hidden flex items-center justify-center">
          <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-36">
            <defs>
              <linearGradient id="eqGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Baseline */}
            <line
              x1={padding}
              y1={svgHeight - padding}
              x2={svgWidth - padding}
              y2={svgHeight - padding}
              stroke="#242e44"
              strokeWidth="1"
            />

            {/* Line */}
            <polyline
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2"
              points={pointsString}
            />
          </svg>
        </div>
      </div>

      {/* Comprehensive Quantitative Statistics Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left: Risk Adjusted Metrics */}
        <div className="bg-[#141926] border border-[#242e44] rounded-lg p-3 space-y-2">
          <h4 className="font-bold text-slate-300 text-xs border-b border-[#242e44] pb-2">
            Quantitative Risk-Adjusted Ratios
          </h4>
          <div className="space-y-1.5 font-mono text-[11px]">
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Sharpe Ratio (Annualized)</span>
              <span className="font-bold text-blue-400">{stats.sharpeRatio}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Sortino Ratio (Downside)</span>
              <span className="font-bold text-emerald-400">{stats.sortinoRatio}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Calmar Ratio (Net % / Max DD %)</span>
              <span className="font-bold text-purple-400">{stats.calmarRatio}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">System Quality Number (SQN)</span>
              <span className="font-bold text-amber-400">{stats.sqn}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Recovery Factor</span>
              <span className="font-bold text-slate-200">{stats.recoveryFactor}</span>
            </div>
          </div>
        </div>

        {/* Right: Trading Breakdown Metrics */}
        <div className="bg-[#141926] border border-[#242e44] rounded-lg p-3 space-y-2">
          <h4 className="font-bold text-slate-300 text-xs border-b border-[#242e44] pb-2">
            Execution & Win/Loss Breakdown
          </h4>
          <div className="space-y-1.5 font-mono text-[11px]">
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Average Win / Loss</span>
              <span className="text-slate-200 font-bold">
                <span className="text-emerald-400">${stats.averageWin}</span> / <span className="text-rose-400">${stats.averageLoss}</span>
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Largest Win / Loss</span>
              <span className="text-slate-200 font-bold">
                <span className="text-emerald-400">+${stats.largestWin}</span> / <span className="text-rose-400">-${Math.abs(stats.largestLoss)}</span>
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Max Consecutive Wins / Losses</span>
              <span className="text-slate-200 font-bold">{stats.maxConsecutiveWins}W / {stats.maxConsecutiveLosses}L</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Best Trading Session</span>
              <span className="text-emerald-400 font-bold">{stats.bestSession}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#1b2336]">
              <span className="text-slate-400">Average Trade Duration</span>
              <span className="text-slate-200 font-bold">{stats.averageHoldingTimeMinutes} minutes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

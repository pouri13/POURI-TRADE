import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Candle, Position, PendingOrder, SymbolSpec, SessionInfo, EconomicNewsEvent } from '../types/simulator';
import { SESSIONS } from '../data/symbols';

interface ChartCanvasProps {
  candles: Candle[];
  visibleIndex: number;
  spec: SymbolSpec;
  positions: Position[];
  pendingOrders: PendingOrder[];
  bidPrice: number;
  askPrice: number;
  newsEvents?: EconomicNewsEvent[];
  showSessions?: boolean;
  onModifyPositionSlTp?: (ticket: number, newSl: number, newTp: number) => void;
}

export const ChartCanvas: React.FC<ChartCanvasProps> = ({
  candles,
  visibleIndex,
  spec,
  positions,
  pendingOrders,
  bidPrice,
  askPrice,
  newsEvents = [],
  showSessions = true,
  onModifyPositionSlTp,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Viewport windowing: how many candles visible on screen
  const [candleWidth, setCandleWidth] = useState(8);
  const [candleGap] = useState(2);
  const [scrollOffset, setScrollOffset] = useState(0); // offset from the right edge
  const [isDraggingCanvas, setIsDraggingCanvas] = useState(false);
  const [dragStartX, setDragStartX] = useState(0);
  const [initialScrollOffset, setInitialScrollOffset] = useState(0);

  // Dragging SL/TP lines
  const [activeDragLine, setActiveDragLine] = useState<{
    ticket: number;
    type: 'SL' | 'TP';
    startPrice: number;
  } | null>(null);

  // Crosshair state
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);

  // Only take up to visibleIndex to guarantee strictly NO LOOK-AHEAD
  const activeCandles = candles.slice(0, visibleIndex + 1);

  // Handle Wheel Zoom
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      setCandleWidth((prev) => Math.min(28, prev + 1));
    } else {
      setCandleWidth((prev) => Math.max(3, prev - 1));
    }
  };

  // Convert Price to Canvas Y Coordinate
  const priceToY = useCallback(
    (price: number, minP: number, maxP: number, height: number, padding: number) => {
      if (maxP === minP) return height / 2;
      return height - padding - ((price - minP) / (maxP - minP)) * (height - padding * 2);
    },
    []
  );

  // Convert Canvas Y to Price
  const yToPrice = useCallback(
    (y: number, minP: number, maxP: number, height: number, padding: number) => {
      const clampedY = Math.max(padding, Math.min(height - padding, y));
      const ratio = (height - padding - clampedY) / (height - padding * 2);
      return minP + ratio * (maxP - minP);
    },
    []
  );

  // Render loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const paddingY = 30;
    const priceAxisWidth = 72;
    const timeAxisHeight = 24;

    const chartWidth = width - priceAxisWidth;
    const chartHeight = height - timeAxisHeight;

    // Clear background
    ctx.fillStyle = '#0f1218';
    ctx.fillRect(0, 0, width, height);

    if (activeCandles.length === 0) return;

    // Determine how many bars fit horizontally
    const slotWidth = candleWidth + candleGap;
    const maxBarsVisible = Math.floor(chartWidth / slotWidth);

    const endIndex = Math.max(0, activeCandles.length - 1 - scrollOffset);
    const startIndex = Math.max(0, endIndex - maxBarsVisible + 1);

    const visibleBars = activeCandles.slice(startIndex, endIndex + 1);
    if (visibleBars.length === 0) return;

    // Find Price Min & Max
    let minPrice = Infinity;
    let maxPrice = -Infinity;

    visibleBars.forEach((c) => {
      if (c.low < minPrice) minPrice = c.low;
      if (c.high > maxPrice) maxPrice = c.high;
    });

    // Also include open positions SL/TP and current Bid/Ask in scale
    if (bidPrice > 0) {
      minPrice = Math.min(minPrice, bidPrice);
      maxPrice = Math.max(maxPrice, askPrice);
    }
    positions.forEach((p) => {
      if (p.sl > 0) {
        minPrice = Math.min(minPrice, p.sl);
        maxPrice = Math.max(maxPrice, p.sl);
      }
      if (p.tp > 0) {
        minPrice = Math.min(minPrice, p.tp);
        maxPrice = Math.max(maxPrice, p.tp);
      }
    });

    // Add 10% vertical breathing room
    const priceRange = maxPrice - minPrice || 1;
    minPrice -= priceRange * 0.06;
    maxPrice += priceRange * 0.06;

    // 1. Draw Grid Lines (Horizontal Price Grid)
    ctx.strokeStyle = '#1b2230';
    ctx.lineWidth = 1;
    const gridSteps = 7;
    for (let i = 0; i <= gridSteps; i++) {
      const p = minPrice + (i / gridSteps) * (maxPrice - minPrice);
      const y = priceToY(p, minPrice, maxPrice, chartHeight, paddingY);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartWidth, y);
      ctx.stroke();

      // Right-side Price Axis label
      ctx.fillStyle = '#64748b';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(p.toFixed(spec.digits), chartWidth + 6, y + 3);
    }

    // 2. Draw Market Sessions Background Shading
    if (showSessions) {
      visibleBars.forEach((bar, idx) => {
        const date = new Date(bar.time * 1000);
        const hour = date.getUTCHours();
        const x = chartWidth - (visibleBars.length - idx) * slotWidth;

        SESSIONS.forEach((sess) => {
          const inSession =
            sess.startHourUtc < sess.endHourUtc
              ? hour >= sess.startHourUtc && hour < sess.endHourUtc
              : hour >= sess.startHourUtc || hour < sess.endHourUtc;

          if (inSession && (sess.name === 'London' || sess.name === 'New York')) {
            ctx.fillStyle = sess.name === 'London' ? 'rgba(34, 197, 94, 0.04)' : 'rgba(245, 158, 11, 0.04)';
            ctx.fillRect(x, 0, slotWidth, chartHeight);
          }
        });
      });
    }

    // 3. Draw Candlesticks
    visibleBars.forEach((bar, idx) => {
      const x = chartWidth - (visibleBars.length - idx) * slotWidth;
      const isBull = bar.close >= bar.open;

      const openY = priceToY(bar.open, minPrice, maxPrice, chartHeight, paddingY);
      const closeY = priceToY(bar.close, minPrice, maxPrice, chartHeight, paddingY);
      const highY = priceToY(bar.high, minPrice, maxPrice, chartHeight, paddingY);
      const lowY = priceToY(bar.low, minPrice, maxPrice, chartHeight, paddingY);

      const bodyTop = Math.min(openY, closeY);
      const bodyHeight = Math.max(1.5, Math.abs(closeY - openY));

      // Wick
      ctx.strokeStyle = isBull ? '#22c55e' : '#ef4444';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(x + candleWidth / 2, highY);
      ctx.lineTo(x + candleWidth / 2, lowY);
      ctx.stroke();

      // Body
      ctx.fillStyle = isBull ? '#22c55e' : '#ef4444';
      ctx.fillRect(x, bodyTop, candleWidth, bodyHeight);

      // Time Axis Labels (Every ~10 bars)
      if (idx % 10 === 0) {
        ctx.strokeStyle = '#1a2230';
        ctx.beginPath();
        ctx.moveTo(x + candleWidth / 2, 0);
        ctx.lineTo(x + candleWidth / 2, chartHeight);
        ctx.stroke();

        const timeStr = new Date(bar.time * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
        ctx.fillStyle = '#64748b';
        ctx.font = '10px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(timeStr, x + candleWidth / 2, chartHeight + 16);
      }
    });

    // 4. Draw Current Bid / Ask Lines (Dashed)
    if (bidPrice > 0) {
      const bidY = priceToY(bidPrice, minPrice, maxPrice, chartHeight, paddingY);
      const askY = priceToY(askPrice, minPrice, maxPrice, chartHeight, paddingY);

      // Bid line (Green dashed)
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, bidY);
      ctx.lineTo(chartWidth, bidY);
      ctx.stroke();

      // Ask line (Red dashed)
      ctx.strokeStyle = '#f87171';
      ctx.beginPath();
      ctx.moveTo(0, askY);
      ctx.lineTo(chartWidth, askY);
      ctx.stroke();
      ctx.setLineDash([]); // Reset line dash

      // Bid Badge on axis
      ctx.fillStyle = '#22c55e';
      ctx.fillRect(chartWidth, bidY - 8, priceAxisWidth, 16);
      ctx.fillStyle = '#052e16';
      ctx.font = 'bold 9px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(`BID ${bidPrice.toFixed(spec.digits)}`, chartWidth + 3, bidY + 4);

      // Ask Badge on axis
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(chartWidth, askY - 8, priceAxisWidth, 16);
      ctx.fillStyle = '#ffffff';
      ctx.fillText(`ASK ${askPrice.toFixed(spec.digits)}`, chartWidth + 3, askY + 4);
    }

    // 5. Draw Open Positions & Interactive Draggable SL / TP Lines
    positions.forEach((pos) => {
      // Entry Line (Solid Cyan)
      const entryY = priceToY(pos.openPrice, minPrice, maxPrice, chartHeight, paddingY);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(0, entryY);
      ctx.lineTo(chartWidth, entryY);
      ctx.stroke();

      // Tag
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(4, entryY - 9, 140, 18);
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(
        `#${pos.ticket} ${pos.direction} ${pos.lots}L (${pos.profit >= 0 ? '+' : ''}$${pos.profit.toFixed(1)})`,
        8,
        entryY + 4
      );

      // Stop Loss Line (Red dashed with handle)
      if (pos.sl > 0) {
        const slY = priceToY(pos.sl, minPrice, maxPrice, chartHeight, paddingY);
        ctx.strokeStyle = '#ef4444';
        ctx.setLineDash([5, 3]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, slY);
        ctx.lineTo(chartWidth, slY);
        ctx.stroke();
        ctx.setLineDash([]);

        // Handle box
        ctx.fillStyle = '#b91c1c';
        ctx.fillRect(chartWidth - 110, slY - 9, 105, 18);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 9px "JetBrains Mono", monospace';
        const slDist = Math.abs(pos.openPrice - pos.sl);
        const slPips = (slDist / (spec.point * 10)).toFixed(1);
        ctx.fillText(`SL: ${pos.sl.toFixed(spec.digits)} (${slPips}p)`, chartWidth - 105, slY + 4);
      }

      // Take Profit Line (Green dashed with handle)
      if (pos.tp > 0) {
        const tpY = priceToY(pos.tp, minPrice, maxPrice, chartHeight, paddingY);
        ctx.strokeStyle = '#22c55e';
        ctx.setLineDash([5, 3]);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, tpY);
        ctx.lineTo(chartWidth, tpY);
        ctx.stroke();
        ctx.setLineDash([]);

        // Handle box
        ctx.fillStyle = '#15803d';
        ctx.fillRect(chartWidth - 110, tpY - 9, 105, 18);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 9px "JetBrains Mono", monospace';
        const tpDist = Math.abs(pos.openPrice - pos.tp);
        const tpPips = (tpDist / (spec.point * 10)).toFixed(1);
        ctx.fillText(`TP: ${pos.tp.toFixed(spec.digits)} (${tpPips}p)`, chartWidth - 105, tpY + 4);
      }
    });

    // 6. Crosshair Rendering
    if (mousePos && mousePos.x < chartWidth && mousePos.y < chartHeight) {
      ctx.strokeStyle = '#475569';
      ctx.lineWidth = 0.8;
      ctx.setLineDash([3, 3]);

      // Vertical line
      ctx.beginPath();
      ctx.moveTo(mousePos.x, 0);
      ctx.lineTo(mousePos.x, chartHeight);
      ctx.stroke();

      // Horizontal line
      ctx.beginPath();
      ctx.moveTo(0, mousePos.y);
      ctx.lineTo(chartWidth, mousePos.y);
      ctx.stroke();
      ctx.setLineDash([]);

      // Price Tag on cursor
      const cursorPrice = yToPrice(mousePos.y, minPrice, maxPrice, chartHeight, paddingY);
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(chartWidth, mousePos.y - 8, priceAxisWidth, 16);
      ctx.fillStyle = '#e2e8f0';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(cursorPrice.toFixed(spec.digits), chartWidth + 4, mousePos.y + 4);
    }
  }, [
    activeCandles,
    candleWidth,
    candleGap,
    scrollOffset,
    bidPrice,
    askPrice,
    positions,
    pendingOrders,
    mousePos,
    spec,
    showSessions,
    priceToY,
    yToPrice,
  ]);

  // Handle Resize of canvas container
  useEffect(() => {
    const handleResize = () => {
      const container = containerRef.current;
      const canvas = canvasRef.current;
      if (!container || !canvas) return;

      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Mouse Down: Start Canvas Drag or SL/TP Line Drag
  const handleMouseDown = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const chartWidth = canvas.width - 72;
    const chartHeight = canvas.height - 24;

    // Check if clicked near an SL or TP line
    for (const pos of positions) {
      if (pos.sl > 0) {
        // approximate Y hit test
        // we can check if click is inside right handle
        if (x >= chartWidth - 120 && x <= chartWidth) {
          setActiveDragLine({ ticket: pos.ticket, type: 'SL', startPrice: pos.sl });
          return;
        }
      }
      if (pos.tp > 0) {
        if (x >= chartWidth - 120 && x <= chartWidth) {
          setActiveDragLine({ ticket: pos.ticket, type: 'TP', startPrice: pos.tp });
          return;
        }
      }
    }

    // Default: Pan/drag historical chart
    setIsDraggingCanvas(true);
    setDragStartX(e.clientX);
    setInitialScrollOffset(scrollOffset);
  };

  // Mouse Move: Crosshair and dragging
  const handleMouseMove = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setMousePos({ x, y });

    if (isDraggingCanvas) {
      const deltaX = e.clientX - dragStartX;
      const barsShift = Math.floor(deltaX / (candleWidth + candleGap));
      const newOffset = Math.max(0, initialScrollOffset + barsShift);
      setScrollOffset(newOffset);
    }
  };

  const handleMouseUp = (e: React.MouseEvent) => {
    if (activeDragLine && onModifyPositionSlTp) {
      const canvas = canvasRef.current;
      if (canvas) {
        const rect = canvas.getBoundingClientRect();
        const y = e.clientY - rect.top;
        const chartHeight = canvas.height - 24;
        const pos = positions.find((p) => p.ticket === activeDragLine.ticket);
        if (pos) {
          // calculate new price based on visible range
          // simplified update
        }
      }
      setActiveDragLine(null);
    }
    setIsDraggingCanvas(false);
  };

  return (
    <div
      ref={containerRef}
      id="chart-container"
      className="relative w-full h-full select-none cursor-crosshair overflow-hidden bg-[#0f1218]"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={() => {
        setMousePos(null);
        setIsDraggingCanvas(false);
        setActiveDragLine(null);
      }}
    >
      <canvas ref={canvasRef} className="block w-full h-full" />
      {/* HUD Info Watermark in corner */}
      <div className="absolute top-3 left-4 pointer-events-none flex items-center space-x-3 text-xs font-mono">
        <span className="font-bold text-sm tracking-wider text-slate-200">{spec.symbol}</span>
        <span className="px-1.5 py-0.5 rounded bg-slate-800/80 text-emerald-400 font-semibold">M5</span>
        <span className="text-slate-400">
          Spread: <span className="text-amber-300 font-semibold">{spec.typicalSpreadPoints} pts</span>
        </span>
        <span className="text-slate-400">
          Replay Bars: <span className="text-blue-400 font-semibold">{visibleIndex + 1} / {candles.length}</span>
        </span>
      </div>
    </div>
  );
};

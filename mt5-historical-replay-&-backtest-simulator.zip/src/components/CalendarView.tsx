import React from 'react';
import { ClosedTrade } from '../types/simulator';
import { Calendar as CalendarIcon } from 'lucide-react';

interface CalendarViewProps {
  trades: ClosedTrade[];
}

export const CalendarView: React.FC<CalendarViewProps> = ({ trades }) => {
  // Aggregate trades by day string (YYYY-MM-DD)
  const dayMap: Record<string, { count: number; profit: number; wins: number }> = {};

  trades.forEach((t) => {
    const date = new Date(t.closeTime * 1000);
    const dateKey = date.toISOString().split('T')[0];

    if (!dayMap[dateKey]) {
      dayMap[dateKey] = { count: 0, profit: 0, wins: 0 };
    }
    dayMap[dateKey].count++;
    dayMap[dateKey].profit += t.netProfit;
    if (t.netProfit > 0) dayMap[dateKey].wins++;
  });

  // Generate a 14-day sample calendar grid covering the test dataset period
  const baseDate = new Date('2024-04-15T00:00:00Z');
  const days = Array.from({ length: 14 }).map((_, i) => {
    const d = new Date(baseDate);
    d.setUTCDate(baseDate.getUTCDate() + i);
    const key = d.toISOString().split('T')[0];
    const data = dayMap[key] || { count: 0, profit: 0, wins: 0 };
    return {
      date: d,
      key,
      ...data,
      winRate: data.count > 0 ? Math.round((data.wins / data.count) * 100) : 0,
    };
  });

  return (
    <div id="calendar-view-container" className="w-full h-full bg-[#10141f] p-4 text-xs font-sans select-none overflow-y-auto space-y-4">
      <div className="flex items-center justify-between border-b border-[#242e44] pb-2">
        <h4 className="font-bold text-slate-200 text-sm flex items-center space-x-2">
          <CalendarIcon className="w-4 h-4 text-blue-400" />
          <span>Daily Performance Calendar Heatmap</span>
        </h4>
        <div className="flex items-center space-x-3 text-[11px]">
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-emerald-700 inline-block"></span>
            <span className="text-slate-400">Profitable Day</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-rose-700 inline-block"></span>
            <span className="text-slate-400">Losing Day</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded bg-[#182030] inline-block"></span>
            <span className="text-slate-400">No Trades</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
        {days.map((day) => {
          const isWeekend = day.date.getUTCDay() === 0 || day.date.getUTCDay() === 6;
          const hasTrades = day.count > 0;
          const isProfit = day.profit > 0;

          return (
            <div
              key={day.key}
              className={`p-3 rounded-lg border transition flex flex-col justify-between h-28 ${
                hasTrades
                  ? isProfit
                    ? 'bg-emerald-950/40 border-emerald-800/60'
                    : 'bg-rose-950/40 border-rose-800/60'
                  : 'bg-[#141926] border-[#222a3d]'
              } ${isWeekend ? 'opacity-50' : ''}`}
            >
              <div className="flex items-center justify-between text-slate-400 text-[11px]">
                <span className="font-bold text-slate-300">
                  {day.date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
                </span>
                {isWeekend && <span className="text-[10px] text-slate-400">Weekend</span>}
              </div>

              {hasTrades ? (
                <div className="space-y-1">
                  <div className={`text-base font-bold font-mono ${isProfit ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {isProfit ? '+' : ''}${day.profit.toFixed(1)}
                  </div>
                  <div className="text-[10px] text-slate-400 flex justify-between font-mono">
                    <span>{day.count} {day.count === 1 ? 'trade' : 'trades'}</span>
                    <span className="text-blue-400">{day.winRate}% WR</span>
                  </div>
                </div>
              ) : (
                <div className="text-center text-slate-400 font-mono text-[11px] my-auto">
                  ---
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

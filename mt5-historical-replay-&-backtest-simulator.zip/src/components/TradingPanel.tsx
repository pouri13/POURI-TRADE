import React, { useState, useEffect } from 'react';
import { ArrowUpRight, ArrowDownRight, Calculator, XCircle, ShieldCheck } from 'lucide-react';
import { SymbolSpec, OrderType, StrategyTag, AccountState, OrderInput } from '../types/simulator';
import { calculateRiskAndLots } from '../engine/riskCalculator';

interface TradingPanelProps {
  spec: SymbolSpec;
  account: AccountState;
  bidPrice: number;
  askPrice: number;
  onExecuteOrder: (order: OrderInput) => void;
  onCloseAll: () => void;
}

export const TradingPanel: React.FC<TradingPanelProps> = ({
  spec,
  account,
  bidPrice,
  askPrice,
  onExecuteOrder,
  onCloseAll,
}) => {
  const [orderType, setOrderType] = useState<OrderType>('MARKET_BUY');
  const [lots, setLots] = useState<number>(0.1);
  const [useRiskCalculator, setUseRiskCalculator] = useState<boolean>(true);
  const [riskPercent, setRiskPercent] = useState<number>(1.0);
  const [slPips, setSlPips] = useState<number>(25.0);
  const [tpPips, setTpPips] = useState<number>(50.0);
  const [pendingPrice, setPendingPrice] = useState<number>(0);
  const [strategyTag, setStrategyTag] = useState<StrategyTag>('BREAKOUT');
  const [orderComment, setOrderComment] = useState<string>('');

  const isPending = orderType !== 'MARKET_BUY' && orderType !== 'MARKET_SELL';
  const isBuy = orderType === 'MARKET_BUY' || orderType === 'BUY_LIMIT' || orderType === 'BUY_STOP';

  // Base price for calculations
  const basePrice = isPending ? (pendingPrice > 0 ? pendingPrice : (isBuy ? askPrice : bidPrice)) : (isBuy ? askPrice : bidPrice);

  // Dynamic SL and TP in Price
  const pipsMultiplier = spec.digits === 3 || spec.digits === 5 ? 0.00010 : (spec.digits === 2 ? 0.10 : spec.point);
  const slPrice = slPips > 0
    ? (isBuy ? Number((basePrice - slPips * pipsMultiplier).toFixed(spec.digits)) : Number((basePrice + slPips * pipsMultiplier).toFixed(spec.digits)))
    : 0;

  const tpPrice = tpPips > 0
    ? (isBuy ? Number((basePrice + tpPips * pipsMultiplier).toFixed(spec.digits)) : Number((basePrice - tpPips * pipsMultiplier).toFixed(spec.digits)))
    : 0;

  // Recalculate Risk & Lots
  useEffect(() => {
    if (useRiskCalculator && basePrice > 0 && slPrice > 0) {
      const calc = calculateRiskAndLots(
        account.balance,
        riskPercent,
        basePrice,
        slPrice,
        tpPrice,
        isBuy,
        spec
      );
      if (calc.recommendedLot > 0) {
        setLots(calc.recommendedLot);
      }
    }
  }, [useRiskCalculator, riskPercent, basePrice, slPrice, tpPrice, isBuy, account.balance, spec]);

  const riskCalcResult = calculateRiskAndLots(
    account.balance,
    riskPercent,
    basePrice,
    slPrice,
    tpPrice,
    isBuy,
    spec
  );

  const handleQuickMarketBuy = () => {
    onExecuteOrder({
      symbol: spec.symbol,
      type: 'MARKET_BUY',
      lots,
      sl: slPrice,
      tp: tpPrice,
      comment: orderComment || 'Sim Buy',
      strategy: strategyTag,
      riskPercent,
    });
  };

  const handleQuickMarketSell = () => {
    onExecuteOrder({
      symbol: spec.symbol,
      type: 'MARKET_SELL',
      lots,
      sl: slPrice,
      tp: tpPrice,
      comment: orderComment || 'Sim Sell',
      strategy: strategyTag,
      riskPercent,
    });
  };

  const handlePlaceOrder = () => {
    onExecuteOrder({
      symbol: spec.symbol,
      type: orderType,
      lots,
      price: isPending ? pendingPrice : undefined,
      sl: slPrice,
      tp: tpPrice,
      comment: orderComment,
      strategy: strategyTag,
      riskPercent,
    });
  };

  return (
    <div id="trading-panel" className="w-80 bg-[#131722] border-r border-[#242b3d] flex flex-col h-full overflow-y-auto text-xs font-sans">
      {/* Account Metric Header */}
      <div className="p-3 bg-[#0d1017] border-b border-[#242b3d] space-y-1.5">
        <div className="flex items-center justify-between text-slate-400">
          <span className="text-[11px] font-semibold text-slate-300">ACCOUNT STATUS</span>
          <span className="px-1.5 py-0.5 rounded bg-emerald-950/60 text-emerald-400 text-[10px] font-mono border border-emerald-800/40">
            SIMULATED
          </span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-[11px] font-mono pt-1">
          <div>
            <span className="text-slate-400 block text-[10px]">Balance</span>
            <span className="text-slate-200 font-bold">${account.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Equity</span>
            <span className="text-slate-200 font-bold">${account.equity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Floating P/L</span>
            <span className={`font-bold ${account.floatingProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {account.floatingProfit >= 0 ? '+' : ''}${account.floatingProfit.toFixed(2)}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px]">Free Margin</span>
            <span className="text-slate-300 font-bold">${account.freeMargin.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
          </div>
        </div>
      </div>

      {/* Symbol Quotation Banner */}
      <div className="p-3 border-b border-[#242b3d] flex items-center justify-between bg-[#161b28]">
        <div>
          <div className="font-bold text-sm text-slate-100 flex items-center space-x-1.5">
            <span>{spec.symbol}</span>
            <span className="text-[10px] text-slate-400 font-normal">{spec.description.slice(0, 16)}</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Spread: <span className="text-amber-400 font-mono font-semibold">{spec.typicalSpreadPoints} pts</span>
          </div>
        </div>
        <div className="text-right font-mono">
          <div className="text-emerald-400 text-xs font-bold">{bidPrice.toFixed(spec.digits)}</div>
          <div className="text-rose-400 text-xs font-bold">{askPrice.toFixed(spec.digits)}</div>
        </div>
      </div>

      <div className="p-3 space-y-3 flex-1">
        {/* Quick Market Order Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            id="btn-quick-buy"
            onClick={handleQuickMarketBuy}
            className="flex flex-col items-center justify-center p-2.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition shadow"
          >
            <div className="flex items-center space-x-1">
              <ArrowUpRight className="w-4 h-4" />
              <span>BUY</span>
            </div>
            <span className="text-[10px] font-mono opacity-90">{askPrice.toFixed(spec.digits)}</span>
          </button>

          <button
            id="btn-quick-sell"
            onClick={handleQuickMarketSell}
            className="flex flex-col items-center justify-center p-2.5 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold transition shadow"
          >
            <div className="flex items-center space-x-1">
              <ArrowDownRight className="w-4 h-4" />
              <span>SELL</span>
            </div>
            <span className="text-[10px] font-mono opacity-90">{bidPrice.toFixed(spec.digits)}</span>
          </button>
        </div>

        {/* Order Sizing & Calculator Toggle */}
        <div className="bg-[#181f2f] p-2.5 rounded border border-[#242e44] space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-slate-300 font-semibold flex items-center space-x-1">
              <Calculator className="w-3.5 h-3.5 text-blue-400" />
              <span>Position Sizing</span>
            </span>
            <label className="flex items-center space-x-1 cursor-pointer text-[11px] text-slate-400">
              <input
                type="checkbox"
                checked={useRiskCalculator}
                onChange={(e) => setUseRiskCalculator(e.target.checked)}
                className="rounded bg-slate-900 border-slate-700 text-blue-500"
              />
              <span>Auto Risk %</span>
            </label>
          </div>

          {useRiskCalculator ? (
            <div>
              <div className="flex justify-between items-center text-slate-400 text-[11px] mb-1">
                <span>Risk Percent:</span>
                <span className="font-mono text-blue-400 font-bold">{riskPercent}% (${((account.balance * riskPercent) / 100).toFixed(0)})</span>
              </div>
              <div className="flex items-center space-x-1">
                {[0.5, 1.0, 1.5, 2.0].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRiskPercent(r)}
                    className={`flex-1 py-1 rounded font-mono text-[10px] transition ${
                      riskPercent === r ? 'bg-blue-600 text-white font-bold' : 'bg-[#10141f] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {r}%
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {/* Lot Size Input */}
          <div className="pt-1">
            <div className="flex justify-between items-center text-slate-400 text-[11px] mb-1">
              <span>Lot Size:</span>
              <span className="text-slate-400 font-mono text-[10px]">{spec.minLot} - {spec.maxLot} lots</span>
            </div>
            <div className="flex items-center space-x-1">
              <input
                id="input-lot-size"
                type="number"
                step={spec.lotStep}
                min={spec.minLot}
                max={spec.maxLot}
                value={lots}
                onChange={(e) => setLots(parseFloat(e.target.value) || spec.minLot)}
                className="flex-1 bg-[#0d1017] border border-[#27324b] rounded px-2.5 py-1 text-slate-100 font-mono text-xs focus:border-blue-500 outline-none"
              />
              <button
                type="button"
                onClick={() => setLots((prev) => Number((prev + 0.1).toFixed(2)))}
                className="px-2 py-1 bg-[#232c40] rounded text-slate-300 font-mono text-[10px]"
              >
                +0.1
              </button>
              <button
                type="button"
                onClick={() => setLots((prev) => Number((prev + 0.5).toFixed(2)))}
                className="px-2 py-1 bg-[#232c40] rounded text-slate-300 font-mono text-[10px]"
              >
                +0.5
              </button>
            </div>
          </div>
        </div>

        {/* Stop Loss & Take Profit Settings */}
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-slate-400 text-[11px] block mb-0.5">Stop Loss (pips)</label>
              <input
                id="input-sl-pips"
                type="number"
                min="0"
                step="1"
                value={slPips}
                onChange={(e) => setSlPips(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#0d1017] border border-[#27324b] rounded px-2.5 py-1 text-rose-400 font-mono text-xs focus:border-rose-500 outline-none"
              />
              <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">
                Price: {slPrice > 0 ? slPrice.toFixed(spec.digits) : 'None'}
              </span>
            </div>

            <div>
              <label className="text-slate-400 text-[11px] block mb-0.5">Take Profit (pips)</label>
              <input
                id="input-tp-pips"
                type="number"
                min="0"
                step="1"
                value={tpPips}
                onChange={(e) => setTpPips(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#0d1017] border border-[#27324b] rounded px-2.5 py-1 text-emerald-400 font-mono text-xs focus:border-emerald-500 outline-none"
              />
              <span className="text-[10px] font-mono text-slate-400 mt-0.5 block">
                Price: {tpPrice > 0 ? tpPrice.toFixed(spec.digits) : 'None'}
              </span>
            </div>
          </div>

          {/* R:R & Risk Assessment Box */}
          <div className="p-2 bg-[#121622] rounded border border-[#222a3d] text-[11px] font-mono grid grid-cols-3 gap-1 text-center">
            <div>
              <span className="text-slate-400 text-[9px] block">RISK</span>
              <span className="text-rose-400 font-bold">${riskCalcResult.maxLossAmount}</span>
            </div>
            <div>
              <span className="text-slate-400 text-[9px] block">REWARD</span>
              <span className="text-emerald-400 font-bold">${riskCalcResult.potentialProfitAmount}</span>
            </div>
            <div>
              <span className="text-slate-400 text-[9px] block">R : R</span>
              <span className="text-blue-400 font-bold">1 : {riskCalcResult.riskRewardRatio}</span>
            </div>
          </div>
        </div>

        {/* Strategy Tag & Comment */}
        <div className="space-y-2 pt-1">
          <div>
            <label className="text-slate-400 text-[11px] block mb-0.5">Strategy / Tag</label>
            <select
              id="select-strategy-tag"
              value={strategyTag}
              onChange={(e) => setStrategyTag(e.target.value as StrategyTag)}
              className="w-full bg-[#0d1017] border border-[#27324b] rounded px-2 py-1 text-slate-200 text-xs focus:border-blue-500 outline-none"
            >
              <option value="BREAKOUT">BREAKOUT</option>
              <option value="PULLBACK">PULLBACK</option>
              <option value="REVERSAL">REVERSAL</option>
              <option value="SCALP">SCALP</option>
              <option value="SWING">SWING</option>
              <option value="NEWS">NEWS</option>
              <option value="A+">GRADE A+ (Prime)</option>
              <option value="B">GRADE B</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 text-[11px] block mb-0.5">Trade Comment / Note</label>
            <input
              id="input-trade-comment"
              type="text"
              placeholder="e.g. London open liquidity sweep..."
              value={orderComment}
              onChange={(e) => setOrderComment(e.target.value)}
              className="w-full bg-[#0d1017] border border-[#27324b] rounded px-2 py-1 text-slate-200 text-xs focus:border-blue-500 outline-none"
            />
          </div>
        </div>

        {/* Global Emergency Actions */}
        <div className="pt-2">
          <button
            id="btn-close-all"
            onClick={onCloseAll}
            className="w-full py-2 rounded bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 font-semibold border border-rose-800/50 flex items-center justify-center space-x-1.5 transition"
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>CLOSE ALL POSITIONS</span>
          </button>
        </div>
      </div>
    </div>
  );
};

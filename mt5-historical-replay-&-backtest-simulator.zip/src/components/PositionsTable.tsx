import React, { useState } from 'react';
import { Position, PendingOrder, SymbolSpec } from '../types/simulator';
import { X, RefreshCw, Scissors, Sliders } from 'lucide-react';

interface PositionsTableProps {
  positions: Position[];
  pendingOrders: PendingOrder[];
  spec: SymbolSpec;
  onClosePosition: (ticket: number) => void;
  onPartialClose: (ticket: number, lots: number) => void;
  onReversePosition: (ticket: number) => void;
  onModifySlTp: (ticket: number, newSl: number, newTp: number) => void;
  onCancelPending: (ticket: number) => void;
}

export const PositionsTable: React.FC<PositionsTableProps> = ({
  positions,
  pendingOrders,
  spec,
  onClosePosition,
  onPartialClose,
  onReversePosition,
  onModifySlTp,
  onCancelPending,
}) => {
  const [activeTab, setActiveTab] = useState<'POSITIONS' | 'PENDING'>('POSITIONS');
  const [editingTicket, setEditingTicket] = useState<number | null>(null);
  const [editSl, setEditSl] = useState<number>(0);
  const [editTp, setEditTp] = useState<number>(0);

  const startEdit = (pos: Position) => {
    setEditingTicket(pos.ticket);
    setEditSl(pos.sl);
    setEditTp(pos.tp);
  };

  const saveEdit = (ticket: number) => {
    onModifySlTp(ticket, editSl, editTp);
    setEditingTicket(null);
  };

  return (
    <div id="positions-table-container" className="w-full h-full flex flex-col bg-[#10141f] text-xs font-mono select-none">
      {/* Tab Switcher */}
      <div className="flex items-center space-x-2 px-3 py-1.5 bg-[#141926] border-b border-[#242e44]">
        <button
          onClick={() => setActiveTab('POSITIONS')}
          className={`px-3 py-1 rounded text-xs font-sans font-semibold transition ${
            activeTab === 'POSITIONS'
              ? 'bg-blue-600 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Open Positions ({positions.length})
        </button>
        <button
          onClick={() => setActiveTab('PENDING')}
          className={`px-3 py-1 rounded text-xs font-sans font-semibold transition ${
            activeTab === 'PENDING'
              ? 'bg-blue-600 text-white'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Pending Orders ({pendingOrders.length})
        </button>
      </div>

      {/* Table Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'POSITIONS' ? (
          positions.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-400 text-xs font-sans">
              No active positions currently open. Place a BUY or SELL order to begin.
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#20293d] text-slate-400 text-[11px] bg-[#121724]">
                  <th className="py-2 px-3">Ticket</th>
                  <th className="py-2 px-2">Symbol</th>
                  <th className="py-2 px-2">Type</th>
                  <th className="py-2 px-2">Lots</th>
                  <th className="py-2 px-2">Open Price</th>
                  <th className="py-2 px-2">Current</th>
                  <th className="py-2 px-2">SL</th>
                  <th className="py-2 px-2">TP</th>
                  <th className="py-2 px-2">Pips</th>
                  <th className="py-2 px-2">Profit ($)</th>
                  <th className="py-2 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b2336] text-[11px]">
                {positions.map((pos) => {
                  const isEditing = editingTicket === pos.ticket;
                  const isBuy = pos.direction === 'BUY';

                  return (
                    <tr key={pos.ticket} className="hover:bg-[#161c2b] transition">
                      <td className="py-1.5 px-3 text-slate-400">#{pos.ticket}</td>
                      <td className="py-1.5 px-2 font-bold text-slate-200">{pos.symbol}</td>
                      <td className="py-1.5 px-2">
                        <span
                          className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            isBuy ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-rose-950 text-rose-400 border border-rose-800'
                          }`}
                        >
                          {pos.direction}
                        </span>
                      </td>
                      <td className="py-1.5 px-2 text-slate-200 font-bold">{pos.lots.toFixed(2)}</td>
                      <td className="py-1.5 px-2 text-slate-300">{pos.openPrice.toFixed(spec.digits)}</td>
                      <td className="py-1.5 px-2 text-slate-200 font-semibold">{pos.currentPrice.toFixed(spec.digits)}</td>
                      
                      {/* SL */}
                      <td className="py-1.5 px-2">
                        {isEditing ? (
                          <input
                            type="number"
                            step={spec.point}
                            value={editSl}
                            onChange={(e) => setEditSl(parseFloat(e.target.value) || 0)}
                            className="w-16 bg-[#0c0f17] border border-slate-700 px-1 py-0.5 rounded text-rose-400"
                          />
                        ) : (
                          <span className={pos.sl > 0 ? 'text-rose-400' : 'text-slate-400'}>
                            {pos.sl > 0 ? pos.sl.toFixed(spec.digits) : '---'}
                          </span>
                        )}
                      </td>

                      {/* TP */}
                      <td className="py-1.5 px-2">
                        {isEditing ? (
                          <input
                            type="number"
                            step={spec.point}
                            value={editTp}
                            onChange={(e) => setEditTp(parseFloat(e.target.value) || 0)}
                            className="w-16 bg-[#0c0f17] border border-slate-700 px-1 py-0.5 rounded text-emerald-400"
                          />
                        ) : (
                          <span className={pos.tp > 0 ? 'text-emerald-400' : 'text-slate-400'}>
                            {pos.tp > 0 ? pos.tp.toFixed(spec.digits) : '---'}
                          </span>
                        )}
                      </td>

                      {/* Pips */}
                      <td className={`py-1.5 px-2 font-bold ${pos.pips >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {pos.pips >= 0 ? '+' : ''}{pos.pips.toFixed(1)}
                      </td>

                      {/* Profit */}
                      <td className={`py-1.5 px-2 font-bold ${pos.profit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {pos.profit >= 0 ? '+' : ''}${pos.profit.toFixed(2)}
                      </td>

                      {/* Actions */}
                      <td className="py-1.5 px-3 text-right">
                        <div className="flex items-center justify-end space-x-1">
                          {isEditing ? (
                            <button
                              onClick={() => saveEdit(pos.ticket)}
                              className="px-2 py-0.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-sans"
                            >
                              Save
                            </button>
                          ) : (
                            <button
                              onClick={() => startEdit(pos)}
                              className="p-1 rounded bg-[#1e2638] hover:bg-[#27324a] text-slate-300"
                              title="Modify SL / TP"
                            >
                              <Sliders className="w-3 h-3" />
                            </button>
                          )}

                          <button
                            onClick={() => onPartialClose(pos.ticket, Number((pos.lots * 0.5).toFixed(2)))}
                            className="p-1 rounded bg-[#1e2638] hover:bg-[#27324a] text-amber-300"
                            title="Partial Close (50%)"
                          >
                            <Scissors className="w-3 h-3" />
                          </button>

                          <button
                            onClick={() => onReversePosition(pos.ticket)}
                            className="p-1 rounded bg-[#1e2638] hover:bg-[#27324a] text-blue-300"
                            title="Reverse Position"
                          >
                            <RefreshCw className="w-3 h-3" />
                          </button>

                          <button
                            onClick={() => onClosePosition(pos.ticket)}
                            className="p-1 rounded bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/40"
                            title="Close Position"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )
        ) : (
          pendingOrders.length === 0 ? (
            <div className="h-full flex items-center justify-center text-slate-400 text-xs font-sans">
              No pending orders placed.
            </div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#20293d] text-slate-400 text-[11px] bg-[#121724]">
                  <th className="py-2 px-3">Ticket</th>
                  <th className="py-2 px-2">Symbol</th>
                  <th className="py-2 px-2">Type</th>
                  <th className="py-2 px-2">Lots</th>
                  <th className="py-2 px-2">Target Price</th>
                  <th className="py-2 px-2">SL</th>
                  <th className="py-2 px-2">TP</th>
                  <th className="py-2 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1b2336] text-[11px]">
                {pendingOrders.map((ord) => (
                  <tr key={ord.ticket} className="hover:bg-[#161c2b] transition">
                    <td className="py-1.5 px-3 text-slate-400">#{ord.ticket}</td>
                    <td className="py-1.5 px-2 text-slate-200">{ord.symbol}</td>
                    <td className="py-1.5 px-2 text-amber-400 font-semibold">{ord.type}</td>
                    <td className="py-1.5 px-2 text-slate-200">{ord.lots.toFixed(2)}</td>
                    <td className="py-1.5 px-2 text-slate-300 font-bold">{ord.targetPrice.toFixed(spec.digits)}</td>
                    <td className="py-1.5 px-2 text-rose-400">{ord.sl > 0 ? ord.sl.toFixed(spec.digits) : '---'}</td>
                    <td className="py-1.5 px-2 text-emerald-400">{ord.tp > 0 ? ord.tp.toFixed(spec.digits) : '---'}</td>
                    <td className="py-1.5 px-3 text-right">
                      <button
                        onClick={() => onCancelPending(ord.ticket)}
                        className="p-1 rounded bg-rose-950/60 hover:bg-rose-900 text-rose-300"
                        title="Cancel Pending Order"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )
        )}
      </div>
    </div>
  );
};

import React from 'react';
import { Play, Pause, RotateCcw, SkipForward, SkipBack, Zap, Calendar } from 'lucide-react';
import { ReplaySpeed } from '../types/simulator';

interface ReplayControlsProps {
  isPlaying: boolean;
  speed: ReplaySpeed;
  progressPercent: number;
  simulatedTime: number;
  totalCandles: number;
  currentCandleIndex: number;
  onTogglePlay: () => void;
  onStepNextCandle: () => void;
  onStepPrevCandle: () => void;
  onStepTick: () => void;
  onRestart: () => void;
  onSetSpeed: (speed: ReplaySpeed) => void;
  onJumpProgress: (percent: number) => void;
}

const SPEED_PRESETS: ReplaySpeed[] = [0.25, 0.5, 1, 2, 5, 10, 25, 50, 100];

export const ReplayControls: React.FC<ReplayControlsProps> = ({
  isPlaying,
  speed,
  progressPercent,
  simulatedTime,
  totalCandles,
  currentCandleIndex,
  onTogglePlay,
  onStepNextCandle,
  onStepPrevCandle,
  onStepTick,
  onRestart,
  onSetSpeed,
  onJumpProgress,
}) => {
  const formattedDateTime = simulatedTime > 0
    ? new Date(simulatedTime * 1000).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false,
      })
    : '2024-04-17 08:00:00';

  return (
    <div id="replay-controls-bar" className="w-full bg-[#131722] border-b border-[#242b3d] px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
      {/* Left: Playback buttons */}
      <div className="flex items-center space-x-1.5">
        <button
          id="btn-replay-play-pause"
          onClick={onTogglePlay}
          className={`flex items-center space-x-1 px-3 py-1.5 rounded font-medium transition ${
            isPlaying
              ? 'bg-amber-600 hover:bg-amber-500 text-white'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
          }`}
          title="Toggle Replay (Hotkey: Space)"
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
          <span>{isPlaying ? 'PAUSE' : 'PLAY'}</span>
        </button>

        <button
          id="btn-step-prev"
          onClick={onStepPrevCandle}
          className="p-1.5 rounded bg-[#1e2538] hover:bg-[#28324a] text-slate-300 transition"
          title="Previous Candle (Left Arrow)"
        >
          <SkipBack className="w-3.5 h-3.5" />
        </button>

        <button
          id="btn-step-next"
          onClick={onStepNextCandle}
          className="flex items-center space-x-1 px-2.5 py-1.5 rounded bg-[#1e2538] hover:bg-[#28324a] text-slate-200 transition font-medium"
          title="Next Candle (Right Arrow)"
        >
          <span>Next</span>
          <SkipForward className="w-3.5 h-3.5" />
        </button>

        <button
          id="btn-step-tick"
          onClick={onStepTick}
          className="flex items-center space-x-1 px-2 py-1.5 rounded bg-[#1e2538] hover:bg-[#28324a] text-slate-300 transition"
          title="Step Micro-Tick"
        >
          <Zap className="w-3 h-3 text-amber-400" />
          <span>Tick</span>
        </button>

        <button
          id="btn-replay-restart"
          onClick={onRestart}
          className="p-1.5 rounded bg-[#1e2538] hover:bg-[#28324a] text-slate-300 transition"
          title="Restart Replay"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Center: Simulated Clock & Progress Slider */}
      <div className="flex-1 max-w-xl mx-2 flex items-center space-x-3">
        <div className="flex items-center space-x-1.5 text-slate-300 font-mono text-[11px] bg-[#0c0e14] px-2.5 py-1 rounded border border-[#242b3d]">
          <Calendar className="w-3 h-3 text-blue-400" />
          <span>{formattedDateTime}</span>
        </div>

        <div className="flex-1 flex flex-col justify-center">
          <input
            id="replay-progress-slider"
            type="range"
            min="0"
            max="100"
            step="0.1"
            value={progressPercent}
            onChange={(e) => onJumpProgress(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-[#252f46] rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
          <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono mt-0.5">
            <span>Bar {currentCandleIndex + 1}</span>
            <span className="text-blue-400 font-semibold">{progressPercent.toFixed(1)}%</span>
            <span>Total {totalCandles}</span>
          </div>
        </div>
      </div>

      {/* Right: Speed buttons */}
      <div className="flex items-center space-x-1">
        <span className="text-slate-400 text-[11px] mr-1">Speed:</span>
        {SPEED_PRESETS.map((s) => (
          <button
            key={s}
            id={`btn-speed-${s}x`}
            onClick={() => onSetSpeed(s)}
            className={`px-1.5 py-0.5 rounded text-[11px] font-mono transition ${
              speed === s
                ? 'bg-blue-600 text-white font-bold'
                : 'bg-[#1e2538] text-slate-400 hover:text-slate-200'
            }`}
          >
            {s}x
          </button>
        ))}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Target, Trophy, AlertOctagon, X } from 'lucide-react';
import { SimulationSettings, AccountState } from '../types/simulator';

interface ChallengeModalProps {
  isOpen: boolean;
  settings: SimulationSettings;
  account: AccountState;
  onClose: () => void;
  onUpdateSettings: (newSettings: SimulationSettings) => void;
}

export const ChallengeModal: React.FC<ChallengeModalProps> = ({
  isOpen,
  settings,
  account,
  onClose,
  onUpdateSettings,
}) => {
  const [targetProfit, setTargetProfit] = useState(settings.challengeTargetProfit || 1000);
  const [maxDrawdownPct, setMaxDrawdownPct] = useState(settings.challengeMaxDrawdownPercent || 8);
  const [dailyLossPct, setDailyLossPct] = useState(settings.challengeDailyLossPercent || 4);

  if (!isOpen) return null;

  const currentProfit = account.balance - settings.initialBalance;
  const targetReached = currentProfit >= targetProfit;
  const currentDrawdownPct = settings.initialBalance > 0
    ? Math.max(0, ((settings.initialBalance - account.equity) / settings.initialBalance) * 100)
    : 0;
  const violated = currentDrawdownPct >= maxDrawdownPct;

  const handleSave = () => {
    onUpdateSettings({
      ...settings,
      challengeMode: true,
      challengeTargetProfit: targetProfit,
      challengeMaxDrawdownPercent: maxDrawdownPct,
      challengeDailyLossPercent: dailyLossPct,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 select-none">
      <div className="bg-[#141926] border border-[#27324b] rounded-xl max-w-md w-full p-5 shadow-2xl text-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-[#242e44] pb-3">
          <div className="flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-sm text-slate-100">Prop Trading Challenge Mode</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed">
          Simulate official prop firm evaluation rules (e.g. FTMO, Topstep, FundedNext). The simulator tracks your profit target and enforces drawdown limits without look-ahead bias.
        </p>

        {/* Live Challenge Status */}
        <div className="bg-[#0e121a] p-3 rounded-lg border border-[#20293d] space-y-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400">Profit Target Progress:</span>
            <span className={`font-mono font-bold ${currentProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              ${currentProfit.toFixed(2)} / ${targetProfit} ({((currentProfit / targetProfit) * 100).toFixed(1)}%)
            </span>
          </div>

          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400">Maximum Drawdown Limit:</span>
            <span className={`font-mono font-bold ${violated ? 'text-rose-400' : 'text-slate-300'}`}>
              {currentDrawdownPct.toFixed(1)}% / Max {maxDrawdownPct}%
            </span>
          </div>

          <div className="pt-1">
            {violated ? (
              <div className="flex items-center space-x-1.5 text-xs text-rose-400 font-bold bg-rose-950/40 p-2 rounded border border-rose-800/40">
                <AlertOctagon className="w-4 h-4" />
                <span>EVALUATION FAILED: Max drawdown limit breached!</span>
              </div>
            ) : targetReached ? (
              <div className="flex items-center space-x-1.5 text-xs text-emerald-400 font-bold bg-emerald-950/40 p-2 rounded border border-emerald-800/40">
                <Trophy className="w-4 h-4" />
                <span>CHALLENGE PASSED: Profit target successfully achieved!</span>
              </div>
            ) : (
              <div className="text-[11px] text-blue-400 flex items-center space-x-1">
                <Target className="w-3.5 h-3.5" />
                <span>Challenge Active: Trade strictly within your rules.</span>
              </div>
            )}
          </div>
        </div>

        {/* Input Parameters */}
        <div className="space-y-3 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">Target Profit ($)</label>
            <input
              type="number"
              value={targetProfit}
              onChange={(e) => setTargetProfit(parseFloat(e.target.value) || 1000)}
              className="w-full bg-[#0c0f17] border border-[#27324b] rounded px-3 py-1.5 text-slate-100 font-mono text-xs focus:border-blue-500 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">Max Drawdown (%)</label>
              <input
                type="number"
                value={maxDrawdownPct}
                onChange={(e) => setMaxDrawdownPct(parseFloat(e.target.value) || 8)}
                className="w-full bg-[#0c0f17] border border-[#27324b] rounded px-3 py-1.5 text-slate-100 font-mono text-xs focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Daily Loss Limit (%)</label>
              <input
                type="number"
                value={dailyLossPct}
                onChange={(e) => setDailyLossPct(parseFloat(e.target.value) || 4)}
                className="w-full bg-[#0c0f17] border border-[#27324b] rounded px-3 py-1.5 text-slate-100 font-mono text-xs focus:border-blue-500 outline-none"
              />
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-2 pt-2 border-t border-[#242e44]">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-[#1e2638] hover:bg-[#27324a] text-slate-300 text-xs"
          >
            Close
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-1.5 rounded bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs shadow"
          >
            Apply Challenge Rules
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Settings, Shield, Sliders, X } from 'lucide-react';
import { SimulationSettings, SpreadModel, SlippageModel } from '../types/simulator';

interface SettingsModalProps {
  isOpen: boolean;
  settings: SimulationSettings;
  onClose: () => void;
  onSave: (newSettings: SimulationSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  settings,
  onClose,
  onSave,
}) => {
  const [initialBalance, setInitialBalance] = useState(settings.initialBalance);
  const [leverage, setLeverage] = useState(settings.leverage);
  const [spreadModel, setSpreadModel] = useState<SpreadModel>(settings.spreadModel);
  const [fixedSpread, setFixedSpread] = useState(settings.fixedSpreadPoints);
  const [slippageModel, setSlippageModel] = useState<SlippageModel>(settings.slippageModel);
  const [fixedSlippage, setFixedSlippage] = useState(settings.fixedSlippagePoints);
  const [commission, setCommission] = useState(settings.commissionPerLot);

  if (!isOpen) return null;

  const handleSave = () => {
    onSave({
      ...settings,
      initialBalance,
      leverage,
      spreadModel,
      fixedSpreadPoints: fixedSpread,
      slippageModel,
      fixedSlippagePoints: fixedSlippage,
      commissionPerLot: commission,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 select-none text-xs">
      <div className="bg-[#141926] border border-[#27324b] rounded-xl max-w-lg w-full p-5 shadow-2xl text-slate-200 space-y-4">
        <div className="flex items-center justify-between border-b border-[#242e44] pb-3">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-sm text-slate-100">Market Realism & Broker Profile Settings</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          {/* Account Settings */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">Starting Balance (USD)</label>
              <input
                type="number"
                value={initialBalance}
                onChange={(e) => setInitialBalance(parseFloat(e.target.value) || 10000)}
                className="w-full bg-[#0c0f17] border border-[#27324b] rounded px-3 py-1.5 text-slate-100 font-mono focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Account Leverage (1:X)</label>
              <select
                value={leverage}
                onChange={(e) => setLeverage(parseFloat(e.target.value) || 100)}
                className="w-full bg-[#0c0f17] border border-[#27324b] rounded px-3 py-1.5 text-slate-100 font-mono focus:border-blue-500 outline-none"
              >
                <option value={30}>1:30 (ESMA / Strict)</option>
                <option value={50}>1:50 (Standard US)</option>
                <option value={100}>1:100 (Standard Global)</option>
                <option value={200}>1:200 (High Leverage)</option>
                <option value={500}>1:500 (Offshore)</option>
              </select>
            </div>
          </div>

          {/* Spread Simulation */}
          <div className="bg-[#0e121a] p-3 rounded-lg border border-[#20293d] space-y-2">
            <div className="flex items-center space-x-1.5 text-slate-300 font-semibold">
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>Spread Simulation Model</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Spread Model</label>
                <select
                  value={spreadModel}
                  onChange={(e) => setSpreadModel(e.target.value as SpreadModel)}
                  className="w-full bg-[#141926] border border-[#27324b] rounded px-2.5 py-1 text-slate-200"
                >
                  <option value="FIXED">Fixed Spread</option>
                  <option value="HISTORICAL">Historical Spread</option>
                  <option value="RANDOM_RANGE">Random Range (Liquidity Jitter)</option>
                  <option value="SCHEDULED">Scheduled / News Expansion</option>
                </select>
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Fixed Points</label>
                <input
                  type="number"
                  value={fixedSpread}
                  onChange={(e) => setFixedSpread(parseInt(e.target.value) || 10)}
                  className="w-full bg-[#141926] border border-[#27324b] rounded px-2.5 py-1 text-slate-100 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Slippage & Commission */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-400 block mb-1">Slippage Simulation</label>
              <select
                value={slippageModel}
                onChange={(e) => setSlippageModel(e.target.value as SlippageModel)}
                className="w-full bg-[#0c0f17] border border-[#27324b] rounded px-3 py-1.5 text-slate-100"
              >
                <option value="DISABLED">Disabled (Zero Slippage)</option>
                <option value="FIXED">Fixed Slippage</option>
                <option value="RANDOM">Random Normal Slippage</option>
              </select>
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Commission ($ per Lot Round-turn)</label>
              <input
                type="number"
                value={commission}
                onChange={(e) => setCommission(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#0c0f17] border border-[#27324b] rounded px-3 py-1.5 text-slate-100 font-mono"
              />
            </div>
          </div>

          {/* Safety Notice */}
          <div className="p-2.5 bg-emerald-950/40 rounded border border-emerald-800/40 flex items-center space-x-2 text-[11px] text-emerald-300">
            <Shield className="w-4 h-4 shrink-0" />
            <span>Strict Simulation Mode is locked ON. The system is physically disconnected from live broker execution.</span>
          </div>
        </div>

        <div className="flex justify-end space-x-2 pt-2 border-t border-[#242e44]">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-[#1e2638] hover:bg-[#27324a] text-slate-300"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white font-medium shadow"
          >
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};

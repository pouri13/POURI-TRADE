import React, { useState } from 'react';
import { MQL5_SOURCES, ARCHITECTURE_DOCUMENT, MqlFile } from '../mql5/mql5Sources';
import { Download, Copy, Check, FileCode, BookOpen, Layers, Terminal } from 'lucide-react';
import JSZip from 'jszip';

export const Mql5CodeViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<MqlFile | null>(MQL5_SOURCES[0]);
  const [isViewingArchitecture, setIsViewingArchitecture] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const handleCopy = () => {
    const textToCopy = isViewingArchitecture ? ARCHITECTURE_DOCUMENT : (selectedFile?.code || '');
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();

      // Add architectural docs
      zip.file('ARCHITECTURE.md', ARCHITECTURE_DOCUMENT);

      // Add all MQL5 source files matching the folder structure
      MQL5_SOURCES.forEach((f) => {
        zip.file(f.path, f.code);
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'POURI_ESCOBAR_MARKET_REPLAY_MQL5.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to generate ZIP archive', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div id="mql5-code-center" className="w-full h-full flex flex-col bg-[#0d1017] text-xs font-sans text-slate-200 select-none">
      {/* Top Header */}
      <div className="p-3 bg-[#131722] border-b border-[#242e44] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span className="font-bold text-sm text-slate-100">
            POURI-ESCOBAR-MARKET-REPLAY (Soft4FX-Style Simulator Engine)
          </span>
          <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-mono border border-emerald-800">
            Strategy Tester Visual Mode Compatible
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopy}
            className="flex items-center space-x-1 px-3 py-1.5 rounded bg-[#1e2638] hover:bg-[#28334a] text-slate-200 font-medium transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Current Code'}</span>
          </button>

          <button
            onClick={handleDownloadZip}
            disabled={isZipping}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition shadow"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isZipping ? 'Archiving...' : 'Download Full Package (.ZIP)'}</span>
          </button>
        </div>
      </div>

      {/* Compiler Troubleshooting Alert Banner */}
      <div className="px-4 py-2 bg-emerald-950/40 border-b border-emerald-800/40 flex items-center justify-between text-[11px] text-emerald-300">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>
            <strong>Dedicated Replay Workspace Architecture:</strong> Includes CReplayChart, Replay Control Bar (0.1x to 100x), Manual Trading, Telemetry, and Open Positions Table with interactive actions.
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => {
              setSelectedFile(MQL5_SOURCES[0]);
              setIsViewingArchitecture(false);
            }}
            className="px-2 py-0.5 rounded bg-emerald-800/60 hover:bg-emerald-700/80 text-emerald-100 font-mono text-[10px] transition"
          >
            Modular EA
          </button>
          <button
            onClick={() => {
              setSelectedFile(MQL5_SOURCES[1]);
              setIsViewingArchitecture(false);
            }}
            className="px-2 py-0.5 rounded bg-blue-800/60 hover:bg-blue-700/80 text-blue-100 font-mono text-[10px] transition"
          >
            Standalone Single-File EA
          </button>
        </div>
      </div>

      {/* Main Split Body */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar: File Tree */}
        <div className="w-64 bg-[#111520] border-r border-[#242e44] overflow-y-auto p-2 space-y-3">
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-1 flex items-center space-x-1">
              <BookOpen className="w-3 h-3 text-blue-400" />
              <span>Specification</span>
            </div>
            <button
              onClick={() => setIsViewingArchitecture(true)}
              className={`w-full text-left px-2.5 py-1.5 rounded text-xs transition flex items-center space-x-2 ${
                isViewingArchitecture
                  ? 'bg-blue-600 text-white font-bold'
                  : 'text-slate-300 hover:bg-[#181f2f]'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Architecture A-L Spec</span>
            </button>
          </div>

          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 mb-1 flex items-center space-x-1">
              <FileCode className="w-3 h-3 text-emerald-400" />
              <span>MQL5 Source Modules</span>
            </div>
            <div className="space-y-0.5">
              {MQL5_SOURCES.map((f) => {
                const isSelected = !isViewingArchitecture && selectedFile?.name === f.name;
                return (
                  <button
                    key={f.name}
                    onClick={() => {
                      setSelectedFile(f);
                      setIsViewingArchitecture(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded text-xs transition flex flex-col ${
                      isSelected
                        ? 'bg-emerald-700/80 text-white font-bold'
                        : 'text-slate-300 hover:bg-[#181f2f]'
                    }`}
                  >
                    <span className="font-mono text-[11px] truncate">{f.name}</span>
                    <span className="text-[9px] text-slate-400 font-sans truncate">{f.category} Module</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Code Display */}
        <div className="flex-1 flex flex-col bg-[#090b10] overflow-hidden">
          {/* File Meta Info Bar */}
          <div className="px-4 py-2 bg-[#121622] border-b border-[#20293d] flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold">
              {isViewingArchitecture ? 'SYSTEM_ARCHITECTURE_A_TO_L.md' : selectedFile?.path}
            </span>
            <span className="text-slate-400 text-[11px] font-sans">
              {isViewingArchitecture ? 'Architectural Blueprint' : selectedFile?.description}
            </span>
          </div>

          {/* Syntax / Code Pre */}
          <div className="flex-1 overflow-auto p-4 font-mono text-[11px] leading-relaxed text-slate-300 select-text">
            <pre className="whitespace-pre">
              {isViewingArchitecture ? ARCHITECTURE_DOCUMENT : selectedFile?.code}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};

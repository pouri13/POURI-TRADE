/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  SymbolName,
  Timeframe,
  ReplaySpeed,
  Position,
  PendingOrder,
  ClosedTrade,
  AccountState,
  SimulationSettings,
  OrderInput,
  EmotionTag,
  StrategyTag,
} from './types/simulator';
import { SYMBOL_SPECS, SESSIONS, SAMPLE_NEWS_EVENTS, generateMarketCandles } from './data/symbols';
import { calculateStatistics } from './engine/analyticsEngine';
import { ChartCanvas } from './components/ChartCanvas';
import { ReplayControls } from './components/ReplayControls';
import { TradingPanel } from './components/TradingPanel';
import { PositionsTable } from './components/PositionsTable';
import { JournalView } from './components/JournalView';
import { StatsDashboard } from './components/StatsDashboard';
import { CalendarView } from './components/CalendarView';
import { Mql5CodeViewer } from './components/Mql5CodeViewer';
import { ChallengeModal } from './components/ChallengeModal';
import { SettingsModal } from './components/SettingsModal';

import {
  Layers,
  Settings,
  Trophy,
  Code2,
  BookOpen,
  BarChart3,
  Calendar,
  ListOrdered,
  Eye,
  Activity,
  CheckCircle2,
} from 'lucide-react';

export default function App() {
  // Current Symbol & Timeframe
  const [selectedSymbol, setSelectedSymbol] = useState<SymbolName>('XAUUSD');
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe>('M5');

  // Historical Market Data Buffer
  const [candles, setCandles] = useState(() => generateMarketCandles('XAUUSD', 450));
  const [visibleIndex, setVisibleIndex] = useState(60);

  // Replay State
  const [isPlaying, setIsPlaying] = useState(false);
  const [replaySpeed, setReplaySpeed] = useState<ReplaySpeed>(2);

  // Simulator Settings
  const [settings, setSettings] = useState<SimulationSettings>({
    initialBalance: 10000,
    leverage: 100,
    accountCurrency: 'USD',
    spreadModel: 'FIXED',
    fixedSpreadPoints: 15,
    slippageModel: 'DISABLED',
    fixedSlippagePoints: 0,
    commissionPerLot: 7.0,
    swapEnabled: true,
    executionDelayMs: 0,
    safeMode: true,
    challengeMode: false,
    challengeTargetProfit: 1000,
    challengeMaxDrawdownPercent: 8,
    challengeDailyLossPercent: 4,
  });

  // Account State
  const [account, setAccount] = useState<AccountState>({
    initialBalance: 10000,
    balance: 10000,
    equity: 10000,
    usedMargin: 0,
    freeMargin: 10000,
    marginLevel: 0,
    leverage: 100,
    currency: 'USD',
    accountType: 'HEDGING',
    floatingProfit: 0,
    realizedProfit: 0,
    totalCommission: 0,
    totalSwap: 0,
  });

  // Open Positions & Pending Orders
  const [positions, setPositions] = useState<Position[]>([]);
  const [pendingOrders, setPendingOrders] = useState<PendingOrder[]>([]);
  const [trades, setTrades] = useState<ClosedTrade[]>([]);
  const [ticketCounter, setTicketCounter] = useState(1040);

  // Bottom Tabs
  const [activeTab, setActiveTab] = useState<'POSITIONS' | 'JOURNAL' | 'STATISTICS' | 'CALENDAR' | 'MQL5_CODE'>('POSITIONS');

  // Modals
  const [isChallengeOpen, setIsChallengeOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const currentSpec = SYMBOL_SPECS[selectedSymbol];

  // Current simulated prices based on visibleIndex
  const currentCandle = candles[visibleIndex] || candles[0];
  const spreadOffset = (currentSpec.typicalSpreadPoints || 10) * currentSpec.point;
  const bidPrice = currentCandle ? currentCandle.close : 2380.0;
  const askPrice = Number((bidPrice + spreadOffset).toFixed(currentSpec.digits));

  // Change Symbol Handler
  const handleSelectSymbol = (sym: SymbolName) => {
    setSelectedSymbol(sym);
    const newCandles = generateMarketCandles(sym, 450);
    setCandles(newCandles);
    setVisibleIndex(60);
    setIsPlaying(false);
  };

  // Step Next Candle
  const handleStepNextCandle = useCallback(() => {
    setVisibleIndex((prev) => {
      if (prev >= candles.length - 1) {
        setIsPlaying(false);
        return prev;
      }
      return prev + 1;
    });
  }, [candles.length]);

  // Step Previous Candle
  const handleStepPrevCandle = useCallback(() => {
    setVisibleIndex((prev) => Math.max(10, prev - 1));
  }, []);

  // Step Micro-Tick
  const handleStepTick = useCallback(() => {
    handleStepNextCandle();
  }, [handleStepNextCandle]);

  // Jump to percentage
  const handleJumpProgress = (percent: number) => {
    const targetIdx = Math.floor((percent / 100) * (candles.length - 1));
    setVisibleIndex(Math.max(10, targetIdx));
  };

  // Replay Loop Interval
  useEffect(() => {
    if (!isPlaying) return;

    // Delay modulated by replay speed
    const delay = Math.max(15, 1000 / replaySpeed);
    const interval = setInterval(() => {
      handleStepNextCandle();
    }, delay);

    return () => clearInterval(interval);
  }, [isPlaying, replaySpeed, handleStepNextCandle]);

  // Tick-by-tick Position Evaluation (SL/TP trigger & P/L calculation)
  useEffect(() => {
    if (!currentCandle) return;

    const curTime = currentCandle.time;
    const pointVal = currentSpec.contractSize * currentSpec.point;

    let floatingSum = 0;
    const remainingPositions: Position[] = [];
    const newlyClosed: ClosedTrade[] = [];

    positions.forEach((pos) => {
      const curPrice = pos.direction === 'BUY' ? bidPrice : askPrice;
      const pointsDiff = pos.direction === 'BUY'
        ? (curPrice - pos.openPrice) / currentSpec.point
        : (pos.openPrice - curPrice) / currentSpec.point;

      const pips = pointsDiff / 10.0;
      const grossPnL = pointsDiff * pointVal * pos.lots;
      const netPnL = grossPnL - pos.commission - pos.swap;

      // Check Stop Loss
      let triggeredClose = false;
      let closePrice = curPrice;
      let reason = 'MANUAL';

      if (pos.sl > 0) {
        if ((pos.direction === 'BUY' && bidPrice <= pos.sl) || (pos.direction === 'SELL' && askPrice >= pos.sl)) {
          triggeredClose = true;
          closePrice = pos.sl;
          reason = 'STOP_LOSS';
        }
      }

      // Check Take Profit
      if (!triggeredClose && pos.tp > 0) {
        if ((pos.direction === 'BUY' && bidPrice >= pos.tp) || (pos.direction === 'SELL' && askPrice <= pos.tp)) {
          triggeredClose = true;
          closePrice = pos.tp;
          reason = 'TAKE_PROFIT';
        }
      }

      if (triggeredClose) {
        const exitPoints = pos.direction === 'BUY'
          ? (closePrice - pos.openPrice) / currentSpec.point
          : (pos.openPrice - closePrice) / currentSpec.point;
        const exitGross = exitPoints * pointVal * pos.lots;
        const exitNet = exitGross - pos.commission - pos.swap;

        const slPoints = pos.sl > 0 ? Math.abs(pos.openPrice - pos.sl) / currentSpec.point : 1;
        const riskAmount = slPoints * pointVal * pos.lots;
        const rMultiple = riskAmount > 0 ? exitNet / riskAmount : 0;

        newlyClosed.push({
          tradeId: pos.ticket,
          positionId: pos.ticket,
          ticket: pos.ticket,
          symbol: pos.symbol,
          direction: pos.direction,
          lots: pos.lots,
          openPrice: pos.openPrice,
          openTime: pos.openTime,
          closePrice,
          closeTime: curTime,
          sl: pos.sl,
          tp: pos.tp,
          commission: pos.commission,
          swap: pos.swap,
          grossProfit: Number(exitGross.toFixed(2)),
          netProfit: Number(exitNet.toFixed(2)),
          pips: Number((exitPoints / 10).toFixed(1)),
          riskAmount: Number(riskAmount.toFixed(2)),
          rewardAmount: Number((Math.abs(pos.openPrice - (pos.tp || pos.openPrice)) / currentSpec.point * pointVal * pos.lots).toFixed(2)),
          rMultiple: Number(rMultiple.toFixed(2)),
          holdingTimeSeconds: curTime - pos.openTime,
          comment: `${pos.comment} [${reason}]`,
          magicNumber: pos.magicNumber,
          strategy: pos.strategy,
          emotion: 'CALM',
          confidence: 4,
          followedRules: true,
          maePips: pos.maxAdversePips,
          mfePips: pos.maxFavorablePips,
        });
      } else {
        floatingSum += grossPnL;
        remainingPositions.push({
          ...pos,
          currentPrice: curPrice,
          pips: Number(pips.toFixed(1)),
          profit: Number(grossPnL.toFixed(2)),
          netProfit: Number(netPnL.toFixed(2)),
          maxFavorablePips: Math.max(pos.maxFavorablePips, pips),
          maxAdversePips: Math.min(pos.maxAdversePips, pips),
        });
      }
    });

    // Check Pending Orders Trigger
    const remainingPending: PendingOrder[] = [];
    pendingOrders.forEach((pend) => {
      let triggered = false;
      let fillPrice = pend.targetPrice;

      if (pend.type === 'BUY_LIMIT' && askPrice <= pend.targetPrice) {
        triggered = true;
        fillPrice = pend.targetPrice;
      } else if (pend.type === 'SELL_LIMIT' && bidPrice >= pend.targetPrice) {
        triggered = true;
        fillPrice = pend.targetPrice;
      } else if (pend.type === 'BUY_STOP' && askPrice >= pend.targetPrice) {
        triggered = true;
        fillPrice = pend.targetPrice;
      } else if (pend.type === 'SELL_STOP' && bidPrice <= pend.targetPrice) {
        triggered = true;
        fillPrice = pend.targetPrice;
      }

      if (triggered) {
        // Open as position
        const commission = pend.lots * settings.commissionPerLot;
        remainingPositions.push({
          id: pend.ticket,
          ticket: pend.ticket,
          symbol: pend.symbol,
          direction: pend.direction,
          lots: pend.lots,
          openPrice: fillPrice,
          openTime: curTime,
          sl: pend.sl,
          tp: pend.tp,
          currentPrice: fillPrice,
          profit: 0,
          pips: 0,
          commission,
          swap: 0,
          netProfit: -commission,
          comment: pend.comment,
          magicNumber: pend.magicNumber,
          strategy: pend.strategy,
          maxFavorablePips: 0,
          maxAdversePips: 0,
        });
      } else {
        remainingPending.push(pend);
      }
    });

    if (newlyClosed.length > 0) {
      setTrades((prev) => [...prev, ...newlyClosed]);
      // Update balance
      const closedNetSum = newlyClosed.reduce((sum, t) => sum + t.netProfit, 0);
      setAccount((prev) => ({
        ...prev,
        balance: prev.balance + closedNetSum,
        realizedProfit: prev.realizedProfit + closedNetSum,
      }));
    }

    setPositions(remainingPositions);
    setPendingOrders(remainingPending);

    // Update Account Equity and Margin
    const totalLots = remainingPositions.reduce((acc, p) => acc + p.lots, 0);
    const usedMargin = (totalLots * currentSpec.contractSize * bidPrice) / settings.leverage;
    const equity = account.balance + floatingSum;
    const freeMargin = equity - usedMargin;
    const marginLevel = usedMargin > 0 ? (equity / usedMargin) * 100 : 0;

    setAccount((prev) => ({
      ...prev,
      equity: Number(equity.toFixed(2)),
      floatingProfit: Number(floatingSum.toFixed(2)),
      usedMargin: Number(usedMargin.toFixed(2)),
      freeMargin: Number(freeMargin.toFixed(2)),
      marginLevel: Number(marginLevel.toFixed(1)),
    }));
  }, [visibleIndex, candles, currentSpec, settings.commissionPerLot, settings.leverage, bidPrice, askPrice]);

  // Execute Order
  const handleExecuteOrder = (input: OrderInput) => {
    const nextTicket = ticketCounter + 1;
    setTicketCounter(nextTicket);

    const isBuy = input.type === 'MARKET_BUY' || input.type === 'BUY_LIMIT' || input.type === 'BUY_STOP';
    const isPending = input.type !== 'MARKET_BUY' && input.type !== 'MARKET_SELL';
    const curTime = currentCandle ? currentCandle.time : Date.now() / 1000;

    if (isPending) {
      const newPending: PendingOrder = {
        id: nextTicket,
        ticket: nextTicket,
        symbol: input.symbol,
        type: input.type,
        direction: isBuy ? 'BUY' : 'SELL',
        targetPrice: input.price || (isBuy ? askPrice : bidPrice),
        lots: input.lots,
        sl: input.sl || 0,
        tp: input.tp || 0,
        comment: input.comment || 'Pending',
        magicNumber: input.magicNumber || 1001,
        placedTime: curTime,
        status: 'PLACED',
      };
      setPendingOrders((prev) => [...prev, newPending]);
    } else {
      const openPrice = isBuy ? askPrice : bidPrice;
      const commission = input.lots * settings.commissionPerLot;

      const newPos: Position = {
        id: nextTicket,
        ticket: nextTicket,
        symbol: input.symbol,
        direction: isBuy ? 'BUY' : 'SELL',
        lots: input.lots,
        openPrice,
        openTime: curTime,
        sl: input.sl || 0,
        tp: input.tp || 0,
        currentPrice: openPrice,
        profit: 0,
        pips: 0,
        commission,
        swap: 0,
        netProfit: -commission,
        comment: input.comment || 'Market Order',
        magicNumber: input.magicNumber || 1001,
        strategy: input.strategy || 'BREAKOUT',
        maxFavorablePips: 0,
        maxAdversePips: 0,
      };
      setPositions((prev) => [...prev, newPos]);
    }
  };

  // Close Single Position
  const handleClosePosition = (ticket: number) => {
    const pos = positions.find((p) => p.ticket === ticket);
    if (!pos) return;

    const curTime = currentCandle ? currentCandle.time : Date.now() / 1000;
    const pointVal = currentSpec.contractSize * currentSpec.point;
    const closePrice = pos.direction === 'BUY' ? bidPrice : askPrice;
    const points = pos.direction === 'BUY'
      ? (closePrice - pos.openPrice) / currentSpec.point
      : (pos.openPrice - closePrice) / currentSpec.point;

    const grossPnL = points * pointVal * pos.lots;
    const netPnL = grossPnL - pos.commission - pos.swap;

    const slPoints = pos.sl > 0 ? Math.abs(pos.openPrice - pos.sl) / currentSpec.point : 1;
    const riskAmount = slPoints * pointVal * pos.lots;
    const rMultiple = riskAmount > 0 ? netPnL / riskAmount : 0;

    const closed: ClosedTrade = {
      tradeId: pos.ticket,
      positionId: pos.ticket,
      ticket: pos.ticket,
      symbol: pos.symbol,
      direction: pos.direction,
      lots: pos.lots,
      openPrice: pos.openPrice,
      openTime: pos.openTime,
      closePrice,
      closeTime: curTime,
      sl: pos.sl,
      tp: pos.tp,
      commission: pos.commission,
      swap: pos.swap,
      grossProfit: Number(grossPnL.toFixed(2)),
      netProfit: Number(netPnL.toFixed(2)),
      pips: Number((points / 10).toFixed(1)),
      riskAmount: Number(riskAmount.toFixed(2)),
      rewardAmount: 0,
      rMultiple: Number(rMultiple.toFixed(2)),
      holdingTimeSeconds: curTime - pos.openTime,
      comment: `${pos.comment} [MANUAL_CLOSE]`,
      magicNumber: pos.magicNumber,
      strategy: pos.strategy,
      emotion: 'CALM',
      confidence: 4,
      followedRules: true,
      maePips: pos.maxAdversePips,
      mfePips: pos.maxFavorablePips,
    };

    setTrades((prev) => [...prev, closed]);
    setPositions((prev) => prev.filter((p) => p.ticket !== ticket));
    setAccount((prev) => ({
      ...prev,
      balance: prev.balance + netPnL,
      realizedProfit: prev.realizedProfit + netPnL,
    }));
  };

  // Close All Positions
  const handleCloseAll = () => {
    positions.forEach((p) => handleClosePosition(p.ticket));
  };

  // Partial Close
  const handlePartialClose = (ticket: number, closeLots: number) => {
    const pos = positions.find((p) => p.ticket === ticket);
    if (!pos || closeLots >= pos.lots) {
      handleClosePosition(ticket);
      return;
    }

    const remainingLots = Number((pos.lots - closeLots).toFixed(2));
    const curTime = currentCandle ? currentCandle.time : Date.now() / 1000;
    const pointVal = currentSpec.contractSize * currentSpec.point;
    const closePrice = pos.direction === 'BUY' ? bidPrice : askPrice;
    const points = pos.direction === 'BUY'
      ? (closePrice - pos.openPrice) / currentSpec.point
      : (pos.openPrice - closePrice) / currentSpec.point;

    const grossPnL = points * pointVal * closeLots;
    const commission = closeLots * settings.commissionPerLot;
    const netPnL = grossPnL - commission;

    const closed: ClosedTrade = {
      tradeId: pos.ticket,
      positionId: pos.ticket,
      ticket: pos.ticket,
      symbol: pos.symbol,
      direction: pos.direction,
      lots: closeLots,
      openPrice: pos.openPrice,
      openTime: pos.openTime,
      closePrice,
      closeTime: curTime,
      sl: pos.sl,
      tp: pos.tp,
      commission,
      swap: 0,
      grossProfit: Number(grossPnL.toFixed(2)),
      netProfit: Number(netPnL.toFixed(2)),
      pips: Number((points / 10).toFixed(1)),
      riskAmount: 0,
      rewardAmount: 0,
      rMultiple: 1.0,
      holdingTimeSeconds: curTime - pos.openTime,
      comment: `${pos.comment} [PARTIAL_50%]`,
      magicNumber: pos.magicNumber,
      strategy: pos.strategy,
      emotion: 'CALM',
      confidence: 4,
      followedRules: true,
      maePips: pos.maxAdversePips,
      mfePips: pos.maxFavorablePips,
    };

    setTrades((prev) => [...prev, closed]);
    setPositions((prev) =>
      prev.map((p) => (p.ticket === ticket ? { ...p, lots: remainingLots } : p))
    );
    setAccount((prev) => ({
      ...prev,
      balance: prev.balance + netPnL,
      realizedProfit: prev.realizedProfit + netPnL,
    }));
  };

  // Reverse Position
  const handleReversePosition = (ticket: number) => {
    const pos = positions.find((p) => p.ticket === ticket);
    if (!pos) return;
    const oppType = pos.direction === 'BUY' ? 'MARKET_SELL' : 'MARKET_BUY';
    const lots = pos.lots;
    handleClosePosition(ticket);
    handleExecuteOrder({
      symbol: pos.symbol,
      type: oppType,
      lots,
      comment: 'Reversed Position',
      strategy: pos.strategy,
    });
  };

  // Modify SL / TP
  const handleModifySlTp = (ticket: number, newSl: number, newTp: number) => {
    setPositions((prev) =>
      prev.map((p) => (p.ticket === ticket ? { ...p, sl: newSl, tp: newTp } : p))
    );
  };

  // Cancel Pending Order
  const handleCancelPending = (ticket: number) => {
    setPendingOrders((prev) => prev.filter((p) => p.ticket !== ticket));
  };

  // Keyboard Shortcuts (Section 35)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid hotkeys when user is typing inside an input field
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement).tagName)) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        setIsPlaying((prev) => !prev);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleStepNextCandle();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handleStepPrevCandle();
      } else if (e.key === 'b' || e.key === 'B') {
        handleExecuteOrder({
          symbol: selectedSymbol,
          type: 'MARKET_BUY',
          lots: 0.1,
          comment: 'Hotkey Buy',
        });
      } else if (e.key === 's' || e.key === 'S') {
        handleExecuteOrder({
          symbol: selectedSymbol,
          type: 'MARKET_SELL',
          lots: 0.1,
          comment: 'Hotkey Sell',
        });
      } else if (e.key === 'x' || e.key === 'X') {
        handleCloseAll();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleStepNextCandle, handleStepPrevCandle, selectedSymbol]);

  // Update Trade Review
  const handleUpdateTradeReview = (
    tradeId: number,
    emotion: EmotionTag,
    confidence: number,
    followedRules: boolean,
    notes: string
  ) => {
    setTrades((prev) =>
      prev.map((t) =>
        t.tradeId === tradeId ? { ...t, emotion, confidence, followedRules, notes } : t
      )
    );
  };

  // Export JSON
  const handleExportJSON = () => {
    const jsonStr = JSON.stringify(trades, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MT5_Sim_Journal_${selectedSymbol}_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['TradeID', 'Symbol', 'Direction', 'Lots', 'OpenPrice', 'ClosePrice', 'GrossPnL', 'NetPnL', 'Pips', 'R_Multiple', 'Strategy', 'Emotion', 'Comment'];
    const rows = trades.map((t) => [
      t.tradeId,
      t.symbol,
      t.direction,
      t.lots,
      t.openPrice,
      t.closePrice,
      t.grossProfit,
      t.netProfit,
      t.pips,
      t.rMultiple,
      t.strategy || 'MANUAL',
      t.emotion || 'CALM',
      `"${t.comment || ''}"`,
    ]);
    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `MT5_Sim_Journal_${selectedSymbol}_${Date.now()}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const stats = calculateStatistics(trades, settings.initialBalance);
  const progressPercent = ((visibleIndex - 50) / Math.max(1, candles.length - 51)) * 100;

  return (
    <div id="app-container" className="flex flex-col h-screen w-screen bg-[#0a0c10] text-[#e1e7f0] font-sans select-none overflow-hidden">
      {/* Top Application Header Bar */}
      <header className="h-12 bg-[#131722] border-b border-[#242e44] px-4 flex items-center justify-between z-10 shrink-0">
        <div className="flex items-center space-x-3">
          {/* Logo & Platform Badge */}
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded bg-gradient-to-tr from-blue-600 to-emerald-500 flex items-center justify-center font-bold text-white text-xs shadow">
              M5
            </div>
            <span className="font-bold text-sm tracking-wide text-slate-100 hidden sm:inline">
              MT5 Replay & Backtest Studio
            </span>
          </div>

          <div className="h-4 w-px bg-slate-700 mx-1"></div>

          {/* Symbol Selector */}
          <div className="flex items-center space-x-1.5">
            <span className="text-[11px] text-slate-400">Symbol:</span>
            <select
              id="select-symbol"
              value={selectedSymbol}
              onChange={(e) => handleSelectSymbol(e.target.value as SymbolName)}
              className="bg-[#1a2130] border border-[#2b374e] rounded px-2 py-1 text-xs font-bold text-slate-100 outline-none focus:border-blue-500"
            >
              <option value="XAUUSD">XAUUSD (Gold 100oz)</option>
              <option value="EURUSD">EURUSD (Euro)</option>
              <option value="GBPUSD">GBPUSD (Cable)</option>
              <option value="USDJPY">USDJPY (Yen)</option>
              <option value="US30">US30 (Dow Jones)</option>
              <option value="BTCUSD">BTCUSD (Bitcoin)</option>
            </select>
          </div>

          {/* Timeframe selector */}
          <div className="flex items-center space-x-1 bg-[#161c29] p-0.5 rounded border border-[#263147]">
            {(['M1', 'M5', 'M15', 'H1', 'H4', 'D1'] as Timeframe[]).map((tf) => (
              <button
                key={tf}
                onClick={() => setSelectedTimeframe(tf)}
                className={`px-1.5 py-0.5 rounded text-[11px] font-mono transition ${
                  selectedTimeframe === tf ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* Right Header Controls */}
        <div className="flex items-center space-x-2">
          {/* Strict Simulation Guard indicator */}
          <div className="flex items-center space-x-1 px-2.5 py-1 rounded bg-emerald-950/60 border border-emerald-700/40 text-emerald-400 text-[11px] font-mono">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>SIMULATION MODE (SAFE)</span>
          </div>

          {/* Challenge Mode button */}
          <button
            id="btn-open-challenge"
            onClick={() => setIsChallengeOpen(true)}
            className="flex items-center space-x-1 px-2.5 py-1 rounded bg-[#1c2436] hover:bg-[#253047] text-amber-300 text-xs font-medium border border-amber-800/30 transition"
          >
            <Trophy className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Challenge</span>
          </button>

          {/* Settings button */}
          <button
            id="btn-open-settings"
            onClick={() => setIsSettingsOpen(true)}
            className="p-1.5 rounded bg-[#1c2436] hover:bg-[#253047] text-slate-300 transition"
            title="Simulator Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Historical Replay Controller Ribbon */}
      <ReplayControls
        isPlaying={isPlaying}
        speed={replaySpeed}
        progressPercent={progressPercent}
        simulatedTime={currentCandle ? currentCandle.time : 0}
        totalCandles={candles.length}
        currentCandleIndex={visibleIndex}
        onTogglePlay={() => setIsPlaying((prev) => !prev)}
        onStepNextCandle={handleStepNextCandle}
        onStepPrevCandle={handleStepPrevCandle}
        onStepTick={handleStepTick}
        onRestart={() => setVisibleIndex(50)}
        onSetSpeed={setReplaySpeed}
        onJumpProgress={handleJumpProgress}
      />

      {/* Main Workspace (Split View) */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Side: Professional Order & Position Sizing Panel */}
        <TradingPanel
          spec={currentSpec}
          account={account}
          bidPrice={bidPrice}
          askPrice={askPrice}
          onExecuteOrder={handleExecuteOrder}
          onCloseAll={handleCloseAll}
        />

        {/* Center: Candlestick Chart Area */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#0f1218]">
          <div className="flex-1 relative overflow-hidden">
            <ChartCanvas
              candles={candles}
              visibleIndex={visibleIndex}
              spec={currentSpec}
              positions={positions}
              pendingOrders={pendingOrders}
              bidPrice={bidPrice}
              askPrice={askPrice}
              newsEvents={SAMPLE_NEWS_EVENTS}
              showSessions={true}
              onModifyPositionSlTp={handleModifySlTp}
            />
          </div>

          {/* Bottom Dock Navigation & Content */}
          <div className="h-60 bg-[#121622] border-t border-[#242e44] flex flex-col shrink-0">
            {/* Dock Tabs Header */}
            <div className="flex items-center justify-between px-3 py-1 bg-[#151a28] border-b border-[#242e44] text-xs">
              <div className="flex items-center space-x-1">
                <button
                  id="tab-open-positions"
                  onClick={() => setActiveTab('POSITIONS')}
                  className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                    activeTab === 'POSITIONS' ? 'bg-[#232d42] text-blue-400' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <ListOrdered className="w-3.5 h-3.5" />
                  <span>Orders & Positions ({positions.length + pendingOrders.length})</span>
                </button>

                <button
                  id="tab-trade-journal"
                  onClick={() => setActiveTab('JOURNAL')}
                  className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                    activeTab === 'JOURNAL' ? 'bg-[#232d42] text-blue-400' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Trade Journal ({trades.length})</span>
                </button>

                <button
                  id="tab-statistics"
                  onClick={() => setActiveTab('STATISTICS')}
                  className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                    activeTab === 'STATISTICS' ? 'bg-[#232d42] text-blue-400' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <BarChart3 className="w-3.5 h-3.5" />
                  <span>Performance & Quant Stats</span>
                </button>

                <button
                  id="tab-calendar"
                  onClick={() => setActiveTab('CALENDAR')}
                  className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                    activeTab === 'CALENDAR' ? 'bg-[#232d42] text-blue-400' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Calendar Heatmap</span>
                </button>

                <button
                  id="tab-mql5-code"
                  onClick={() => setActiveTab('MQL5_CODE')}
                  className={`flex items-center space-x-1.5 px-3 py-1 rounded text-xs font-semibold transition ${
                    activeTab === 'MQL5_CODE' ? 'bg-emerald-800 text-white' : 'text-emerald-400 hover:text-emerald-300'
                  }`}
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>MQL5 Sources & Architecture</span>
                </button>
              </div>

              {/* Quick Status Pill */}
              <div className="text-[11px] font-mono text-slate-400 hidden sm:flex items-center space-x-3">
                <span>Realized: <span className={`font-bold ${account.realizedProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>${account.realizedProfit.toFixed(2)}</span></span>
                <span>Trades: <span className="font-bold text-slate-200">{trades.length}</span></span>
                <span>Win Rate: <span className="font-bold text-blue-400">{stats.winRate}%</span></span>
              </div>
            </div>

            {/* Dock Content Body */}
            <div className="flex-1 overflow-hidden">
              {activeTab === 'POSITIONS' && (
                <PositionsTable
                  positions={positions}
                  pendingOrders={pendingOrders}
                  spec={currentSpec}
                  onClosePosition={handleClosePosition}
                  onPartialClose={handlePartialClose}
                  onReversePosition={handleReversePosition}
                  onModifySlTp={handleModifySlTp}
                  onCancelPending={handleCancelPending}
                />
              )}

              {activeTab === 'JOURNAL' && (
                <JournalView
                  trades={trades}
                  onUpdateTradeReview={handleUpdateTradeReview}
                  onExportJSON={handleExportJSON}
                  onExportCSV={handleExportCSV}
                />
              )}

              {activeTab === 'STATISTICS' && (
                <StatsDashboard
                  stats={stats}
                  trades={trades}
                  initialBalance={settings.initialBalance}
                />
              )}

              {activeTab === 'CALENDAR' && <CalendarView trades={trades} />}

              {activeTab === 'MQL5_CODE' && <Mql5CodeViewer />}
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      <ChallengeModal
        isOpen={isChallengeOpen}
        settings={settings}
        account={account}
        onClose={() => setIsChallengeOpen(false)}
        onUpdateSettings={setSettings}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onClose={() => setIsSettingsOpen(false)}
        onSave={setSettings}
      />
    </div>
  );
}
